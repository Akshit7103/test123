# Protiviti MRM Finding Library

Flask + vanilla-JS web app for managing Model Risk Management findings, with TF-IDF clustering, semantic search, PSI drift detection, and OpenAI-powered AI Analyze.

## Local development

```bash
pip install -r requirements.txt
cp .env.example .env          # then paste your OpenAI key into .env
python wsgi.py                # http://localhost:5000
```

## Deploy on Render

This repo includes `render.yaml`, `Procfile`, and `runtime.txt`.

1. Push to GitHub.
2. In Render → **New +** → **Blueprint** → connect this repo. Render reads `render.yaml` and provisions a web service.
3. In the service's **Environment** tab, set `OPENAI_API_KEY` to your real key (it's marked `sync: false` so it's never committed).
4. Deploy. The healthcheck hits `/api/stats/count`.

Manual setup (without Blueprint): create a **Web Service**, set build command to `pip install -r requirements.txt`, start command to the line in `Procfile`, add `OPENAI_API_KEY` and `OPENAI_MODEL` env vars.

## Notes

- **Storage is in-memory.** Findings reset on every restart/spin-up. Add SQLite persistence before relying on this for real data.
- **`/api/llm` is unauthenticated** and proxies billable OpenAI calls. Add a token check or rate limit before exposing publicly.
- Free Render instances spin down after ~15 min idle; first request after sleep takes ~30 s to cold-start.
