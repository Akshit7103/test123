"""Flask application factory."""
import gzip as _gzip
import os as _os

from flask import Flask, request, jsonify

_PROJECT_ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))

# Load .env if available so OPENAI_API_KEY etc. are exposed via os.environ.
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


def _register_gzip(app: Flask) -> None:
    @app.after_request
    def compress_response(response):
        if (response.status_code < 200 or response.status_code >= 300
                or response.direct_passthrough
                or 'Content-Encoding' in response.headers):
            return response
        ct = response.content_type or ''
        if not any(t in ct for t in ('json', 'html', 'javascript', 'text')):
            return response
        data = response.get_data()
        if len(data) < 1024:
            return response
        accept = request.headers.get('Accept-Encoding', '')
        if 'gzip' not in accept:
            return response
        compressed = _gzip.compress(data, compresslevel=6)
        response.set_data(compressed)
        response.headers['Content-Encoding'] = 'gzip'
        response.headers['Content-Length'] = len(compressed)
        response.vary.add('Accept-Encoding')
        return response


def _register_error_handlers(app: Flask) -> None:
    @app.errorhandler(400)
    @app.errorhandler(404)
    @app.errorhandler(405)
    @app.errorhandler(500)
    def json_error(e):
        code = getattr(e, 'code', 500)
        return jsonify({'error': str(e)}), code


def _seed(app: Flask) -> None:
    """Load sample findings + run blocking initial clustering."""
    from app import storage
    from app.seed import SAMPLE_FINDINGS
    from app.services.clustering import run_clustering

    if not storage.findings_db:
        storage.findings_db.extend(SAMPLE_FINDINGS)
        run_clustering(background=False)


def create_app() -> Flask:
    app = Flask(
        __name__,
        static_folder=_os.path.join(_PROJECT_ROOT, 'static'),
        template_folder=_os.path.join(_PROJECT_ROOT, 'templates'),
    )

    _register_gzip(app)
    _register_error_handlers(app)

    from app.routes.pages import bp as pages_bp
    from app.routes.findings import bp as findings_bp
    from app.routes.clusters import bp as clusters_bp
    from app.routes.search import bp as search_bp
    from app.routes.llm import bp as llm_bp

    app.register_blueprint(pages_bp)
    app.register_blueprint(findings_bp)
    app.register_blueprint(clusters_bp)
    app.register_blueprint(search_bp)
    app.register_blueprint(llm_bp)

    _seed(app)
    return app
