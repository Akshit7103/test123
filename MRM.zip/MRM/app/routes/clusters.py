"""Clusters API."""
from flask import Blueprint, request, jsonify

from app import storage
from app.services.clustering import run_clustering

bp = Blueprint('clusters', __name__, url_prefix='/api/clusters')


@bp.route('', methods=['GET'])
def get_clusters():
    return jsonify(storage.clusters_db)


@bp.route('/status', methods=['GET'])
def clusters_status():
    return jsonify({'busy': storage.get_clustering_busy(), 'count': len(storage.clusters_db)})


@bp.route('/rerun', methods=['POST'])
def rerun_clustering():
    k = request.json.get('k') if request.json else None
    run_clustering(k, background=False)
    return jsonify({'status': 'ok', 'clusters': len(storage.clusters_db)})
