"""OpenAI proxy + diagnostic endpoints."""
from flask import Blueprint, request, jsonify

from app.services.openai_client import (
    is_openai_pkg_available,
    get_openai_client,
    classify_openai_exception,
    openai_model,
    try_openai_chat,
    get_log_lines,
)

bp = Blueprint('llm', __name__)


@bp.route('/api/llm-check', methods=['GET'])
def llm_check():
    if not is_openai_pkg_available():
        return jsonify({
            'reachable': False,
            'error': 'openai package is not installed (pip install -r requirements.txt)',
            'error_code': 'no_package',
            'model': openai_model(),
            'host': 'api.openai.com',
        })
    client, err, code = get_openai_client()
    if err:
        return jsonify({
            'reachable': False,
            'error': err,
            'error_code': code,
            'model': openai_model(),
            'host': 'api.openai.com',
        })
    try:
        models = client.models.list()
        names = sorted({getattr(m, 'id', '') for m in getattr(models, 'data', []) if getattr(m, 'id', '')})
        configured = openai_model()
        return jsonify({
            'reachable': True,
            'model': configured,
            'model_available': configured in names if names else None,
            'available_models': names[:80],
            'host': 'api.openai.com',
        })
    except Exception as e:
        cls = type(e).__name__
        return jsonify({
            'reachable': False,
            'error': f'{cls}: {e}',
            'error_code': classify_openai_exception(e),
            'model': openai_model(),
            'host': 'api.openai.com',
        })


@bp.route('/api/llm-logs', methods=['GET'])
def llm_logs():
    client, err, code = get_openai_client()
    status = 'ok' if (client and not err) else 'error'
    return jsonify({
        'lines': get_log_lines(),
        'status': status,
        'error': err,
        'error_code': code,
    })


@bp.route('/api/llm', methods=['POST'])
def llm_proxy():
    body = request.json or {}
    system_prompt = body.get('system', '')
    user_msg      = body.get('user', '')
    if not user_msg:
        return jsonify({'error': 'user message is required'}), 400

    messages = []
    if system_prompt:
        messages.append({'role': 'system', 'content': system_prompt})
    messages.append({'role': 'user', 'content': user_msg})

    text, err = try_openai_chat(messages)
    if text:
        return jsonify({'text': text, 'model': openai_model()})
    return jsonify({'error': err or 'Unknown OpenAI error'}), 502


# Backwards-compatible aliases
@bp.route('/api/ollama-check', methods=['GET'])
def _legacy_ollama_check():
    return llm_check()


@bp.route('/api/ollama-logs', methods=['GET'])
def _legacy_ollama_logs():
    return llm_logs()
