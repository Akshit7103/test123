"""Search + stats."""
from flask import Blueprint, request, jsonify

from app import storage
from app.services.search import search_query

bp = Blueprint('search', __name__)


@bp.route('/api/search', methods=['POST'])
def search():
    query = (request.json or {}).get('query', '')
    if not query:
        return jsonify({'error': 'Empty query'}), 400
    result = search_query(query)
    resp = jsonify(result)
    resp.headers['Cache-Control'] = 'no-store'
    return resp


@bp.route('/api/stats', methods=['GET'])
def stats():
    return jsonify({
        'total_findings': len(storage.findings_db),
        'total_clusters': len(storage.clusters_db),
    })


@bp.route('/api/stats/count', methods=['GET'])
def stats_count():
    resp = jsonify({
        'f': len(storage.findings_db),
        'c': len(storage.clusters_db),
        'busy': storage.get_clustering_busy(),
    })
    resp.headers['Cache-Control'] = 'no-store'
    return resp
