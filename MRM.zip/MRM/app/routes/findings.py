"""Findings CRUD + bulk import."""
import io

from flask import Blueprint, request, jsonify

from app import storage
from app.services.clustering import run_clustering

try:
    import pandas as pd
    import openpyxl  # noqa: F401
    _PANDAS_OK = True
except ImportError:
    _PANDAS_OK = False

bp = Blueprint('findings', __name__, url_prefix='/api/findings')


@bp.route('', methods=['GET'])
def get_findings():
    return jsonify(storage.findings_db)


@bp.route('', methods=['POST'])
def add_finding():
    data = request.json
    required = ['finding_id', 'title', 'description', 'business_justification']
    if not all(k in data for k in required):
        return jsonify({'error': 'Missing required fields: finding_id, title, description, business_justification'}), 400
    if any(f['finding_id'] == data['finding_id'] for f in storage.findings_db):
        return jsonify({'error': 'Finding ID already exists'}), 409
    record = {k: str(data[k]).strip() for k in required}
    record['model_theme'] = str(data['model_theme']).strip() if data.get('model_theme') else ''
    record['suggested_remediation'] = str(data['suggested_remediation']).strip() if data.get('suggested_remediation') else ''
    storage.findings_db.append(record)
    storage.invalidate_search_cache()
    storage.invalidate_tfidf_cache()
    run_clustering()
    return jsonify({'status': 'ok', 'total': len(storage.findings_db)}), 201


@bp.route('/bulk', methods=['POST'])
def bulk_findings():
    rows = request.json
    added, skipped = 0, 0
    for row in rows:
        required = ['finding_id', 'title', 'description', 'business_justification']
        if not all(k in row for k in required):
            skipped += 1
            continue
        if any(f['finding_id'] == row['finding_id'] for f in storage.findings_db):
            skipped += 1
            continue
        record = {k: str(row[k]).strip() for k in required}
        record['model_theme'] = str(row['model_theme']).strip() if row.get('model_theme') else ''
        record['suggested_remediation'] = str(row.get('suggested_remediation', '')).strip() if row.get('suggested_remediation') else ''
        storage.findings_db.append(record)
        added += 1
    storage.invalidate_search_cache()
    storage.invalidate_tfidf_cache()
    run_clustering()
    return jsonify({'added': added, 'skipped': skipped, 'total': len(storage.findings_db)})


@bp.route('/upload', methods=['POST'])
def upload_findings():
    """Accept an Excel (.xlsx) or CSV file and bulk-import findings."""
    if not _PANDAS_OK:
        return jsonify({'error': 'pandas/openpyxl not installed on this server'}), 500

    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    file = request.files['file']
    filename = (file.filename or '').lower()

    try:
        raw = file.read()
        if filename.endswith('.xlsx') or filename.endswith('.xls'):
            df = pd.read_excel(io.BytesIO(raw))
        elif filename.endswith('.csv'):
            df = pd.read_csv(io.BytesIO(raw))
        else:
            return jsonify({'error': 'Unsupported file type. Please upload .xlsx or .csv'}), 400
    except Exception as e:
        return jsonify({'error': f'Failed to parse file: {str(e)}'}), 400

    df.columns = [c.strip() for c in df.columns]

    col_map = {}
    for col in df.columns:
        key = col.lower().replace(' ', '_').replace('-', '_')
        col_map[key] = col

    def resolve(candidates):
        for c in candidates:
            if c in col_map:
                return col_map[c]
        return None

    finding_id_col    = resolve(['finding_id', 'findingid', 'finding_no', 'id'])
    model_theme_col   = resolve(['model_theme', 'modeltheme', 'theme'])
    title_col         = resolve(['title'])
    description_col   = resolve(['description', 'desc'])
    business_just_col = resolve(['business_justification', 'businessjustification', 'bj', 'justification'])
    remediation_col   = resolve(['suggested_remediation', 'remediation', 'suggestedremediation'])

    missing = [name for name, col in [
        ('Finding ID', finding_id_col),
        ('Title', title_col),
        ('Description', description_col),
        ('Business Justification', business_just_col),
    ] if col is None]

    if missing:
        return jsonify({
            'error': f'Required column(s) not found: {", ".join(missing)}. '
                     f'Expected headers: Finding ID, Model Theme, Title, Description, Business Justification. '
                     f'Found: {", ".join(df.columns.tolist())}'
        }), 400

    added, skipped = 0, 0
    for _, row in df.iterrows():
        fid   = str(row[finding_id_col]).strip()
        theme = str(row[model_theme_col]).strip() if model_theme_col and pd.notna(row.get(model_theme_col)) else ''
        title = str(row[title_col]).strip()
        desc  = str(row[description_col]).strip()
        bj    = str(row[business_just_col]).strip()
        rem   = str(row[remediation_col]).strip() if remediation_col and pd.notna(row.get(remediation_col)) else ''

        if not fid or not title or not desc or not bj or fid.lower() == 'nan':
            skipped += 1
            continue
        if any(f['finding_id'] == fid for f in storage.findings_db):
            skipped += 1
            continue

        storage.findings_db.append({
            'finding_id': fid,
            'model_theme': theme,
            'title': title,
            'description': desc,
            'business_justification': bj,
            'suggested_remediation': rem,
        })
        added += 1

    if added:
        storage.invalidate_search_cache()
        storage.invalidate_tfidf_cache()
        run_clustering()

    return jsonify({'added': added, 'skipped': skipped, 'total': len(storage.findings_db)})


@bp.route('/<fid>', methods=['DELETE'])
def delete_finding(fid):
    storage.findings_db[:] = [f for f in storage.findings_db if f['finding_id'] != fid]
    storage.invalidate_search_cache()
    storage.invalidate_tfidf_cache()
    run_clustering()
    return jsonify({'status': 'ok'})
