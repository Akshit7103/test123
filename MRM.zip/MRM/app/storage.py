"""In-memory state: findings, clusters, locks, caches."""
import threading

# Findings + clusters
findings_db = []
clusters_db = []

# Clustering thread state
_cluster_lock = threading.Lock()
_cluster_thread = None
_clustering_busy = False

# Pre-computed TF-IDF cache (rebuilt after every cluster run)
_tfidf_cache_lock = threading.Lock()
_tfidf_cache = None


def get_clustering_busy() -> bool:
    return _clustering_busy


def set_clustering_busy(value: bool) -> None:
    global _clustering_busy
    _clustering_busy = value


def set_cluster_thread(t):
    global _cluster_thread
    _cluster_thread = t


def get_tfidf_cache():
    with _tfidf_cache_lock:
        return _tfidf_cache


def set_tfidf_cache(cache):
    global _tfidf_cache
    with _tfidf_cache_lock:
        _tfidf_cache = cache


def invalidate_tfidf_cache() -> None:
    global _tfidf_cache
    with _tfidf_cache_lock:
        _tfidf_cache = None


# LRU search cache (cleared whenever findings/clusters change)
_search_cache = {}
_search_cache_lock = threading.Lock()
_SEARCH_CACHE_MAX = 128


def invalidate_search_cache() -> None:
    with _search_cache_lock:
        _search_cache.clear()


def search_cache_get(key):
    with _search_cache_lock:
        return _search_cache.get(key)


def search_cache_put(key, value):
    with _search_cache_lock:
        if len(_search_cache) >= _SEARCH_CACHE_MAX:
            old_keys = list(_search_cache.keys())[:_SEARCH_CACHE_MAX // 2]
            for k in old_keys:
                del _search_cache[k]
        _search_cache[key] = value
