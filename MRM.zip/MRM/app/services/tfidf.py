"""TF-IDF vectorizer + cosine helpers."""
import math
from collections import defaultdict


def build_tfidf(token_counts_list: list):
    """
    Build normalised TF-IDF vectors from pre-computed weighted token counts.
    Sublinear TF + smoothed IDF. Returns (matrix, vocab, word2idx).
    """
    N = len(token_counts_list)
    df = defaultdict(int)
    for tc in token_counts_list:
        for t in tc:
            df[t] += 1

    max_df = max(1, int(0.95 * N))
    vocab = [t for t, d in df.items() if 1 <= d <= max_df]
    word2idx = {w: i for i, w in enumerate(vocab)}
    V = len(vocab)

    vectors = []
    for tc in token_counts_list:
        vec = [0.0] * V
        for t, wcount in tc.items():
            idx = word2idx.get(t)
            if idx is None:
                continue
            tf = 1.0 + math.log(wcount) if wcount > 0 else 0.0
            idf = math.log((N + 1) / (df[t] + 1)) + 1.0
            vec[idx] = tf * idf
        norm = math.sqrt(sum(x * x for x in vec)) or 1.0
        vectors.append([x / norm for x in vec])
    return vectors, vocab, word2idx


def dot(a: list, b: list) -> float:
    return sum(a[i] * b[i] for i in range(len(a)))


def cosine_all(matrix: list, vec: list) -> list:
    return [dot(row, vec) for row in matrix]
