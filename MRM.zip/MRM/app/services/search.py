"""Search query: TF-IDF cosine match against findings + clusters."""
import math
from collections import defaultdict

from config import THEME_GROUPS
from app import storage
from app.services.tokenize import tokenize_with_bigrams, weighted_token_counts
from app.services.tfidf import build_tfidf, dot


def search_query(query: str) -> dict:
    if not storage.clusters_db or not storage.findings_db:
        return {'cluster': None, 'findings': [], 'score': 0}

    cached = storage.search_cache_get(query)
    if cached is not None:
        return cached

    raw_query_tokens = tokenize_with_bigrams(query)
    query_tc = {tok: 1.0 for tok in raw_query_tokens}

    for theme_key, theme_label in THEME_GROUPS.items():
        if any(part in query.lower() for part in theme_key.split()):
            for tok in tokenize_with_bigrams(theme_key + ' ' + theme_label):
                query_tc[tok] = query_tc.get(tok, 0) + 0.5

    cache_snap = storage.get_tfidf_cache()
    current_fids = [f['finding_id'] for f in storage.findings_db]
    if cache_snap and cache_snap['fid_snapshot'] == current_fids:
        doc_vecs   = cache_snap['vectors']
        word2idx   = cache_snap['word2idx']
        token_counts = cache_snap['token_counts']
        N = len(token_counts)
        df = defaultdict(int)
        for tc in token_counts:
            for t in tc:
                df[t] += 1
        V = len(word2idx)
        q_vec = [0.0] * V
        for t, wcount in query_tc.items():
            idx = word2idx.get(t)
            if idx is None:
                continue
            tf = 1.0 + math.log(wcount) if wcount > 0 else 0.0
            idf = math.log((N + 1) / (df.get(t, 0) + 1)) + 1.0
            q_vec[idx] = tf * idf
        norm = math.sqrt(sum(x * x for x in q_vec)) or 1.0
        q_vec = [x / norm for x in q_vec]
    else:
        all_tcs = [weighted_token_counts(f) for f in storage.findings_db] + [query_tc]
        vectors, _, _ = build_tfidf(all_tcs)
        q_vec    = vectors[-1]
        doc_vecs = vectors[:-1]

    sims = [(dot(q_vec, dv), i) for i, dv in enumerate(doc_vecs)]
    sims.sort(reverse=True)

    fid_to_sim = {storage.findings_db[i]['finding_id']: score for score, i in sims}
    best_cluster, best_avg = None, -1.0
    for c in storage.clusters_db:
        members = c['findings_included']
        if not members:
            continue
        avg = sum(fid_to_sim.get(fid, 0.0) for fid in members) / len(members)
        if avg > best_avg:
            best_avg, best_cluster = avg, c

    if best_cluster:
        fid_lookup = {f['finding_id']: f for f in storage.findings_db}
        cluster_findings = [
            (fid_to_sim.get(fid, 0.0), fid_lookup[fid])
            for fid in best_cluster['findings_included']
            if fid in fid_lookup
        ]
        cluster_findings.sort(reverse=True, key=lambda x: x[0])
        top_findings = [f for _, f in cluster_findings]
    else:
        top_findings = [storage.findings_db[i] for _, i in sims[:5]]

    result = {
        'cluster': best_cluster,
        'findings': top_findings,
        'score': round(sims[0][0], 3) if sims else 0,
    }
    storage.search_cache_put(query, result)
    return result
