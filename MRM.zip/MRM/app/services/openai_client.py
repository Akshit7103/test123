"""OpenAI client wrapper, error classification, and log ring buffer."""
import collections
import datetime
import os
import threading

try:
    from openai import OpenAI as _OpenAI
    _OPENAI_PKG_OK = True
except ImportError:
    _OPENAI_PKG_OK = False
    _OpenAI = None


_log_lock = threading.Lock()
_log_buffer = collections.deque(maxlen=200)


def _log(msg: str):
    ts = datetime.datetime.now().strftime('%H:%M:%S')
    line = f'[{ts}] {msg}'
    with _log_lock:
        _log_buffer.append(line)


def get_log_lines():
    with _log_lock:
        return list(_log_buffer)


def is_openai_pkg_available() -> bool:
    return _OPENAI_PKG_OK


_openai_client_lock = threading.Lock()
_openai_client = None
_openai_client_key_fingerprint = None


def openai_model() -> str:
    return os.environ.get('OPENAI_MODEL', 'gpt-4o-mini').strip() or 'gpt-4o-mini'


def _openai_api_key() -> str:
    return os.environ.get('OPENAI_API_KEY', '').strip()


def _is_placeholder_key(key: str) -> bool:
    if not key:
        return True
    low = key.lower()
    return low.startswith('sk-your') or low in {'sk-...', 'changeme', 'placeholder'}


def get_openai_client():
    """
    Return (client, None, None) on success or (None, error_message, error_code).
    Codes: no_package | no_key | placeholder.
    """
    global _openai_client, _openai_client_key_fingerprint
    if not _OPENAI_PKG_OK:
        return None, 'The "openai" package is not installed. Run: pip install -r requirements.txt', 'no_package'
    api_key = _openai_api_key()
    if not api_key:
        return None, 'OPENAI_API_KEY is not set. Add your key to the .env file in the project root.', 'no_key'
    if _is_placeholder_key(api_key):
        return None, 'OPENAI_API_KEY is still a placeholder. Replace it with your real key in .env.', 'placeholder'
    fingerprint = api_key[-6:] if len(api_key) >= 6 else api_key
    with _openai_client_lock:
        if _openai_client is None or _openai_client_key_fingerprint != fingerprint:
            _openai_client = _OpenAI(api_key=api_key)
            _openai_client_key_fingerprint = fingerprint
    return _openai_client, None, None


def classify_openai_exception(exc) -> str:
    cls = type(exc).__name__
    msg = str(exc).lower()
    if 'Authentication' in cls or 'invalid_api_key' in msg:
        return 'auth'
    if 'RateLimit' in cls or 'insufficient_quota' in msg:
        return 'rate_limit'
    if 'Timeout' in cls:
        return 'timeout'
    if 'Connection' in cls:
        return 'connection'
    if 'NotFound' in cls or 'model_not_found' in msg:
        return 'model_not_found'
    return 'api_error'


def try_openai_chat(messages, timeout: float = 90.0):
    """
    Returns (text, None) on success or (None, error_string) on failure.
    """
    client, err, _code = get_openai_client()
    if err:
        _log(f'CONFIG_ERR {err}')
        return None, err

    model = openai_model()
    _log(f'REQUEST  model={model}  msgs={len(messages)}')
    try:
        resp = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=0.3,
            max_tokens=900,
            timeout=timeout,
        )
    except Exception as e:
        cls = type(e).__name__
        msg = str(e)
        code = classify_openai_exception(e)
        _log(f'API_ERR  [{code}] {cls}: {msg[:160]}')
        if code == 'auth':
            return None, 'OpenAI rejected the API key. Check OPENAI_API_KEY in .env.'
        if code == 'rate_limit':
            return None, 'OpenAI rate limit hit (or quota exceeded). Wait or check billing.'
        if code == 'timeout':
            return None, f'OpenAI request timed out after {timeout}s.'
        if code == 'connection':
            return None, 'Cannot reach OpenAI. Check your network connection.'
        if code == 'model_not_found':
            return None, f'Model "{model}" is not available on this account. Set OPENAI_MODEL in .env to a model your key can access.'
        return None, f'{cls}: {msg}'

    if not getattr(resp, 'choices', None):
        _log('EMPTY    no choices in response')
        return None, 'OpenAI returned an empty response.'
    text = (resp.choices[0].message.content or '').strip()
    if not text:
        _log('EMPTY    empty content')
        return None, 'OpenAI returned an empty response.'

    usage = getattr(resp, 'usage', None)
    stats = ''
    if usage:
        stats = f'  [prompt={usage.prompt_tokens}, completion={usage.completion_tokens}, total={usage.total_tokens}]'
    _log(f'OK       {len(text)} chars{stats}')
    return text, None
