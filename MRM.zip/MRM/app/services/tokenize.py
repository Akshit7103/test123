"""Tokenizers and weighted token counts."""
import re
from collections import defaultdict

from config import STOP_WORDS, THEME_GROUPS, FIELD_WEIGHTS


def bigrams(tokens: list) -> list:
    return [f"{tokens[i]}_{tokens[i+1]}" for i in range(len(tokens) - 1)]


def normalize_theme(theme: str) -> str:
    if not theme:
        return ''
    return THEME_GROUPS.get(theme.lower().strip(), theme.lower().strip())


def tokenize(text: str) -> list:
    """Lowercase, extract alpha tokens >=3 chars, remove stop-words."""
    tokens = re.findall(r'\b[a-z][a-z\-]{2,}\b', text.lower())
    return [t for t in tokens if t not in STOP_WORDS]


def tokenize_with_bigrams(text: str) -> list:
    """Return unigrams + bigrams -- richer semantic signal."""
    uni = tokenize(text)
    bi = [f"{uni[i]}_{uni[i+1]}" for i in range(len(uni) - 1)]
    return uni + bi


def weighted_token_counts(finding: dict) -> dict:
    counts = defaultdict(float)
    for field, weight in FIELD_WEIGHTS.items():
        val = finding.get(field, '') or ''
        for tok in tokenize_with_bigrams(val):
            counts[tok] += weight
    return counts
