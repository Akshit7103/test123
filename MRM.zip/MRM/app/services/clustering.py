"""Clustering: k-means, bisecting, auto-k, label generation, run_clustering."""
import math
import threading
from collections import defaultdict

from app import storage
from app.services.tokenize import (
    weighted_token_counts, normalize_theme, tokenize_with_bigrams,
)
from app.services.tfidf import build_tfidf, dot, cosine_all


def kmeans(vectors: list, k: int, max_iter: int = 100, n_restarts: int = 3, seed: int = 42):
    import random
    n = len(vectors)
    if n == 0:
        return [], []
    k = min(k, n)
    V = len(vectors[0])

    best_labels, best_inertia = None, float('inf')

    for restart in range(n_restarts):
        rng = random.Random(seed + restart * 31)

        first = rng.randint(0, n - 1)
        centroids = [vectors[first][:]]
        for _ in range(k - 1):
            sims = [max(dot(v, c) for c in centroids) for v in vectors]
            dists = [max(0.0, 1.0 - s) ** 2 for s in sims]
            total = sum(dists) or 1.0
            r, cum = rng.random() * total, 0.0
            chosen = n - 1
            for i, d in enumerate(dists):
                cum += d
                if cum >= r:
                    chosen = i
                    break
            centroids.append(vectors[chosen][:])

        labels = [0] * n
        for _ in range(max_iter):
            new_labels = []
            for v in vectors:
                sims = cosine_all(centroids, v)
                new_labels.append(sims.index(max(sims)))
            if new_labels == labels:
                break
            labels = new_labels

            for j in range(k):
                members = [vectors[i] for i, lbl in enumerate(labels) if lbl == j]
                if not members:
                    farthest = max(range(n), key=lambda i: 1.0 - dot(vectors[i], centroids[labels[i]]))
                    centroids[j] = vectors[farthest][:]
                    continue
                c = [sum(members[m][d] for m in range(len(members))) / len(members) for d in range(V)]
                norm = math.sqrt(sum(x * x for x in c)) or 1.0
                centroids[j] = [x / norm for x in c]

        inertia = sum(1.0 - dot(vectors[i], centroids[labels[i]]) for i in range(n))
        if inertia < best_inertia:
            best_inertia, best_labels = inertia, labels[:]

    return best_labels, None


def bisecting_kmeans(vectors: list, k: int, seed: int = 42):
    n = len(vectors)
    if n == 0:
        return [], []
    k = min(k, n)
    V = len(vectors[0])

    clusters = [list(range(n))]

    def inertia_of(idx_list):
        if len(idx_list) <= 1:
            return 0.0
        vecs = [vectors[i] for i in idx_list]
        c = [sum(v[d] for v in vecs) / len(vecs) for d in range(V)]
        norm = math.sqrt(sum(x * x for x in c)) or 1.0
        c = [x / norm for x in c]
        return sum(1.0 - dot(vectors[i], c) for i in idx_list)

    while len(clusters) < k:
        target_idx = max(range(len(clusters)), key=lambda j: inertia_of(clusters[j]))
        target = clusters[target_idx]
        if len(target) < 2:
            break

        sub_vecs = [vectors[i] for i in target]
        lbls, _ = kmeans(sub_vecs, 2, max_iter=50, n_restarts=2, seed=seed + len(clusters) * 17)
        if not lbls:
            break

        group_a = [target[i] for i, l in enumerate(lbls) if l == 0]
        group_b = [target[i] for i, l in enumerate(lbls) if l == 1]
        if not group_a or not group_b:
            break

        clusters.pop(target_idx)
        clusters.extend([group_a, group_b])

    labels = [0] * n
    for lbl, idx_list in enumerate(clusters):
        for i in idx_list:
            labels[i] = lbl
    return labels, clusters


def _silhouette_score(vectors: list, labels: list, k: int, max_sample: int = 200) -> float:
    import random
    n = len(vectors)
    if k <= 1 or n <= k:
        return -1.0

    cluster_members = defaultdict(list)
    for i, l in enumerate(labels):
        cluster_members[l].append(i)

    indices = list(range(n))
    if n > max_sample:
        random.seed(7)
        indices = random.sample(indices, max_sample)

    scores = []
    for i in indices:
        lbl = labels[i]
        same = [j for j in cluster_members[lbl] if j != i]
        if not same:
            scores.append(0.0)
            continue
        a = sum(1.0 - dot(vectors[i], vectors[j]) for j in same) / len(same)
        b_vals = [
            sum(1.0 - dot(vectors[i], vectors[j]) for j in members) / len(members)
            for other_lbl, members in cluster_members.items()
            if other_lbl != lbl and members
        ]
        b = min(b_vals) if b_vals else 0.0
        denom = max(a, b)
        scores.append((b - a) / denom if denom else 0.0)

    return sum(scores) / len(scores) if scores else -1.0


def _inertia(vectors: list, labels: list) -> float:
    V = len(vectors[0]) if vectors else 0
    cluster_members = defaultdict(list)
    for i, l in enumerate(labels):
        cluster_members[l].append(i)
    total = 0.0
    for members in cluster_members.values():
        if not members:
            continue
        vecs = [vectors[i] for i in members]
        c = [sum(v[d] for v in vecs) / len(vecs) for d in range(V)]
        norm = math.sqrt(sum(x * x for x in c)) or 1.0
        c = [x / norm for x in c]
        total += sum(1.0 - dot(vectors[i], c) for i in members)
    return total


def _gap_statistic(vectors: list, k_min: int, k_max: int,
                   n_refs: int = 5, seed: int = 42) -> list:
    import random
    rng = random.Random(seed)
    n = len(vectors)
    V = len(vectors[0]) if vectors else 1

    actual_log_w = {}
    prev_clusters = [list(range(n))]
    for k in range(2, k_max + 1):
        while len(prev_clusters) < k:
            def _inertia_of(idx_list, _V=V):
                if len(idx_list) <= 1:
                    return 0.0
                vecs = [vectors[i] for i in idx_list]
                c = [sum(v[d] for v in vecs) / len(vecs) for d in range(_V)]
                norm = math.sqrt(sum(x * x for x in c)) or 1.0
                c = [x / norm for x in c]
                return sum(1.0 - dot(vectors[i], c) for i in idx_list)

            tidx = max(range(len(prev_clusters)), key=lambda j: _inertia_of(prev_clusters[j]))
            tgt = prev_clusters[tidx]
            if len(tgt) < 2:
                break
            sub = [vectors[i] for i in tgt]
            lbls, _ = kmeans(sub, 2, max_iter=50, n_restarts=2, seed=seed + len(prev_clusters) * 17)
            if not lbls:
                break
            ga = [tgt[i] for i, l in enumerate(lbls) if l == 0]
            gb = [tgt[i] for i, l in enumerate(lbls) if l == 1]
            if not ga or not gb:
                break
            prev_clusters.pop(tidx)
            prev_clusters.extend([ga, gb])

        if len(prev_clusters) >= k:
            labels = [0] * n
            for lbl, idx_list in enumerate(prev_clusters):
                for i in idx_list:
                    labels[i] = lbl
            w = _inertia(vectors, labels)
            actual_log_w[k] = math.log(w + 1e-10)

    bounds = [(min(v[d] for v in vectors), max(v[d] for v in vectors)) for d in range(V)]

    results = []
    for k in range(k_min, k_max + 1):
        if k not in actual_log_w:
            continue
        ref_log_ws = []
        for b in range(n_refs):
            ref = [[rng.uniform(lo, hi) for lo, hi in bounds] for _ in range(n)]
            ref_norm = []
            for rv in ref:
                nm = math.sqrt(sum(x * x for x in rv)) or 1.0
                ref_norm.append([x / nm for x in rv])
            rlbls, _ = bisecting_kmeans(ref_norm, k, seed=seed + b * 97 + k * 13)
            if not rlbls:
                rlbls = [0] * n
            ref_log_ws.append(math.log(_inertia(ref_norm, rlbls) + 1e-10))
        e_log_w = sum(ref_log_ws) / len(ref_log_ws)
        sdk = math.sqrt(sum((x - e_log_w) ** 2 for x in ref_log_ws) / len(ref_log_ws))
        sdk *= math.sqrt(1 + 1.0 / n_refs)
        gap = e_log_w - actual_log_w[k]
        results.append((k, gap, sdk))

    return results


def _auto_select_k(vectors: list, n: int, theme_count: int, findings: list = None) -> int:
    if n <= 2:
        return 1
    if n <= 3:
        return 2

    k_min = 2
    if n <= 10:
        k_max = min(n - 1, 6)
    elif n <= 30:
        k_max = min(n // 2, 10)
    elif n <= 100:
        k_max = min(n // 4, 15)
    else:
        k_max = min(n // 8, 25)

    k_max = max(k_max, k_min + 1)

    sil_scores = {}
    prev_clusters = [list(range(n))]
    V = len(vectors[0]) if vectors else 1

    for k in range(k_min, k_max + 1):
        while len(prev_clusters) < k:
            def _io(idx_list, _V=V):
                if len(idx_list) <= 1:
                    return 0.0
                vecs = [vectors[i] for i in idx_list]
                c = [sum(v[d] for v in vecs) / len(vecs) for d in range(_V)]
                nm = math.sqrt(sum(x * x for x in c)) or 1.0
                c = [x / nm for x in c]
                return sum(1.0 - dot(vectors[i], c) for i in idx_list)

            tidx = max(range(len(prev_clusters)), key=lambda j: _io(prev_clusters[j]))
            tgt = prev_clusters[tidx]
            if len(tgt) < 2:
                break
            sub = [vectors[i] for i in tgt]
            lbls, _ = kmeans(sub, 2, max_iter=50, n_restarts=2, seed=42 + len(prev_clusters) * 17)
            if not lbls:
                break
            ga = [tgt[i] for i, l in enumerate(lbls) if l == 0]
            gb = [tgt[i] for i, l in enumerate(lbls) if l == 1]
            if not ga or not gb:
                break
            prev_clusters.pop(tidx)
            prev_clusters.extend([ga, gb])

        if len(prev_clusters) < k:
            break
        labels = [0] * n
        for lbl, idx_list in enumerate(prev_clusters):
            for i in idx_list:
                labels[i] = lbl
        sil_scores[k] = _silhouette_score(vectors, labels, k)

    if not sil_scores:
        return k_min

    gap_results = _gap_statistic(vectors, k_min, k_max, n_refs=5)
    gap_map = {k: (gap, sdk) for k, gap, sdk in gap_results}

    gap_k = k_min
    for k, gap, sdk in gap_results[:-1]:
        next_k, next_gap, next_sdk = gap_results[gap_results.index((k, gap, sdk)) + 1]
        if gap >= next_gap - next_sdk:
            gap_k = k
            break
    else:
        if gap_results:
            gap_k = max(gap_results, key=lambda x: x[1])[0]

    all_gaps = [g for _, g, _ in gap_results]
    g_min, g_max = min(all_gaps), max(all_gaps)
    g_range = (g_max - g_min) or 1.0

    best_k, best_score = k_min, -float('inf')
    for k in sil_scores:
        if k not in gap_map:
            continue
        gap_norm = (gap_map[k][0] - g_min) / g_range
        sil = sil_scores[k]
        score = 0.55 * gap_norm + 0.45 * sil - 0.002 * k
        if score > best_score:
            best_score, best_k = score, k

    if gap_k in sil_scores and gap_k in gap_map:
        gap_norm = (gap_map[gap_k][0] - g_min) / g_range
        gap_k_score = 0.55 * gap_norm + 0.45 * sil_scores[gap_k] - 0.002 * gap_k
        best_norm = (gap_map[best_k][0] - g_min) / g_range
        best_score_val = 0.55 * best_norm + 0.45 * sil_scores.get(best_k, 0) - 0.002 * best_k
        if abs(gap_k_score - best_score_val) < 0.05:
            best_k = gap_k

    return best_k


def _cluster_label(fids: list, all_clusters_fids: list) -> str:
    fid_set = {f['finding_id']: f for f in storage.findings_db}
    themes = []
    for fid in fids:
        f = fid_set.get(fid)
        if f and f.get('model_theme'):
            themes.append(normalize_theme(f['model_theme']))
    dominant_theme = ''
    if themes:
        dominant_theme = max(set(themes), key=themes.count)
        dominant_theme = dominant_theme.replace('_', ' ').title()

    freq_in = defaultdict(float)
    for fid in fids:
        f = fid_set.get(fid)
        if not f:
            continue
        tc = weighted_token_counts(f)
        for tok, wc in tc.items():
            if '_' in tok and not tok.endswith('_seed'):
                freq_in[tok] += wc

    all_fids_flat = [fid for cluster in all_clusters_fids for fid in cluster]
    freq_all = defaultdict(float)
    for fid in all_fids_flat:
        f = fid_set.get(fid)
        if not f:
            continue
        tc = weighted_token_counts(f)
        for tok, wc in tc.items():
            if '_' in tok and not tok.endswith('_seed'):
                freq_all[tok] += wc

    n_clusters = max(1, len(all_clusters_fids))
    tfidf_bigrams = {}
    for tok, freq in freq_in.items():
        tf = freq / max(1, len(fids))
        idf = math.log(n_clusters / max(1, sum(1 for cl in all_clusters_fids
                                                if any(weighted_token_counts(fid_set.get(fid, {})).get(tok, 0) > 0
                                                       for fid in cl))))
        tfidf_bigrams[tok] = tf * idf

    top_bi = sorted(tfidf_bigrams, key=lambda x: -tfidf_bigrams[x])[:2]
    phrase = ', '.join(t.replace('_', ' ') for t in top_bi)

    if dominant_theme and phrase:
        return f"{dominant_theme}: {phrase}"
    elif dominant_theme:
        return dominant_theme
    return phrase or 'Mixed'


def _top_signals(fids: list) -> str:
    freq = defaultdict(float)
    fid_set = {f['finding_id']: f for f in storage.findings_db}
    for fid in fids:
        f = fid_set.get(fid)
        if not f:
            continue
        tc = weighted_token_counts(f)
        for tok, wc in tc.items():
            if not tok.endswith('_seed'):
                freq[tok] += wc
    bigram_tokens = sorted(
        [t for t in freq if '_' in t], key=lambda x: -freq[x])[:6]
    unigram_tokens = sorted(
        [t for t in freq if '_' not in t], key=lambda x: -freq[x])[:6]
    top = bigram_tokens + [u for u in unigram_tokens if u not in bigram_tokens]
    return ', '.join(t.replace('_', ' ') for t in top[:12])


def _generate_why(fids: list, label: str = '') -> str:
    themes = []
    fid_set = {f['finding_id']: f for f in storage.findings_db}
    for fid in fids:
        f = fid_set.get(fid)
        if f and f.get('model_theme'):
            themes.append(f['model_theme'])
    theme_str = ''
    if themes:
        unique = list(dict.fromkeys(themes))
        theme_str = f" under the theme(s): {', '.join(unique)}."
    label_str = f" Semantic label: '{label}'." if label else ''
    return (
        f"Findings {', '.join(fids)} share overlapping vocabulary and risk focus"
        f"{theme_str}{label_str} Gap Statistic + Silhouette auto-k selection on sublinear TF-IDF vectors "
        "(description×8 + business justification×7 + title×1 + remediation×1 + model_theme×2, "
        "with bigrams) detected strong semantic similarity purely from finding content."
    )


def _prewarm_tfidf_cache():
    if not storage.findings_db:
        return
    token_counts = [weighted_token_counts(f) for f in storage.findings_db]
    vectors, vocab, word2idx = build_tfidf(token_counts)
    snapshot = [f['finding_id'] for f in storage.findings_db]
    storage.set_tfidf_cache({
        'vectors': vectors,
        'vocab': vocab,
        'word2idx': word2idx,
        'token_counts': token_counts,
        'fid_snapshot': snapshot,
    })


def _do_clustering(k: int = None):
    storage.set_clustering_busy(True)
    try:
        if not storage.findings_db:
            with storage._cluster_lock:
                storage.clusters_db[:] = []
            return

        n = len(storage.findings_db)

        token_counts = [weighted_token_counts(f) for f in storage.findings_db]
        vectors, vocab, word2idx = build_tfidf(token_counts)

        theme_set = set()
        for f in storage.findings_db:
            t = normalize_theme(f.get('model_theme', ''))
            if t:
                theme_set.add(t)
        theme_count = len(theme_set)

        if k is None:
            k = _auto_select_k(vectors, n, theme_count, storage.findings_db)
        k = min(k, n)

        labels, _ = bisecting_kmeans(vectors, k)
        if not labels:
            labels, _ = kmeans(vectors, k)

        cluster_map = defaultdict(list)
        for i, label in enumerate(labels):
            cluster_map[label].append(storage.findings_db[i]['finding_id'])

        theme_order = ['data_quality', 'documentation', 'governance',
                       'methodology', 'performance_monitoring', 'implementation', 'model_validation']
        fid_lookup = {f['finding_id']: f for f in storage.findings_db}

        def theme_sort_key(fids):
            counts = defaultdict(int)
            for fid in fids:
                f = fid_lookup.get(fid)
                if f:
                    counts[normalize_theme(f.get('model_theme', ''))] += 1
            dominant = max(counts, key=counts.get) if counts else ''
            try:
                return theme_order.index(dominant)
            except ValueError:
                return 99

        sorted_clusters = sorted(cluster_map.values(), key=theme_sort_key)
        all_clusters_fids = list(sorted_clusters)

        new_clusters = []
        for idx, fids in enumerate(sorted_clusters):
            label = _cluster_label(fids, all_clusters_fids)
            new_clusters.append({
                'cluster_id': f"C{idx + 1}",
                'findings_included': fids,
                'why_grouped': _generate_why(fids, label),
                'semantic_signals': _top_signals(fids),
                'semantic_label': label,
                'size': len(fids),
            })

        with storage._cluster_lock:
            storage.clusters_db[:] = new_clusters

        _prewarm_tfidf_cache()
        storage.invalidate_search_cache()
    finally:
        storage.set_clustering_busy(False)


def run_clustering(k: int = None, background: bool = True):
    if not background:
        _do_clustering(k)
        return
    t = threading.Thread(target=_do_clustering, args=(k,), daemon=True)
    storage.set_cluster_thread(t)
    t.start()
