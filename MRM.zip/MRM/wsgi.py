"""WSGI entry point. Use `gunicorn wsgi:app` in production, or `python wsgi.py` in dev."""
from app import create_app

app = create_app()


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000, use_reloader=False)
