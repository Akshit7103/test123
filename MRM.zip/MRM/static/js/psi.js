
// ═══════════════════════════════════════════════════════════════════════════
// ── PSI Calculator ────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════

const PSI_DEFAULT_ROWS = [
  { band: 'Low Risk (750+)',       dev: 20, cur: 10 },
  { band: 'Medium Risk (650–750)', dev: 40, cur: 35 },
  { band: 'High Risk (550–650)',   dev: 25, cur: 30 },
  { band: 'Very High Risk (<550)', dev: 15, cur: 25 },
];

let _psiBarChart    = null;

function psiInitTable() {
  const tbody = document.getElementById('psi-input-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  PSI_DEFAULT_ROWS.forEach(r => psiAddRowData(r.band, r.dev, r.cur));
  psiUpdateTotals();
}

function psiAddRow() { psiAddRowData('', 0, 0); psiUpdateTotals(); }

function psiAddRowData(band, dev, cur) {
  const tbody = document.getElementById('psi-input-tbody');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td style="text-align:center;vertical-align:middle">
      <button onclick="psiRemoveRow(this)" style="background:none;border:none;cursor:pointer;color:var(--muted);padding:2px 6px;border-radius:4px;font-size:13px;line-height:1;transition:color .15s" onmouseover="this.style.color='var(--accent)'" onmouseout="this.style.color='var(--muted)'">✕</button>
    </td>
    <td>
      <input type="text" value="${band}" placeholder="e.g. Low Risk (750+)"
        style="width:100%;border:none;background:transparent;font-size:14px;color:var(--text);font-family:var(--font-sans);outline:none;padding:4px 2px;border-radius:4px"
        oninput="psiUpdateTotals()" onfocus="this.style.background='var(--bg)'" onblur="this.style.background='transparent'"/>
    </td>
    <td style="text-align:center;vertical-align:middle">
      <div style="display:flex;align-items:center;justify-content:center;gap:4px">
        <input type="number" value="${dev}" min="0" max="100" step="0.01"
          style="width:80px;text-align:center;border:1px solid var(--border);border-radius:5px;padding:7px 8px;font-family:var(--font-mono);font-size:14px;font-weight:600;color:var(--primary);outline:none;transition:border-color .2s"
          oninput="psiUpdateTotals()" onfocus="this.style.borderColor='var(--primary-light)'" onblur="this.style.borderColor='var(--border)'"/>
        <span style="font-size:13px;color:var(--muted)">%</span>
      </div>
    </td>
    <td style="text-align:center;vertical-align:middle">
      <div style="display:flex;align-items:center;justify-content:center;gap:4px">
        <input type="number" value="${cur}" min="0" max="100" step="0.01"
          style="width:80px;text-align:center;border:1px solid var(--border);border-radius:5px;padding:7px 8px;font-family:var(--font-mono);font-size:14px;font-weight:600;color:var(--accent);outline:none;transition:border-color .2s"
          oninput="psiUpdateTotals()" onfocus="this.style.borderColor='var(--accent)'" onblur="this.style.borderColor='var(--border)'"/>
        <span style="font-size:13px;color:var(--muted)">%</span>
      </div>
    </td>`;
  tbody.appendChild(tr);
}

function psiRemoveRow(btn) { btn.closest('tr').remove(); psiUpdateTotals(); }

function psiGetRows() {
  const rows = [];
  for (const tr of document.getElementById('psi-input-tbody').rows) {
    const inputs = tr.querySelectorAll('input');
    rows.push({
      band: inputs[0].value.trim() || `Band ${rows.length + 1}`,
      dev:  parseFloat(inputs[1].value) || 0,
      cur:  parseFloat(inputs[2].value) || 0,
    });
  }
  return rows;
}

function psiUpdateTotals() {
  const rows = psiGetRows();
  const devT = rows.reduce((s, r) => s + r.dev, 0);
  const curT = rows.reduce((s, r) => s + r.cur, 0);
  const fmt = (v, el) => {
    el.textContent = v.toFixed(1) + '%';
    el.style.color = Math.abs(v - 100) < 0.01 ? 'var(--success)' : Math.abs(v - 100) < 5 ? 'var(--warn)' : 'var(--accent)';
  };
  fmt(devT, document.getElementById('psi-dev-total'));
  fmt(curT, document.getElementById('psi-cur-total'));
}

function psiReset() {
  document.getElementById('psi-result-zone').style.display = 'none';
  if (_psiBarChart)     { _psiBarChart.destroy();     _psiBarChart = null; }
  psiInitTable();
}

// ── RAG config ────────────────────────────────────────────────────────────
const PSI_RAG = {
  green: { color:'#38A169', bg:'linear-gradient(135deg,#276749,#2F855A)', label:'Green',
           msg:'No significant population shift detected. Model is stable.', icon:'✓' },
  amber: { color:'#D69E2E', bg:'linear-gradient(135deg,#744210,#975A16)', label:'Amber',
           msg:'Moderate population shift detected. Monitor closely and investigate root causes.', icon:'⚠' },
  red:   { color:'#E53E3E', bg:'linear-gradient(135deg,#742A2A,#9B2C2C)', label:'Red',
           msg:'Significant population shift. Model likely requires recalibration or redevelopment.', icon:'✕' },
};

function psiGetRAG(psi) {
  return psi < 0.10 ? PSI_RAG.green : psi <= 0.25 ? PSI_RAG.amber : PSI_RAG.red;
}
function psiGetRAGKey(psi) { return psi < 0.10 ? 'green' : psi <= 0.25 ? 'amber' : 'red'; }

// ── Main calculation ──────────────────────────────────────────────────────
function calcPSI() {
  const rows  = psiGetRows();
  const FLOOR = 0.0001;
  const devT  = rows.reduce((s, r) => s + r.dev, 0);
  const curT  = rows.reduce((s, r) => s + r.cur, 0);

  if (!devT || !curT) { showAlert('All values are zero — cannot compute PSI.', 'error'); return; }

  const ePct = rows.map(r => Math.max(r.dev / devT, FLOOR));
  const aPct = rows.map(r => Math.max(r.cur / curT, FLOOR));
  const contribs = ePct.map((e, i) => (aPct[i] - e) * Math.log(aPct[i] / e));
  const psi = contribs.reduce((s, v) => s + v, 0);
  const rag = psiGetRAG(psi);
  const ragKey = psiGetRAGKey(psi);

  // ── Result Box ────────────────────────────────────────────────────────
  const box = document.getElementById('psi-result-box');
  box.style.background = rag.bg;
  document.getElementById('psi-value-display').textContent = psi.toFixed(4);
  document.getElementById('psi-result-icon').innerHTML =
    `<span style="font-size:36px;filter:drop-shadow(0 2px 4px rgba(0,0,0,.2))">${rag.icon}</span>`;
  document.getElementById('psi-rag-dot').style.background = rag.color;
  document.getElementById('psi-rag-label').textContent = rag.label;
  document.getElementById('psi-rag-msg').textContent = rag.msg;

  // ── Highlight active threshold pill ──────────────────────────────────
  ['green','amber','red'].forEach(k => {
    const pill = document.getElementById('psi-pill-' + k);
    if (!pill) return;
    if (k === ragKey) {
      pill.style.background = k==='green' ? 'rgba(104,211,145,.22)' : k==='amber' ? 'rgba(246,224,94,.18)' : 'rgba(252,129,129,.18)';
      pill.style.boxShadow = '0 2px 12px rgba(0,0,0,.15)';
      pill.style.transform = 'none';
    } else {
      pill.style.background = 'rgba(255,255,255,.05)';
      pill.style.boxShadow = 'none';
      pill.style.opacity = '0.45';
    }
  });

  const labels   = rows.map(r => r.band);
  const devVals  = rows.map(r => parseFloat(r.dev.toFixed(2)));
  const curVals  = rows.map(r => parseFloat(r.cur.toFixed(2)));

  // Destroy old instances
  if (_psiBarChart) { _psiBarChart.destroy(); _psiBarChart = null; }

  // Grouped bar — Dev Population vs Live Population
  const barCtx = document.getElementById('psi-bar-chart').getContext('2d');
  _psiBarChart = new Chart(barCtx, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        { label: 'Dev Population (%)', data: devVals,
          backgroundColor: 'rgba(0,94,124,0.78)', borderColor: '#005E7C', borderWidth: 1.5, borderRadius: 4, borderSkipped: false },
        { label: 'Live Population (%)', data: curVals,
          backgroundColor: 'rgba(234,108,54,0.78)', borderColor: '#EA6C36', borderWidth: 1.5, borderRadius: 4, borderSkipped: false },
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      layout: { padding: { top: 8, right: 16, bottom: 0, left: 0 } },
      plugins: {
        legend: { display: false },
        tooltip: { mode:'index', intersect:false,
          callbacks:{ label: ctx => ` ${ctx.dataset.label}: ${ctx.raw}%` } }
      },
      scales: {
        x: { grid:{display:false}, ticks:{font:{size:10}, maxRotation:30, autoSkip:false} },
        y: {
          min: 0,
          max: Math.min(100, Math.max(...devVals, ...curVals) + 10),
          beginAtZero: true,
          ticks:{ callback: v => v+'%', font:{size:11}, stepSize:10 },
          grid:{ color:'rgba(0,0,0,.05)' }
        }
      }
    }
  });

  // ── Breakdown table ──────────────────────────────────────────────────
  document.getElementById('psi-result-tbody').innerHTML = rows.map((r, i) => {
    const eP    = (ePct[i] * 100).toFixed(2);
    const aP    = (aPct[i] * 100).toFixed(2);
    const delta = (aPct[i] - ePct[i]) * 100;
    const lnR   = Math.log(aPct[i] / ePct[i]);
    const con   = contribs[i];
    const pct   = ((con / psi) * 100).toFixed(1);
    const dSign = delta >= 0 ? '+' : '';
    const conColor = con > 0.05 ? '#C53030' : con > 0.02 ? '#B45309' : '#0C7A40';
    const conBg    = con > 0.05 ? '#FFF5F5' : con > 0.02 ? '#FFFBEB' : '#F0FFF4';
    const rowBg    = i % 2 === 0 ? '#fff' : '#FAFBFF';
    return `<tr style="background:${rowBg}">
      <td style="padding:12px 18px;font-weight:700;color:var(--text);font-size:13px;border-bottom:1px solid var(--border)">${r.band}</td>
      <td style="padding:12px 18px;font-family:var(--font-mono);text-align:center;color:#005E7C;font-weight:700;font-size:13px;border-bottom:1px solid var(--border)">${eP}%</td>
      <td style="padding:12px 18px;font-family:var(--font-mono);text-align:center;color:#C05621;font-weight:700;font-size:13px;border-bottom:1px solid var(--border)">${aP}%</td>
      <td style="padding:12px 18px;font-family:var(--font-mono);text-align:center;font-weight:600;font-size:13px;color:${delta>=0?'#276749':'#9B2C2C'};border-bottom:1px solid var(--border)">
        <span style="background:${delta>=0?'#F0FFF4':'#FFF5F5'};border:1px solid ${delta>=0?'#B3DECA':'#FEB2B2'};border-radius:5px;padding:3px 9px">${dSign}${delta.toFixed(2)}%</span>
      </td>
      <td style="padding:12px 18px;font-family:var(--font-mono);text-align:center;color:var(--muted);font-size:12px;border-bottom:1px solid var(--border)">${lnR.toFixed(4)}</td>
      <td style="padding:12px 18px;font-family:var(--font-mono);text-align:center;border-bottom:1px solid var(--border)">
        <span style="font-weight:800;font-size:14px;color:${conColor};background:${conBg};border:1px solid ${conColor}33;border-radius:6px;padding:3px 10px">${con.toFixed(4)}</span>
        <span style="font-size:10px;color:var(--muted);margin-left:5px;font-weight:600">${pct}%</span>
      </td>
    </tr>`;
  }).join('');

  document.getElementById('psi-result-tfoot').innerHTML = `
    <tr style="background:linear-gradient(to right,#F0F6FF,#F8FBFF);border-top:2px solid var(--border)">
      <td colspan="5" style="font-weight:800;font-size:13px;padding:14px 18px;font-family:var(--font-mono);color:var(--text-secondary);letter-spacing:.04em">
        TOTAL PSI &nbsp;=&nbsp; Σ PSI<sub>i</sub>
      </td>
      <td style="padding:14px 18px;font-family:var(--font-mono)">
        <span style="font-size:20px;font-weight:900;color:${rag.color}">${psi.toFixed(4)}</span>
        <span style="font-size:11px;font-weight:700;background:${rag.color}1A;border:1.5px solid ${rag.color}55;
          color:${rag.color};border-radius:20px;padding:3px 12px;margin-left:10px;vertical-align:middle;letter-spacing:.06em">${rag.label.toUpperCase()}</span>
      </td>
    </tr>`;

  document.getElementById('psi-result-zone').style.display = '';
  document.getElementById('psi-result-zone').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Init on panel open
const _origShowPanelPSI = showPanel;
showPanel = function(name, el) {
  _origShowPanelPSI(name, el);
  if (name === 'psi-calc' && !document.getElementById('psi-input-tbody').rows.length) {
    psiInitTable();
  }
};

// ── End PSI Calculator ────────────────────────────────────────────────────
