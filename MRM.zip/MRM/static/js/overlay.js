
// ── Tab Detail Overlay ───────────────────────────────────────────────────
// Opens a full-page overlay showing tab content clearly when a tab is clicked
const TAB_LABELS = {
  finding: 'Overview',
  remediation: 'Suggested Remediation',
  validation: 'Validation Checks',
  regulatory: 'Regulatory Guidelines',
  ai: 'AI Analysis',
};
const TAB_ICONS = {
  finding: `<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>`,
  remediation: `<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`,
  validation: `<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/><path d="M9 12h6M9 16h4"/></svg>`,
  regulatory: `<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>`,
  ai: `<svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/><circle cx="19" cy="5" r="3" fill="currentColor" stroke="none"/></svg>`,
};

// Inject overlay HTML once on load
(function createTabOverlay() {
  const overlay = document.createElement('div');
  overlay.id = 'tab-detail-overlay';
  overlay.style.cssText = `
    display:none; position:fixed; inset:0; z-index:2000;
    background:rgba(10,20,40,.55); backdrop-filter:blur(4px);
    align-items:flex-start; justify-content:center; overflow-y:auto;
    padding:32px 20px 60px;
  `;
  overlay.innerHTML = `
    <div id="tab-detail-panel" style="
      background:#fff; border:1px solid var(--border); border-radius:12px;
      width:min(820px,100%); margin:auto; box-shadow:0 20px 60px rgba(0,0,0,.18);
      animation:slideUp .22s ease; overflow:hidden;
    ">
      <div id="tab-detail-header" style="
        display:flex; align-items:center; gap:14px;
        padding:24px 28px 20px; border-bottom:1px solid var(--border);
        background:linear-gradient(135deg,#F0F7FF,#fff);
      ">
        <div id="tab-detail-icon" style="
          width:40px; height:40px; border-radius:10px; background:var(--primary);
          display:flex; align-items:center; justify-content:center;
          flex-shrink:0; color:#fff;
        "></div>
        <div style="flex:1; min-width:0">
          <div id="tab-detail-finding-id" style="font-family:var(--font-mono);font-size:12px;color:var(--muted);margin-bottom:3px"></div>
          <div id="tab-detail-title" style="font-size:18px;font-weight:700;color:var(--text);line-height:1.3"></div>
        </div>
        <button onclick="closeTabOverlay()" style="
          background:var(--bg); border:1px solid var(--border); cursor:pointer;
          color:var(--muted); font-size:20px; line-height:1; padding:6px 10px;
          border-radius:8px; transition:all .15s; flex-shrink:0;
        " onmouseover="this.style.color='var(--text)'" onmouseout="this.style.color='var(--muted)'">✕</button>
      </div>
      <!-- Tab bar inside overlay for switching without closing -->
      <div id="tab-detail-tabbar" style="
        display:flex; gap:0; border-bottom:1px solid var(--border);
        background:#FAFBFF; overflow-x:auto;
      "></div>
      <div id="tab-detail-body" style="padding:28px 32px; font-size:15px; line-height:1.8; color:#1A2F4A"></div>
    </div>`;
  document.body.appendChild(overlay);

  // Close on backdrop click
  overlay.addEventListener('click', e => { if (e.target === overlay) closeTabOverlay(); });

  // Close on Escape
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeTabOverlay(); });
})();

function closeTabOverlay() {
  const ov = document.getElementById('tab-detail-overlay');
  if (ov) { ov.style.display = 'none'; }
}

// Opens the overlay for a specific finding + pane
// tid = base id (e.g. 'sr-tabs-0'), pane = 'remediation'|'validation'|'regulatory'|'finding'
function openTabOverlay(tid, pane, findingTitle, findingId) {
  const paneEl = document.getElementById(tid + '-' + pane);
  if (!paneEl) return;

  const overlay = document.getElementById('tab-detail-overlay');
  const icon    = document.getElementById('tab-detail-icon');
  const titleEl = document.getElementById('tab-detail-title');
  const fidEl   = document.getElementById('tab-detail-finding-id');
  const body    = document.getElementById('tab-detail-body');
  const tabbar  = document.getElementById('tab-detail-tabbar');

  icon.innerHTML  = TAB_ICONS[pane] || TAB_ICONS.finding;
  titleEl.textContent = TAB_LABELS[pane] || pane;
  fidEl.textContent   = findingId ? findingId + (findingTitle ? ' · ' + findingTitle : '') : '';

  // Build tab bar for all panes in this finding card
  const allPanes = ['finding','remediation','validation','regulatory','ai'];
  tabbar.innerHTML = allPanes.map(p => {
    const isActive = p === pane;
    return `<button onclick="switchOverlayTab('${tid}','${p}','${(findingTitle||'').replace(/'/g,"\\'")}','${findingId||''}')"
      style="display:flex;align-items:center;gap:7px;padding:12px 20px;font-size:14px;font-weight:${isActive?'600':'500'};
      color:${isActive?'var(--primary)':'var(--muted)'};cursor:pointer;border:none;background:none;
      border-bottom:3px solid ${isActive?'var(--primary)':'transparent'};white-space:nowrap;transition:all .15s;flex-shrink:0"
      onmouseover="if(!${isActive})this.style.color='var(--text)'" onmouseout="if(!${isActive})this.style.color='var(--muted)'">
      ${TAB_ICONS[p]}<span>${TAB_LABELS[p]}</span>
    </button>`;
  }).join('');

  // Clone the pane content
  body.innerHTML = '';
  const clone = paneEl.cloneNode(true);
  clone.style.display = '';
  clone.classList.add('active');
  body.appendChild(clone);

  overlay.style.display = 'flex';
  document.getElementById('tab-detail-panel').scrollTop = 0;
}

function switchOverlayTab(tid, pane, findingTitle, findingId) {
  openTabOverlay(tid, pane, findingTitle, findingId);
}

// ── Drawer toggle & tab helpers ──────────────────────────────────────────
function toggleDrawer(drawerId) {
  const body = document.getElementById(drawerId);
  const chevron = document.getElementById(drawerId + '-chevron');
  if (!body) return;
  const isOpen = body.classList.contains('open');
  body.classList.toggle('open', !isOpen);
  if (chevron) chevron.classList.toggle('open', !isOpen);
}

function switchDrawerTab(drawerId, pane, btn) {
  const content = document.getElementById(drawerId === 'pf' ? 'pf-drawer' : 'mrm-drawer');
  if (!content) return;
  // Hide all panes
  content.querySelectorAll('.drawer-pane').forEach(p => p.classList.remove('active'));
  // Show target pane
  const target = document.getElementById((drawerId === 'pf' ? 'pf' : 'mrm') + '-pane-' + pane);
  if (target) target.classList.add('active');
  // Update tab active states
  content.querySelectorAll('.drawer-inner-tab').forEach(t => t.classList.remove('active'));
  if (btn) btn.classList.add('active');
}

// Tabs are inline — no overlay override needed

// ── Result overlay: renders the full-page view inline as a modal iframe ─────
// No blob URL, no popup blockers, no extra browser tab. Esc / click-outside / × closes.
let _resultOverlayState = null;

function _ensureResultOverlay() {
  if (_resultOverlayState) return _resultOverlayState;

  const overlay = document.createElement('div');
  overlay.id = 'result-overlay';
  overlay.style.cssText =
    'position:fixed;inset:0;z-index:9999;background:rgba(15,25,40,.55);' +
    'backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);' +
    'display:flex;align-items:stretch;justify-content:center;padding:24px;' +
    'animation:fadeIn .2s ease';
  overlay.addEventListener('click', (e) => { if (e.target === overlay) _closeResultOverlay(); });

  const container = document.createElement('div');
  container.style.cssText =
    'position:relative;width:100%;max-width:1180px;background:#fff;border-radius:14px;' +
    'overflow:hidden;box-shadow:0 25px 80px rgba(0,0,0,.35);display:flex;flex-direction:column;' +
    'animation:fadeIn .25s ease';

  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.title = 'Close (Esc)';
  closeBtn.setAttribute('aria-label', 'Close');
  closeBtn.innerHTML =
    '<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">' +
    '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';
  closeBtn.style.cssText =
    'position:absolute;top:14px;right:18px;z-index:10;width:32px;height:32px;border-radius:8px;' +
    'background:rgba(255,255,255,.95);border:1px solid #E0E4E8;color:#4A5568;cursor:pointer;' +
    'display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.12);' +
    'transition:color .15s,border-color .15s,background .15s';
  closeBtn.addEventListener('mouseenter', () => {
    closeBtn.style.color = '#1A2F4A';
    closeBtn.style.borderColor = '#C4CDD5';
    closeBtn.style.background = '#fff';
  });
  closeBtn.addEventListener('mouseleave', () => {
    closeBtn.style.color = '#4A5568';
    closeBtn.style.borderColor = '#E0E4E8';
    closeBtn.style.background = 'rgba(255,255,255,.95)';
  });
  closeBtn.addEventListener('click', _closeResultOverlay);

  const iframe = document.createElement('iframe');
  iframe.title = 'Result page';
  iframe.style.cssText = 'flex:1;width:100%;min-height:0;border:none;background:#F4F6F8;display:block';

  container.appendChild(closeBtn);
  container.appendChild(iframe);
  overlay.appendChild(container);

  const escHandler = (e) => { if (e.key === 'Escape') _closeResultOverlay(); };

  const prevBodyOverflow = document.body.style.overflow;
  document.body.style.overflow = 'hidden';
  document.body.appendChild(overlay);
  document.addEventListener('keydown', escHandler);

  _resultOverlayState = { overlay, iframe, container, closeBtn, escHandler, prevBodyOverflow };
  return _resultOverlayState;
}

function _closeResultOverlay() {
  if (!_resultOverlayState) return;
  const { overlay, escHandler, prevBodyOverflow } = _resultOverlayState;
  document.removeEventListener('keydown', escHandler);
  document.body.style.overflow = prevBodyOverflow || '';
  overlay.remove();
  _resultOverlayState = null;
}
window.closeResultOverlay = _closeResultOverlay;

function _renderResultOverlay(html) {
  const { iframe } = _ensureResultOverlay();
  // Inject a tiny shim so window.close() inside the page closes the overlay instead.
  const shim =
    '<script>(function(){' +
      'var done=function(){try{if(window.parent&&window.parent.closeResultOverlay)window.parent.closeResultOverlay();}catch(e){}};' +
      'window.close=done;' +
    '})();<\/script>';
  const patched = html.includes('</body>') ? html.replace('</body>', shim + '</body>') : html + shim;
  iframe.srcdoc = patched;
}

// ── Render Potential Findings or MRM Actions inline ─────────────────────────
function _openResultPageNow(type) {
  if (!_lastSearchResults) {
    showAlert('Run a search first to view results.', 'info');
    return;
  }
  const data = _resultPageData(type);
  const key = 'mrm_page_data_' + Date.now();
  try { sessionStorage.setItem(key, JSON.stringify(data)); } catch(e) {}
  _renderResultOverlay(buildResultPageHTML(data, key));
}

function _mrmActionHtmlIsReady(html) {
  const text = (html || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  return !!text && !text.includes('Click AI Analyze') && !text.includes('Generating');
}

function _mrmActionsReady() {
  return ['regulatory', 'validation', 'remediation'].every(pane => {
    const el = document.getElementById('llm-text-' + pane);
    return el && _mrmActionHtmlIsReady(el.innerHTML);
  });
}

function _resultPageData(type) {
  const query = (document.getElementById('search-input') || {}).value || '';
  return {
    type,
    query,
    findings: _lastSearchResults.findings || [],
    cluster:  _lastSearchResults.cluster || null,
    score:    _lastSearchResults.score   || 0,
    llm: {
      remediation: (document.getElementById('llm-text-remediation') || {}).innerHTML || '',
      regulatory:  (document.getElementById('llm-text-regulatory')  || {}).innerHTML || '',
      validation:  (document.getElementById('llm-text-validation')  || {}).innerHTML || '',
    }
  };
}

function _writeResultPage(_win, type) {
  // Legacy helper retained for compatibility — overlay-based rendering.
  _openResultPageNow(type);
}

let _llmAnalysisPromise = null;
const _runLLMAnalysis = doLLMAnalysis;
doLLMAnalysis = async function() {
  if (_llmAnalysisPromise) return _llmAnalysisPromise;
  _llmAnalysisPromise = _runLLMAnalysis().finally(() => {
    _llmAnalysisPromise = null;
  });
  return _llmAnalysisPromise;
};

// ── MRM Drawer loading overlay ─────────────────────────────────────────────
function _setMRMDrawerLoading(on) {
  const drawer = document.getElementById('mrm-drawer');
  if (!drawer) return;
  let ov = document.getElementById('mrm-drawer-load-ov');
  if (on) {
    if (!ov) {
      ov = document.createElement('div');
      ov.id = 'mrm-drawer-load-ov';
      ov.style.cssText = 'position:absolute;inset:0;z-index:60;border-radius:0 0 8px 8px;' +
        'background:rgba(255,255,255,.92);backdrop-filter:blur(4px);' +
        'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px';
      ov.innerHTML =
        '<div style="position:relative;width:48px;height:48px">' +
          '<div style="position:absolute;inset:0;border-radius:50%;border:3px solid #FDF1EA"></div>' +
          '<div style="position:absolute;inset:0;border-radius:50%;border:3px solid transparent;border-top-color:#EA6C36;animation:spin .8s linear infinite"></div>' +
          '<div style="position:absolute;inset:8px;border-radius:50%;border:2px solid transparent;border-top-color:#2B6CB0;animation:spin 1.2s linear infinite reverse"></div>' +
        '</div>' +
        '<div style="text-align:center">' +
          '<div style="font-size:13px;font-weight:700;color:#1A2F4A;margin-bottom:3px">Generating MRM Actions</div>' +
          '<div style="font-size:11.5px;color:#718096">AI is analysing — all 3 sections loading…</div>' +
        '</div>' +
        '<div style="display:flex;gap:6px">' +
          '<span style="display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:600;font-family:monospace;color:#2B6CB0;background:#EAF3FF;border:1px solid #C0D8F0;border-radius:20px;padding:3px 9px">' +
            '<svg width="9" height="9" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>Regulatory</span>' +
          '<span style="display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:600;font-family:monospace;color:#005E7C;background:#E6F3F7;border:1px solid #B3D8E5;border-radius:20px;padding:3px 9px">' +
            '<svg width="9" height="9" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/></svg>Validation</span>' +
          '<span style="display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:600;font-family:monospace;color:#EA6C36;background:#FDF1EA;border:1px solid #F8CBB4;border-radius:20px;padding:3px 9px">' +
            '<svg width="9" height="9" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>Remediation</span>' +
        '</div>';
      drawer.style.position = 'relative';
      drawer.appendChild(ov);
    }
    ov.style.display = 'flex';
  } else {
    if (ov) ov.style.display = 'none';
  }
}

async function openResultPage(type) {
  if (type !== 'mrm') {
    _openResultPageNow(type);
    return;
  }

  if (!_lastSearchResults) {
    showAlert('Run a search first to view results.', 'info');
    return;
  }

  const query = (document.getElementById('search-input') || {}).value || '';
  const findings = _lastSearchResults.findings || [];
  const cluster = _lastSearchResults.cluster || null;
  const score = _lastSearchResults.score || 0;

  // Show the loading view inside the overlay immediately.
  _renderResultOverlay(buildMRMLoadingPage({ query, findings, cluster, score }));

  // Run AI analysis (or skip if already done).
  if (!_mrmActionsReady()) {
    _setMRMDrawerLoading(true);
    try { await doLLMAnalysis(); } catch(e) {}
    _setMRMDrawerLoading(false);
  }

  // Only swap to results if the user hasn't dismissed the overlay in the meantime.
  if (_resultOverlayState) {
    const data = _resultPageData('mrm');
    const key = 'mrm_page_data_' + Date.now();
    try { sessionStorage.setItem(key, JSON.stringify(data)); } catch(e) {}
    _renderResultOverlay(buildResultPageHTML(data, key));
  }
}

function buildMRMLoadingPage(data) {
  const query = (data.query || '').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>Additional MRM Actions — Protiviti MRM</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Roboto+Mono:wght@400;500;600&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{background:#F4F6F8;color:#333;font-family:'Inter',-apple-system,sans-serif;font-size:15px;line-height:1.7;min-height:100vh}
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@keyframes slideDown{from{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:translateY(0)}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes shimmer{0%{background-position:100% 50%}100%{background-position:0% 50%}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.45}}
@keyframes floatUp{0%{transform:translateY(0)}50%{transform:translateY(-8px)}100%{transform:translateY(0)}}
.fade-in{animation:fadeIn .3s ease both}
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:#C4CDD5;border-radius:10px}
</style>
</head>
<body>
<!-- Top nav bar -->
<div style="background:#fff;border-bottom:1px solid #E0E4E8;padding:0 32px;display:flex;align-items:center;height:62px;gap:14px;position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,.07);animation:slideDown .25s ease">
  <div style="width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,#EA6C36,#c9520f);display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 3px 10px rgba(234,108,54,.3)">
    <svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/><circle cx="19" cy="5" r="3" fill="currentColor" stroke="none"/></svg>
  </div>
  <div>
    <div style="font-size:18px;font-weight:700;color:#1A2F4A;line-height:1.2">Additional MRM Actions</div>
    <div style="font-size:12px;color:#718096;margin-top:1px">Protiviti MRM Finding Library · Query: <em style="color:#4A5568">"${query}"</em></div>
  </div>
  <div style="margin-left:auto">
    <button onclick="window.close()" style="background:#F4F6F8;border:1px solid #E0E4E8;border-radius:8px;padding:7px 14px;cursor:pointer;font-size:12px;font-weight:500;color:#4A5568;display:flex;align-items:center;gap:6px;transition:all .15s">
      <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      Close
    </button>
  </div>
</div>

<!-- Loading state -->
<div style="max-width:720px;margin:0 auto;padding:64px 32px;text-align:center;animation:fadeIn .4s ease">
  <!-- Animated icon -->
  <div style="position:relative;width:72px;height:72px;margin:0 auto 28px;animation:floatUp 2.4s ease-in-out infinite">
    <div style="position:absolute;inset:0;border-radius:50%;border:3px solid #FDE8D8"></div>
    <div style="position:absolute;inset:0;border-radius:50%;border:3px solid transparent;border-top-color:#EA6C36;animation:spin .8s linear infinite"></div>
    <div style="position:absolute;inset:10px;border-radius:50%;border:2.5px solid transparent;border-top-color:#2B6CB0;animation:spin 1.3s linear infinite reverse"></div>
    <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">
      <svg width="24" height="24" fill="none" stroke="#EA6C36" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/><circle cx="19" cy="5" r="3" fill="#EA6C36" stroke="none"/></svg>
    </div>
  </div>

  <h2 style="font-size:22px;font-weight:700;color:#1A2F4A;margin-bottom:10px;letter-spacing:-.01em">Generating MRM Actions</h2>
  <p style="font-size:14px;color:#718096;line-height:1.7;max-width:480px;margin:0 auto 32px">AI is analysing your query and matched findings to produce regulatory guidelines, validation checks, and remediation steps.</p>

  <!-- Three section pills with individual loading indicators -->
  <div style="display:flex;flex-direction:column;gap:14px;max-width:500px;margin:0 auto 40px">
    <div style="display:flex;align-items:center;gap:14px;background:#fff;border:1px solid #E0E4E8;border-radius:10px;padding:14px 18px;box-shadow:0 1px 4px rgba(0,0,0,.05)">
      <div style="width:36px;height:36px;border-radius:9px;background:#EAF3FF;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <svg width="16" height="16" fill="none" stroke="#2B6CB0" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>
      </div>
      <div style="flex:1;text-align:left">
        <div style="font-size:13px;font-weight:600;color:#1A2F4A">Regulatory Guidelines</div>
        <div style="font-size:11px;color:#718096;margin-top:2px">Supervisory expectations &amp; standards</div>
      </div>
      <div style="width:18px;height:18px;border-radius:50%;border:2.5px solid #2B6CB0;border-top-color:transparent;animation:spin .75s linear infinite;flex-shrink:0"></div>
    </div>
    <div style="display:flex;align-items:center;gap:14px;background:#fff;border:1px solid #E0E4E8;border-radius:10px;padding:14px 18px;box-shadow:0 1px 4px rgba(0,0,0,.05)">
      <div style="width:36px;height:36px;border-radius:9px;background:#E8F7EE;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <svg width="16" height="16" fill="none" stroke="#0C7A40" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/><path d="M9 12h6M9 16h4"/></svg>
      </div>
      <div style="flex:1;text-align:left">
        <div style="font-size:13px;font-weight:600;color:#1A2F4A">Validation Checks</div>
        <div style="font-size:11px;color:#718096;margin-top:2px">Independent tests &amp; review activities</div>
      </div>
      <div style="width:18px;height:18px;border-radius:50%;border:2.5px solid #0C7A40;border-top-color:transparent;animation:spin .75s linear infinite;animation-delay:.2s;flex-shrink:0"></div>
    </div>
    <div style="display:flex;align-items:center;gap:14px;background:#fff;border:1px solid #E0E4E8;border-radius:10px;padding:14px 18px;box-shadow:0 1px 4px rgba(0,0,0,.05)">
      <div style="width:36px;height:36px;border-radius:9px;background:#FDF1EA;display:flex;align-items:center;justify-content:center;flex-shrink:0">
        <svg width="16" height="16" fill="none" stroke="#EA6C36" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
      </div>
      <div style="flex:1;text-align:left">
        <div style="font-size:13px;font-weight:600;color:#1A2F4A">Suggested Remediations</div>
        <div style="font-size:11px;color:#718096;margin-top:2px">Prioritised corrective actions</div>
      </div>
      <div style="width:18px;height:18px;border-radius:50%;border:2.5px solid #EA6C36;border-top-color:transparent;animation:spin .75s linear infinite;animation-delay:.4s;flex-shrink:0"></div>
    </div>
  </div>

  <!-- Shimmer skeleton preview -->
  <div style="background:#fff;border:1px solid #E0E4E8;border-radius:12px;padding:24px 28px;max-width:680px;margin:0 auto;box-shadow:0 2px 8px rgba(0,0,0,.05)">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:20px">
      <div style="width:32px;height:32px;border-radius:8px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.5s ease infinite"></div>
      <div style="flex:1">
        <div style="height:13px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.5s ease .1s infinite;width:55%;margin-bottom:7px"></div>
        <div style="height:10px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.5s ease .2s infinite;width:35%"></div>
      </div>
    </div>
    <div style="height:13px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.5s ease 0s infinite;width:90%;margin-bottom:10px"></div>
    <div style="height:13px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.5s ease .15s infinite;width:75%;margin-bottom:10px"></div>
    <div style="height:13px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.5s ease .3s infinite;width:82%;margin-bottom:10px"></div>
    <div style="height:13px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.5s ease .45s infinite;width:60%"></div>
  </div>
</div>
</body>
</html>`;
}

function buildResultPageHTML(data, storeKey) {
  const isPF  = data.type === 'pf';
  const title = isPF ? 'Potential Findings' : 'Additional MRM Actions';
  const accent = isPF ? '#005E7C' : '#EA6C36';
  const accentBg = isPF ? '#E6F3F7' : '#FDF1EA';
  const iconSVG = isPF
    ? `<svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/></svg>`
    : `<svg width="22" height="22" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/><circle cx="19" cy="5" r="3" fill="currentColor" stroke="none"/></svg>`;

  /* ── Potential Findings page content ── */
  const pfContent = () => {
    if (!data.findings || !data.findings.length) {
      return `<div style="text-align:center;padding:60px 20px;color:#718096">
        <div style="font-size:40px;margin-bottom:16px;opacity:.4">⊘</div>
        <p style="font-size:15px">No findings matched this query.</p>
      </div>`;
    }
    return data.findings.map((f, i) => {
      return `
      <div style="background:#fff;border:1px solid #E0E4E8;border-radius:12px;margin-bottom:20px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,.07);animation:fadeIn .3s ease ${i*0.06}s both">
        <!-- Card header -->
        <div style="display:flex;align-items:flex-start;gap:14px;padding:20px 24px 16px;border-bottom:1px solid #E0E4E8;background:linear-gradient(to right,#F4F8FF,#fff)">
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:8px">
              <span style="background:#EEF3FF;color:#005E7C;border:1px solid #C5D5F5;border-radius:4px;font-size:12px;font-family:monospace;font-weight:600;padding:3px 10px">${f.finding_id}</span>
              ${f.model_theme ? `<span style="background:#E8F7EE;color:#0C7A40;border:1px solid #B3DECA;border-radius:4px;font-size:11px;font-family:monospace;font-weight:600;padding:2px 8px">${f.model_theme}</span>` : ''}
            </div>
            <div style="font-size:17px;font-weight:700;color:#1A2F4A;line-height:1.35">${f.title}</div>
          </div>
          <div style="background:#EEF3FF;color:#005E7C;border:1px solid #C5D5F5;border-radius:8px;padding:4px 10px;font-size:11px;font-family:monospace;font-weight:700;flex-shrink:0;white-space:nowrap">#${i+1}</div>
        </div>
        <!-- Overview pane (no tab bar needed — remediation removed) -->
        <div style="padding:22px 26px">
          <div style="font-family:monospace;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#005E7C;margin-bottom:6px;padding-bottom:6px;border-bottom:1px solid #E0E4E8">Description</div>
          <div style="font-size:14px;color:#2D3748;line-height:1.85;margin-bottom:16px">${f.description}</div>
          <div style="font-family:monospace;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#B45309;margin-bottom:6px;padding-bottom:6px;border-bottom:1px solid #E0E4E8">Business Justification</div>
          <div style="font-size:14px;color:#2D3748;line-height:1.85;background:#FEF3C7;border-left:4px solid #D69E2E;padding:12px 16px;border-radius:0 8px 8px 0">${f.business_justification}</div>
        </div>
      </div>`;
    }).join('');
  };

  /* ── MRM Actions page content ── */
  const mrmContent = () => {
    const sections = [
      {
        tid: 'regulatory',
        label: 'Applicable Regulatory Guidelines',
        shortLabel: 'Regulatory Guidelines',
        accent: '#2B6CB0',
        accentLight: '#EAF3FF',
        accentMid: '#DBEAFE',
        border: '#C0D8F0',
        bulletColor: '#2B6CB0',
        subColor: '#5A8FD4',
        tagBg: '#EAF3FF',
        gradFrom: '#EAF3FF',
        icon: '<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>',
        iconSm: '<svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>',
        html: data.llm.regulatory,
        description: 'Supervisory expectations & regulatory standards',
      },
      {
        tid: 'validation',
        label: 'Applicable Validation Checks',
        shortLabel: 'Validation Checks',
        accent: '#0C7A40',
        accentLight: '#E8F7EE',
        accentMid: '#D1FAE5',
        border: '#B3DECA',
        bulletColor: '#0C7A40',
        subColor: '#3DAA6A',
        tagBg: '#E8F7EE',
        gradFrom: '#E8F7EE',
        icon: '<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/><path d="M9 12h6M9 16h4"/></svg>',
        iconSm: '<svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/></svg>',
        html: data.llm.validation,
        description: 'Independent tests & review activities',
      },
      {
        tid: 'remediation',
        label: 'Suggested Remediations',
        shortLabel: 'Remediations',
        accent: '#EA6C36',
        accentLight: '#FDF1EA',
        accentMid: '#FFE4CC',
        border: '#F8CBB4',
        bulletColor: '#EA6C36',
        subColor: '#C45A28',
        tagBg: '#FDF1EA',
        gradFrom: '#FDF1EA',
        icon: '<svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
        iconSm: '<svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>',
        html: data.llm.remediation,
        description: 'Prioritised, actionable corrective steps',
      },
    ];

    const isReady = (html) =>
      html && html.trim() &&
      !html.includes('Click <strong>AI Analyze</strong>') &&
      !html.includes('Generating') &&
      !html.includes('Click AI Analyze');

    // ── Smart parser: detects main points vs sub-points from LLM output ──────
    // Main point: short header-like line (ends with ":" or is a numbered/lettered item without a sub-letter)
    //             OR a plain numbered sentence that is the "lead" item
    // Sub-point:  lines starting with a. b. c. / - / – / Cite: / quoted text
    const parseItems = (html) => {
      const items = [];
      const pMatches = (html || '').match(/<p[^>]*>([\s\S]*?)<\/p>/gi) || [];
      pMatches.forEach(function(match) {
        const text = match.replace(/<[^>]+>/g, '').replace(/\s+/g,' ').trim();
        if (!text || text.length < 3) return;
        // Sub-point patterns: starts with a letter+dot (a. b. c.), dash, cite, quote
        const isSubPattern = /^[a-z]\.\s/i.test(text) ||
                             /^[-–•]\s/.test(text) ||
                             /^Cite:/i.test(text) ||
                             /^[""]/.test(text) ||
                             /^- Cite/i.test(text);
        // Main point patterns: ends with colon (heading), OR is a short bold-style line
        const isMainHeading = /:\s*$/.test(text) && text.length < 80;
        items.push({ text, isSub: isSubPattern && !isMainHeading, isHeading: isMainHeading });
      });
      return items;
    };

    // ── Render items with clear visual hierarchy ──────────────────────────────
    const renderItems = (items, s) => {
      if (!items.length) return '';
      let out = '<div style="padding:4px 0 4px">';
      items.forEach(function(item, idx) {
        const isLast = idx === items.length - 1;
        const nextIsSub = !isLast && (items[idx+1].isSub || items[idx+1].isHeading === false);

        if (item.isHeading) {
          // ── Section heading: bold label with left colour bar, no bullet ──
          const sep = idx > 0 ? 'margin-top:18px;' : '';
          out += '<div style="display:flex;align-items:center;gap:10px;' + sep + 'padding:10px 0 8px 0;border-bottom:2px solid ' + s.accentMid + ';margin-bottom:2px">' +
            '<div style="width:4px;height:20px;border-radius:2px;background:' + s.accent + ';flex-shrink:0"></div>' +
            '<span style="font-size:15px;font-weight:800;color:' + s.accent + ';letter-spacing:.01em;line-height:1.3">' + item.text.replace(/:$/, '') + '</span>' +
            '</div>';

        } else if (item.isSub) {
          // ── Sub-point: indented, normal weight, small arrow marker ──
          out += '<div style="display:flex;gap:10px;align-items:flex-start;padding:7px 0 7px 22px;' +
            (isLast ? '' : 'border-bottom:1px dashed ' + s.accentMid + ';') + '">' +
            '<svg style="flex-shrink:0;margin-top:5px;opacity:.65" width="10" height="10" fill="none" stroke="' + s.subColor + '" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>' +
            '<p style="margin:0;font-size:13.5px;color:#4A5568;line-height:1.78;font-weight:400">' +
              item.text.replace(/^[a-z]\.\s*/i,'').replace(/^[-–•]\s*/,'').replace(/^Cite:\s*/i,'') +
            '</p>' +
            '</div>';

        } else {
          // ── Main numbered point: large filled bullet, bold text ──
          out += '<div style="display:flex;gap:14px;align-items:flex-start;padding:13px 0;' +
            (isLast ? '' : 'border-bottom:1px solid #F0F4F8;') + '">' +
            '<span style="flex-shrink:0;width:11px;height:11px;border-radius:50%;background:' + s.bulletColor + ';margin-top:5px;box-shadow:0 0 0 3px ' + s.accentMid + '"></span>' +
            '<p style="margin:0;font-size:14.5px;color:#1A2F4A;line-height:1.82;font-weight:700;letter-spacing:.01em">' + item.text + '</p>' +
            '</div>';
        }
      });
      out += '</div>';
      return out;
    };

    // ── Clean Claude/ChatGPT-style renderer — no colored left bars ───────────
    const renderClaudeStyle = (items, s) => {
      if (!items.length) return '';
      let out = '<div style="padding:2px 0">';
      items.forEach(function(item, idx) {
        const isLast = idx === items.length - 1;

        if (item.isHeading) {
          const top = idx > 0 ? 'margin-top:24px;' : '';
          out += '<div style="' + top + 'padding:0 0 10px 0;margin-bottom:4px;border-bottom:1px solid #F0F4F8">' +
            '<span style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:' + s.accent + ';font-family:monospace">' + item.text.replace(/:$/, '') + '</span>' +
            '</div>';

        } else if (item.isSub) {
          out += '<div style="display:flex;gap:12px;align-items:flex-start;padding:8px 0 8px 8px;' +
            (isLast ? '' : 'border-bottom:1px solid #F7F9FB;') + '">' +
            '<span style="flex-shrink:0;margin-top:8px;color:' + s.subColor + ';opacity:.7">' +
              '<svg width="10" height="10" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"/></svg>' +
            '</span>' +
            '<p style="margin:0;font-size:14px;color:#4A5568;line-height:1.82;font-weight:400">' +
              item.text.replace(/^[a-z]\.\s*/i,'').replace(/^[-–•]\s*/,'').replace(/^Cite:\s*/i,'') +
            '</p>' +
            '</div>';

        } else {
          // Main point: dot + prose, clean separation
          out += '<div style="display:flex;gap:14px;align-items:flex-start;padding:14px 0;' +
            (isLast ? '' : 'border-bottom:1px solid #F2F4F7;') + '">' +
            '<span style="flex-shrink:0;width:8px;height:8px;border-radius:50%;background:' + s.bulletColor + ';margin-top:7px;opacity:.85"></span>' +
            '<p style="margin:0;font-size:14.5px;color:#1A2F4A;line-height:1.85;font-weight:400">' + item.text + '</p>' +
            '</div>';
        }
      });
      out += '</div>';
      return out;
    };

    // Shimmer line helper
    const shimmer = (w, delay) => '<div style="height:13px;border-radius:6px;' +
      'background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);' +
      'background-size:400% 100%;animation:shimmer 1.5s ease ' + (delay||'0s') + ' infinite;' +
      'width:' + w + ';margin-bottom:12px"></div>';

    const renderSectionCard = (s) =>
      '<div id="mrm-section-' + s.tid + '" style="display:none;animation:fadeIn .28s ease">' +
      // Clean section header — no left bar, just icon + label
      '<div style="display:flex;align-items:center;gap:14px;padding:20px 28px 16px;border-bottom:1px solid #F0F4F8">' +
        '<div style="width:38px;height:38px;border-radius:10px;background:' + s.accentLight + ';display:flex;align-items:center;justify-content:center;flex-shrink:0;color:' + s.accent + '">' + s.icon + '</div>' +
        '<div style="flex:1;min-width:0">' +
          '<div style="font-size:16px;font-weight:700;color:#1A2F4A;line-height:1.25">' + s.label + '</div>' +
          '<div style="font-size:12px;color:#718096;margin-top:2px">' + s.description + '</div>' +
        '</div>' +
        '<span style="display:inline-flex;align-items:center;gap:5px;background:' + s.tagBg + ';border:1px solid ' + s.border + ';border-radius:20px;padding:4px 11px;font-size:10px;font-weight:700;color:' + s.accent + ';font-family:monospace;letter-spacing:.05em;flex-shrink:0">' +
          '<svg width="8" height="8" fill="' + s.accent + '" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/></svg>' +
          'AI GENERATED' +
        '</span>' +
      '</div>' +
      // Content body — clean prose style
      '<div id="mrm-body-' + s.tid + '" style="background:#fff;padding:22px 28px;min-height:220px">' +
        (isReady(s.html)
          ? (renderClaudeStyle(parseItems(s.html), s) || s.html)
          : '<div id="mrm-shimmer-' + s.tid + '" style="padding:14px 0">' +
              shimmer('88%','0s') + shimmer('72%','.15s') + shimmer('82%','.3s') +
              shimmer('65%','.45s') + shimmer('78%','.6s') + shimmer('55%','.75s') +
            '</div>'
        ) +
      '</div>' +
      '</div>';

    return '<style>' +
      '@keyframes shimmer{0%{background-position:100% 50%}100%{background-position:0% 50%}}' +
      '@keyframes tabPop{0%{transform:translateY(4px);opacity:.5}100%{transform:translateY(0);opacity:1}}' +
      '@keyframes spin{to{transform:rotate(360deg)}}' +
      '.mrm-tab-btn{transition:all .2s;border:none;cursor:pointer;background:none;font-family:inherit;}' +
      '.mrm-tab-btn:hover{opacity:.85;}' +
      '</style>' +

    // ── Outer wrapper — clean card ──
    '<div style="background:#fff;border:1px solid #E8ECF0;border-radius:14px;box-shadow:0 2px 10px rgba(0,0,0,.06);overflow:hidden">' +

    // ── Tab Bar ──
    '<div style="display:flex;gap:0;background:#FAFBFC;border-bottom:1px solid #E8ECF0;" id="mrm-tab-bar">' +
      sections.map(function(s, i) {
        const isFirst = i === 0;
        const borderL = i > 0 ? 'border-left:1px solid #E8ECF0;' : '';
        return '<button class="mrm-tab-btn" onclick="switchMRMTab(\'' + s.tid + '\')" id="mrm-btn-' + s.tid + '" ' +
          'style="display:flex;align-items:center;justify-content:center;gap:8px;flex:1;padding:14px 16px;' +
          'font-size:13px;font-weight:' + (isFirst ? '600' : '400') + ';' +
          'white-space:nowrap;' + borderL +
          'background:' + (isFirst ? s.accentLight : 'transparent') + ';' +
          'color:' + (isFirst ? s.accent : '#718096') + ';' +
          'border-bottom:3px solid ' + (isFirst ? s.accent : 'transparent') + '">' +
          '<span style="display:flex;color:inherit">' + s.icon.replace('width="18" height="18"','width="15" height="15"') + '</span>' +
          s.shortLabel +
          '</button>';
      }).join('') +
    '</div>' +

    // ── Animated loading bar — shown when content is being generated ──
    '<div id="mrm-page-loading" style="' + (!sections.every(function(s){return isReady(s.html);}) ? 'display:flex' : 'display:none') + ';' +
      'align-items:center;gap:16px;padding:16px 24px;background:linear-gradient(to right,#FFFAF7,#fff);border-bottom:1px solid #F8CBB4">' +
      // Dual-ring spinner
      '<div style="position:relative;width:34px;height:34px;flex-shrink:0">' +
        '<div style="position:absolute;inset:0;border-radius:50%;border:3px solid #FDE8D8"></div>' +
        '<div style="position:absolute;inset:0;border-radius:50%;border:3px solid transparent;border-top-color:#EA6C36;animation:spin .75s linear infinite"></div>' +
        '<div style="position:absolute;inset:7px;border-radius:50%;border:2px solid transparent;border-top-color:#2B6CB0;animation:spin 1.2s linear infinite reverse"></div>' +
      '</div>' +
      '<div style="flex:1">' +
        '<div style="font-size:13.5px;font-weight:700;color:#1A2F4A;margin-bottom:3px">Generating MRM Actions across all 3 sections…</div>' +
        '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">' +
          // Progress pill per section with animated dot
          '<span id="mrm-pill-regulatory" style="display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:600;font-family:monospace;color:#2B6CB0;background:#EAF3FF;border:1px solid #C0D8F0;border-radius:20px;padding:3px 10px">' +
            '<span id="mrm-dot-regulatory" style="width:7px;height:7px;border-radius:50%;border:2px solid #2B6CB0;border-top-color:transparent;display:inline-block;animation:spin .7s linear infinite"></span>Regulatory</span>' +
          '<span id="mrm-pill-validation" style="display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:600;font-family:monospace;color:#0C7A40;background:#E8F7EE;border:1px solid #B3DECA;border-radius:20px;padding:3px 10px">' +
            '<span id="mrm-dot-validation" style="width:7px;height:7px;border-radius:50%;border:2px solid #0C7A40;border-top-color:transparent;display:inline-block;animation:spin .7s linear infinite"></span>Validation</span>' +
          '<span id="mrm-pill-remediation" style="display:inline-flex;align-items:center;gap:5px;font-size:11px;font-weight:600;font-family:monospace;color:#EA6C36;background:#FDF1EA;border:1px solid #F8CBB4;border-radius:20px;padding:3px 10px">' +
            '<span id="mrm-dot-remediation" style="width:7px;height:7px;border-radius:50%;border:2px solid #EA6C36;border-top-color:transparent;display:inline-block;animation:spin .7s linear infinite"></span>Remediations</span>' +
        '</div>' +
      '</div>' +
    '</div>' +

    // ── Section Cards (one shown at a time) ──
    sections.map(function(s) { return renderSectionCard(s); }).join('') +

    '</div>' + // close outer wrapper

    '<script>' +
    '(function() {' +
      'var sections=["regulatory","validation","remediation"];' +
      'var colors={regulatory:"#2B6CB0",validation:"#0C7A40",remediation:"#EA6C36"};' +
      'var lights={regulatory:"#EAF3FF",validation:"#E8F7EE",remediation:"#FDF1EA"};' +
      'var accents={regulatory:"#2B6CB0",validation:"#0C7A40",remediation:"#EA6C36"};' +

      'function switchMRMTab(active){' +
        'sections.forEach(function(t){' +
          'var s=document.getElementById("mrm-section-"+t);' +
          'var b=document.getElementById("mrm-btn-"+t);' +
          'if(s){s.style.display=t===active?"block":"none";if(t===active){s.style.animation="none";void s.offsetHeight;s.style.animation="tabPop .22s ease both";}}' +
          'if(b){' +
            'b.style.background=t===active?lights[t]:"transparent";' +
            'b.style.color=t===active?colors[t]:"#718096";' +
            'b.style.fontWeight=t===active?"700":"500";' +
            'b.style.borderBottom="3px solid "+(t===active?accents[t]:"transparent");' +
          '}' +
        '});' +
      '}' +
      'window.switchMRMTab=switchMRMTab;' +
      'switchMRMTab("regulatory");' +

      // Mark a section pill as done (tick) when its content is present
      'function markDone(tid){' +
        'var pill=document.getElementById("mrm-pill-"+tid);' +
        'var dot=document.getElementById("mrm-dot-"+tid);' +
        'if(dot){dot.style.animation="none";dot.style.borderColor="currentColor";dot.style.background="currentColor";dot.style.width="6px";dot.style.height="6px";}' +
      '}' +

      // Check if each section already has real content on load; update pills & hide bar if all done
      '(function checkOnLoad(){' +
        'var allDone=true;' +
        'sections.forEach(function(t){' +
          'var shimmer=document.getElementById("mrm-shimmer-"+t);' +
          'if(!shimmer){markDone(t);}else{allDone=false;}' +
        '});' +
        'if(allDone){var bar=document.getElementById("mrm-page-loading");if(bar)bar.style.display="none";}' +
      '})();' +

    '})();' +
    '<\/script>';
  };

  const bodyContent = isPF ? pfContent() : mrmContent();
  const clusterInfo = data.cluster ? `
    <div style="background:#fff;border:1px solid #E0E4E8;border-radius:10px;padding:14px 20px;margin-top:18px;display:flex;align-items:center;gap:12px;box-shadow:0 1px 4px rgba(0,0,0,.06)">
      <div style="width:10px;height:10px;border-radius:50%;background:#005E7C;flex-shrink:0"></div>
      <span style="font-size:12px;font-family:monospace;font-weight:700;color:#005E7C">${data.cluster.cluster_id}</span>
      ${data.cluster.semantic_label ? `<span style="font-size:12px;color:#4A5568">${data.cluster.semantic_label}</span>` : ''}
      <span style="margin-left:auto;font-size:11px;color:#718096;font-family:monospace">${data.cluster.findings_included.length} findings in cluster</span>
    </div>` : '';

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>${title} — Protiviti MRM</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Roboto+Mono:wght@400;500;600&display=swap" rel="stylesheet"/>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{background:#F4F6F8;color:#333;font-family:'Inter',-apple-system,sans-serif;font-size:15px;line-height:1.7;min-height:100vh}
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
@keyframes slideDown{from{opacity:0;transform:translateY(-10px)}to{opacity:1;transform:translateY(0)}}
@keyframes spin{to{transform:rotate(360deg)}}
.fade-in{animation:fadeIn .3s ease both}
::-webkit-scrollbar{width:5px;height:5px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:#C4CDD5;border-radius:10px}
</style>
</head>
<body>

<!-- ── Top navigation bar ── -->
<div style="background:#fff;border-bottom:1px solid #E0E4E8;padding:0 32px;display:flex;align-items:center;height:62px;gap:14px;position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,.07);animation:slideDown .25s ease">
  <div style="width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,${accent},${isPF?'#0081A6':'#c9520f'});display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 3px 10px ${isPF?'rgba(0,94,124,.25)':'rgba(234,108,54,.3)'}">
    ${iconSVG}
  </div>
  <div>
    <div style="font-size:18px;font-weight:700;color:#1A2F4A;line-height:1.2">${title}</div>
    <div style="font-size:12px;color:#718096;margin-top:1px">Protiviti MRM Finding Library · Query: <em style="color:#4A5568">"${(data.query||'').replace(/</g,'&lt;').replace(/>/g,'&gt;')}"</em></div>
  </div>
  <div style="margin-left:auto;display:flex;align-items:center;gap:10px">
    ${data.findings && data.findings.length && isPF ? `<span style="background:${accentBg};color:${accent};border:1px solid ${isPF?'#C5D5F5':'rgba(234,108,54,.3)'};border-radius:20px;font-size:12px;font-family:monospace;font-weight:700;padding:4px 14px">${data.findings.length} Finding${data.findings.length!==1?'s':''} Matched</span>` : ''}
    <button onclick="window.close()" style="background:#F4F6F8;border:1px solid #E0E4E8;border-radius:8px;padding:7px 14px;cursor:pointer;font-size:12px;font-weight:500;color:#4A5568;display:flex;align-items:center;gap:6px;transition:all .15s" onmouseover="this.style.borderColor='#C4CDD5';this.style.color='#1A2F4A'" onmouseout="this.style.borderColor='#E0E4E8';this.style.color='#4A5568'">
      <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      Close
    </button>
  </div>
</div>

<!-- ── Cluster badge (if any) ── -->
${clusterInfo ? `<div style="max-width:1080px;margin:0 auto;padding:14px 32px 0">${clusterInfo}</div>` : ''}

<!-- ── Query box ── -->
${data.query ? `<div style="max-width:1080px;margin:0 auto;padding:${clusterInfo ? '10px' : '18px'} 32px 0">
  <div style="display:inline-flex;align-items:center;gap:9px;background:#fff;border:1px solid #D6E4F0;border-radius:8px;padding:8px 16px;box-shadow:0 1px 4px rgba(0,0,0,.06)">
    <svg width="13" height="13" fill="none" stroke="#005E7C" stroke-width="2.2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
    <span style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.09em;color:#718096;font-family:monospace">Query</span>
    <span style="width:1px;height:14px;background:#E0E4E8"></span>
    <span style="font-size:13px;font-weight:500;color:#1A2F4A;font-style:italic">"${(data.query||'').replace(/</g,'&lt;').replace(/>/g,'&gt;')}"</span>
  </div>
</div>` : ''}

<!-- ── Main content ── -->
<div style="max-width:1080px;margin:0 auto;padding:20px 32px 60px;animation:fadeIn .35s ease">
  ${bodyContent}
</div>

<script>
function switchTab(idx, pane) {
  const el = document.getElementById('pane-' + idx + '-' + pane);
  if (el) el.style.display = 'block';
}
<\/script>
</body>
</html>`;
}
