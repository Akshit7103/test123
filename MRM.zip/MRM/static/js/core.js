// ── State ──────────────────────────────────────────────────────────────────
let allFindings = [];
let allClusters = [];
let currentPage = 1;
const PAGE_SIZE = 25;
let filteredFindings = [];
let themeDonutChart = null;
let clusterBarChart = null;

// Cluster color cycling
const CLUSTER_COLORS = [1,2,3,4,5,6,7,8];
function clusterColorIdx(cid) {
  const n = parseInt(cid.replace('C','')) || 1;
  return ((n - 1) % CLUSTER_COLORS.length) + 1;
}

// ── Navigation ──────────────────────────────────────────────────────────────
const TITLES = {
  dashboard:'Dashboard', findings:'Findings Library',
  clusters:'Clusters', search:'Search & Query',
  'psi-calc':'PSI Calculator',
  'dq-checks':'Data Quality Checks',
  import:'Bulk Import', add:'Add New Finding'
};
const DESCS = {
  dashboard:'Overview & statistics', findings:'Browse and manage all findings',
  clusters:'Auto-generated semantic clusters', search:'Query by natural language',
  'psi-calc':'Population Stability Index · Model Drift Detection',
  'dq-checks':'Missing values · Outliers · Uniqueness',
  import:'Bulk import via CSV, JSON or file upload', add:'Create a new finding record'
};
function showPanel(name, el) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('panel-' + name).classList.add('active');
  if (el) el.classList.add('active');
  document.getElementById('page-title').textContent = TITLES[name] || name;
  document.getElementById('page-desc').textContent = DESCS[name] || '';
  closeGlobalDropdown();
  if (name === 'dashboard') renderDashboard();
  if (name === 'findings') { currentPage = 1; renderFindings(); }
  if (name === 'clusters') renderClusters();
}

// ── API ──────────────────────────────────────────────────────────────────────
async function apiFetch(url, opts={}) {
  const res = await fetch(url, {headers:{'Content-Type':'application/json'}, ...opts});
  const ct = res.headers.get('content-type') || '';
  if (!ct.includes('application/json')) {
    const text = await res.text();
    const msg = text.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 200);
    throw new Error('Server error ' + res.status + ': ' + msg);
  }
  return res.json();
}

async function loadAll() {
  [allFindings, allClusters] = await Promise.all([
    apiFetch('/api/findings'),
    apiFetch('/api/clusters'),
  ]);
  updateSidebar();
}

// ── Cluster polling ───────────────────────────────────────────────────────
let _pollTimer = null;

function showClusterBanner(msg) {
  let b = document.getElementById('cluster-banner');
  if (!b) {
    b = document.createElement('div');
    b.id = 'cluster-banner';
    b.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);' +
      'background:#005E7C;color:#fff;padding:9px 20px;border-radius:8px;font-size:13px;' +
      'font-weight:500;z-index:9999;box-shadow:0 4px 14px rgba(0,0,0,.18);' +
      'display:flex;align-items:center;gap:10px;transition:opacity .3s';
    document.body.appendChild(b);
  }
  b.innerHTML = '<span style="display:inline-block;width:10px;height:10px;border-radius:50%;' +
    'border:2px solid #fff;border-top-color:transparent;animation:spin .7s linear infinite"></span>' +
    msg;
  b.style.opacity = '1';
  // Ensure spin keyframe exists
  if (!document.getElementById('spin-style')) {
    const s = document.createElement('style');
    s.id = 'spin-style';
    s.textContent = '@keyframes spin{to{transform:rotate(360deg)}}';
    document.head.appendChild(s);
  }
}

function hideClusterBanner() {
  const b = document.getElementById('cluster-banner');
  if (b) { b.style.opacity = '0'; setTimeout(() => b.remove(), 350); }
}

async function pollUntilClustered(onDone) {
  clearTimeout(_pollTimer);
  showClusterBanner('Re-clustering findings\u2026');
  const check = async () => {
    try {
      const s = await apiFetch('/api/clusters/status');
      if (!s.busy) {
        // Clustering done — refresh clusters and update UI
        allClusters = await apiFetch('/api/clusters');
        updateSidebar();
        renderClusters();
        renderFindings();
        renderDashboard();
        hideClusterBanner();
        if (onDone) onDone(s.count);
      } else {
        _pollTimer = setTimeout(check, 800);
      }
    } catch(e) {
      hideClusterBanner();
    }
  };
  // Give the thread a moment to start, then begin polling
  _pollTimer = setTimeout(check, 400);
}

function updateSidebar() {
  document.getElementById('s-findings').textContent = allFindings.length;
  document.getElementById('s-clusters').textContent = allClusters.length;
}

function findClusterForFinding(fid) {
  return allClusters.find(c => c.findings_included.includes(fid));
}

// ── Dashboard ──────────────────────────────────────────────────────────────
const CHART_PALETTE = ['#005E7C','#EA6C36','#2B6CB0','#38A169','#D69E2E','#E53E3E','#0081A6','#6B46C1'];

function renderDashboard() {
  const kpis = [
    {label:'Total Findings', value:allFindings.length, sub:'records in library', color:'var(--primary)'},
    {label:'Active Clusters', value:allClusters.length, sub:'semantic groups', color:'var(--accent)'},
    {label:'Avg Cluster Size', value:allClusters.length ? (allFindings.length/allClusters.length).toFixed(1) : '—', sub:'findings per cluster', color:'var(--success)'},
  ];
  document.getElementById('kpi-row').innerHTML = kpis.map((k,i) => `
    <div class="kpi fade-in" style="animation-delay:${i*0.05}s">
      <div class="kpi-accent" style="background:${k.color}"></div>
      <div class="kpi-label">${k.label}</div>
      <div class="kpi-value">${k.value}</div>
      <div class="kpi-sub">${k.sub}</div>
    </div>`).join('');

  // ── Theme Donut ───────────────────────────────────────────────────────
  const themeCounts = {};
  allFindings.forEach(f => {
    const t = f.model_theme || 'Unclassified';
    themeCounts[t] = (themeCounts[t] || 0) + 1;
  });
  const themeEntries = Object.entries(themeCounts).sort((a,b) => b[1]-a[1]);
  const total = allFindings.length || 1;
  const DCX = 90, DCY = 90, DR = 72, DIR = 44;
  let cumAngle = -Math.PI/2;
  const slices = themeEntries.map(([name, count], idx) => {
    const angle = (count / total) * 2 * Math.PI;
    const x1 = DCX + DR*Math.cos(cumAngle), y1 = DCY + DR*Math.sin(cumAngle);
    cumAngle += angle;
    const x2 = DCX + DR*Math.cos(cumAngle), y2 = DCY + DR*Math.sin(cumAngle);
    const xi1 = DCX + DIR*Math.cos(cumAngle-angle), yi1 = DCY + DIR*Math.sin(cumAngle-angle);
    const xi2 = DCX + DIR*Math.cos(cumAngle), yi2 = DCY + DIR*Math.sin(cumAngle);
    const large = angle > Math.PI ? 1 : 0;
    const path = `M${x1},${y1} A${DR},${DR} 0 ${large},1 ${x2},${y2} L${xi2},${yi2} A${DIR},${DIR} 0 ${large},0 ${xi1},${yi1} Z`;
    return {path, color: CHART_PALETTE[idx % CHART_PALETTE.length], name, count};
  });
  const donutSVG = `<svg viewBox="0 0 180 180" width="180" height="180" style="flex-shrink:0">
    ${slices.map(s => `<path d="${s.path}" fill="${s.color}" opacity="0.9" stroke="#fff" stroke-width="1.5"><title>${s.name}: ${s.count} (${((s.count/total)*100).toFixed(1)}%)</title></path>`).join('')}
    <text x="90" y="82" text-anchor="middle" font-size="22" font-weight="700" fill="#333">${total}</text>
    <text x="90" y="96" text-anchor="middle" font-size="8.5" fill="#718096" font-family="sans-serif" font-weight="600">TOTAL</text>
    <text x="90" y="108" text-anchor="middle" font-size="8" fill="#718096" font-family="sans-serif">FINDINGS</text>
  </svg>`;
  const legendHTML = slices.map(s => {
    const pct = ((s.count/total)*100).toFixed(1);
    return `
    <div class="donut-legend-item">
      <div class="donut-legend-dot" style="background:${s.color}"></div>
      <span class="donut-legend-label">${s.name}</span>
      <span style="font-family:var(--font-mono);font-size:10px;color:var(--muted);margin-right:4px">${pct}%</span>
      <span class="donut-legend-val">${s.count}</span>
    </div>`;}).join('');
  const themeEl = document.getElementById('theme-donut-chart');
  if (themeEl) themeEl.innerHTML = `<div class="donut-wrap">${donutSVG}<div class="donut-legend">${legendHTML}</div></div>`;

  // ── Cluster Overview (compact scrollable list) ────────────────────────
  const summaryEl = document.getElementById('cluster-summary');
  if (summaryEl) {
    if (!allClusters.length) {
      summaryEl.innerHTML = '<div class="empty" style="padding:32px 20px"><p>No clusters yet.</p></div>';
    } else {
      summaryEl.innerHTML = allClusters.map((c, i) => {
        const ci = clusterColorIdx(c.cluster_id);
        const color = CHART_PALETTE[(ci-1) % CHART_PALETTE.length];
        const themes = [...new Set(c.findings_included
          .map(fid => allFindings.find(f=>f.finding_id===fid))
          .filter(Boolean).map(f=>f.model_theme).filter(Boolean))];
        const signals = (c.semantic_signals||'').split(',').slice(0,3).map(s=>s.trim()).join(' · ');
        const label = c.semantic_label || '';
        return `<div onclick="openClusterModal('${c.cluster_id}')" style="display:flex;align-items:center;gap:12px;padding:11px 20px;border-bottom:1px solid var(--border);cursor:pointer;transition:background .15s;${i===allClusters.length-1?'border-bottom:none':''}" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
          <div style="width:9px;height:9px;border-radius:50%;background:${color};flex-shrink:0"></div>
          <div style="flex:1;min-width:0">
            <div style="display:flex;align-items:center;gap:7px;margin-bottom:2px;flex-wrap:wrap">
              <span style="font-family:var(--font-mono);font-size:12px;font-weight:600;color:${color}">${c.cluster_id}</span>
              <span style="font-size:11px;color:var(--text-secondary);font-weight:500">${c.size} finding${c.size!==1?'s':''}</span>
              <span style="font-size:10px;color:var(--muted);font-family:var(--font-mono)">(${allFindings.length?((c.size/allFindings.length)*100).toFixed(0):0}%)</span>
              ${label ? `<span style="font-size:10px;color:var(--primary);background:var(--primary-bg);border:1px solid var(--primary)33;border-radius:3px;padding:1px 6px;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${label}">${label}</span>` : ''}
            </div>
            <div style="font-size:10px;color:var(--muted);font-family:var(--font-mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">Signals: ${signals||'—'}</div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:2px;justify-content:flex-end;max-width:80px;flex-shrink:0">
            ${c.findings_included.slice(0,3).map(f=>`<span class="tag tag-id" style="font-size:9px;padding:1px 5px">${f}</span>`).join('')}
            ${c.findings_included.length>3?`<span style="font-size:9px;color:var(--muted);font-family:var(--font-mono);align-self:center">+${c.findings_included.length-3}</span>`:''}
          </div>
        </div>`;
      }).join('');
    }
  }

  // ── Pipeline ──────────────────────────────────────────────────────────
  const pipeSteps = [
    {
      label:'Content-Weighted Ingestion',
      desc:'Description×8, Business Justification×7, Title×1, Remediation×1 — model theme excluded from clustering signal',
      icon:`<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>`,
      bg:'#E6F3F7', color:'#005E7C', arrow:true
    },
    {
      label:'Sublinear TF-IDF (Bigrams)',
      desc:'Unigram + bigram vectors, L2-normalised, 95% max-df pruning',
      icon:`<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>`,
      bg:'#FDF1EA', color:'#EA6C36', arrow:true
    },
    {
      label:'Gap Stat + Silhouette Auto-k',
      desc:'score = 0.55×gap(normalised) + 0.45×silhouette − 0.002k; no theme anchoring',
      icon:`<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>`,
      bg:'#EBF8FF', color:'#2B6CB0', arrow:true
    },
    {
      label:'Bisecting K-Means',
      desc:'Stable semantic groups via recursive bisection + cosine similarity',
      icon:`<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>`,
      bg:'#F0FFF4', color:'#38A169', arrow:true
    },
    {
      label:'Semantic Label Output',
      desc:'Dominant theme (post-hoc only) + discriminative bigrams → human-readable cluster label',
      icon:`<svg width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>`,
      bg:'#FFFFF0', color:'#D69E2E', arrow:false
    },
  ];
  document.getElementById('pipeline-viz').innerHTML = pipeSteps.map((s,i) => `
    <div class="pipe-step fade-in" style="animation-delay:${i*0.07}s">
      <div class="pipe-step-icon-wrap" style="background:${s.bg};border:1.5px solid ${s.color}33">
        <span style="color:${s.color}">${s.icon}</span>
      </div>
      <div class="pipe-step-num" style="color:${s.color}">Step ${i+1}</div>
      <div class="pipe-step-label">${s.label}</div>
    </div>
    ${s.arrow ? `<div class="pipe-connector"><div class="pipe-connector-line"></div></div>` : ''}`).join('');
}
// ── Findings Library ──────────────────────────────────────────────────────
function renderFindings() {
  // populate cluster filter
  const cf = document.getElementById('cluster-filter-sel');
  const currentFilter = cf.value;
  cf.innerHTML = '<option value="">All Clusters</option>' +
    allClusters.map(c => `<option${currentFilter===c.cluster_id?' selected':''}>${c.cluster_id}</option>`).join('');
  filterFindings();
}

function filterFindings() {
  const q = (document.getElementById('find-filter').value || '').toLowerCase();
  const clusterFilter = document.getElementById('cluster-filter-sel').value;
  filteredFindings = allFindings.filter(f => {
    const matchQ = !q || [f.finding_id, f.model_theme, f.title, f.description, f.business_justification].some(s => s && s.toLowerCase().includes(q));
    const matchC = !clusterFilter || (() => {
      const cl = findClusterForFinding(f.finding_id);
      return cl && cl.cluster_id === clusterFilter;
    })();
    return matchQ && matchC;
  });
  currentPage = 1;
  renderFindingsPage();
}

function renderFindingsPage() {
  const total = filteredFindings.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  if (currentPage > totalPages) currentPage = totalPages;
  const start = (currentPage - 1) * PAGE_SIZE;
  const pageItems = filteredFindings.slice(start, start + PAGE_SIZE);

  document.getElementById('findings-count-label').textContent =
    `Showing ${start+1}–${Math.min(start+PAGE_SIZE, total)} of ${total} finding${total!==1?'s':''}`;
  document.getElementById('page-info').textContent =
    `Page ${currentPage} of ${totalPages} · ${total} result${total!==1?'s':''}`;
  document.getElementById('btn-prev').disabled = currentPage <= 1;
  document.getElementById('btn-next').disabled = currentPage >= totalPages;

  document.getElementById('findings-tbody').innerHTML = pageItems.length
    ? pageItems.map(f => {
        const cl = findClusterForFinding(f.finding_id);
        const ci = cl ? clusterColorIdx(cl.cluster_id) : 1;
        return `<tr>
          <td><span class="tag tag-id">${f.finding_id}</span></td>
          <td style="min-width:140px;max-width:180px"><div class="cell-truncate" style="font-size:12px;color:var(--text-secondary)">${f.model_theme || '<span style="color:var(--muted)">—</span>'}</div></td>
          <td style="min-width:200px;max-width:260px"><div class="cell-truncate" style="font-weight:500">${f.title}</div></td>
          <td style="max-width:260px"><div class="cell-truncate" style="color:var(--text-secondary)">${f.description}</div></td>
          <td style="max-width:260px"><div class="cell-truncate" style="color:var(--text-secondary)">${f.business_justification}</div></td>
          <td>${cl ? `<span class="tag c-bg-${ci} c-color-${ci}" style="cursor:pointer" onclick="openClusterModal('${cl.cluster_id}')">${cl.cluster_id}</span>` : '<span style="color:var(--muted);font-size:11px">—</span>'}</td>
          <td>
            <button class="btn btn-outline btn-sm" onclick="openFindingModal('${f.finding_id}')">View</button>
            <button class="btn btn-danger btn-sm" style="margin-left:4px" onclick="deleteFinding('${f.finding_id}')">✕</button>
          </td>
        </tr>`;}).join('')
    : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--muted)">No findings match the current filter</td></tr>';
}

function changePage(delta) {
  currentPage += delta;
  renderFindingsPage();
}

// ── Clusters ──────────────────────────────────────────────────────────────
function renderClusters() {
  document.getElementById('cluster-grid').innerHTML = allClusters.length
    ? allClusters.map((c,i) => {
        const ci = clusterColorIdx(c.cluster_id);
        const signals = c.semantic_signals ? c.semantic_signals.split(',').slice(0,6).map(s=>s.trim()).join(' · ') : '';
        return `<div class="cluster-card fade-in" style="animation-delay:${i*0.04}s" onclick="openClusterModal('${c.cluster_id}')">
          <div class="cluster-card-accent" style="background:var(--cluster-${ci%6+1},var(--primary))"></div>
          <div class="cluster-card-inner">
            <div class="cluster-id c-color-${ci}">${c.cluster_id} <span style="font-weight:400;color:var(--muted)">· ${c.findings_included.length} finding${c.findings_included.length!==1?'s':''}</span></div>
            ${c.semantic_label ? `<div style="font-size:11px;font-weight:600;color:var(--text-secondary);margin-bottom:6px;padding:3px 7px;background:var(--bg);border-radius:4px;border-left:2px solid var(--cluster-${ci%6+1},var(--primary));display:inline-block">${c.semantic_label}</div>` : ''}
            <div class="cluster-findings">
              ${c.findings_included.map(fid => `<span class="tag tag-id" style="font-size:10px">${fid}</span>`).join('')}
            </div>
            ${signals ? `<div class="cluster-signals">${signals}</div>` : ''}
          </div>
          <div class="cluster-count">${c.findings_included.length}</div>
        </div>`;}).join('')
    : '<div class="empty"><div class="empty-icon">◎</div><p>No clusters yet. Add findings to generate clusters automatically.</p></div>';
}

async function rerunClustering() {
  const k = document.getElementById('k-val').value;
  showAlert('Re-running semantic clustering…', 'info');
  const res = await apiFetch('/api/clusters/rerun', {method:'POST', body:JSON.stringify({k:k?+k:null})});
  await loadAll();
  renderClusters();
  showAlert(`Clustering complete — ${res.clusters} clusters generated`, 'success');
}

