
function clearForm() {
  ['f-id','f-title','f-desc','f-just','f-rem'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  const theme = document.getElementById('f-theme');
  if (theme) theme.value = '';
}

async function deleteFinding(fid) {
  if (!confirm('Delete finding ' + fid + '? This will trigger re-clustering.')) return;
  await apiFetch('/api/findings/' + fid, {method:'DELETE'});
  allFindings = await apiFetch('/api/findings');
  updateSidebar();
  renderFindings();
  showAlert('Finding ' + fid + ' deleted. Re-clustering\u2026', 'success');
  pollUntilClustered(null);
}

// ── File Upload ──────────────────────────────────────────────────────────
let selectedFile = null;

function fileDropOver(e) {
  e.preventDefault();
  const z = document.getElementById('file-drop-zone');
  z.style.borderColor = 'var(--primary-light)';
  z.style.background = 'var(--primary-bg)';
}

function fileDropLeave(e) {
  const z = document.getElementById('file-drop-zone');
  z.style.borderColor = 'var(--border)';
  z.style.background = 'var(--bg)';
}

function fileDropped(e) {
  e.preventDefault();
  fileDropLeave(e);
  const file = e.dataTransfer.files[0];
  if (file) setUploadFile(file);
}

function fileSelected(input) {
  if (input.files[0]) setUploadFile(input.files[0]);
}

function setUploadFile(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (!['xlsx', 'xls', 'csv'].includes(ext)) {
    showAlert('Unsupported file type. Please upload .xlsx, .xls, or .csv', 'error');
    return;
  }
  selectedFile = file;
  document.getElementById('file-name').textContent = file.name;
  document.getElementById('file-size').textContent = (file.size / 1024).toFixed(1) + ' KB';
  document.getElementById('file-preview').style.display = '';
  document.getElementById('file-drop-zone').style.opacity = '0.5';
  document.getElementById('btn-upload-file').disabled = false;
  document.getElementById('import-result-file').innerHTML = '';
}

function clearFileUpload() {
  selectedFile = null;
  document.getElementById('file-upload-input').value = '';
  document.getElementById('file-preview').style.display = 'none';
  document.getElementById('file-drop-zone').style.opacity = '1';
  document.getElementById('btn-upload-file').disabled = true;
  document.getElementById('import-result-file').innerHTML = '';
}

async function uploadFile() {
  if (!selectedFile) return;
  const btn = document.getElementById('btn-upload-file');
  const resultEl = document.getElementById('import-result-file');
  btn.disabled = true;
  btn.textContent = 'Uploading…';
  resultEl.innerHTML = '';
  const fd = new FormData();
  fd.append('file', selectedFile);
  try {
    const res = await fetch('/api/findings/upload', { method: 'POST', body: fd });
    let data;
    const ct = res.headers.get('content-type') || '';
    if (ct.includes('application/json')) {
      data = await res.json();
    } else {
      const text = await res.text();
      const msg = text.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 200);
      throw new Error('Server error ' + res.status + ': ' + msg);
    }
    if (data.error) {
      resultEl.innerHTML = '<div class="alert alert-error">\u2717 ' + data.error + '</div>';
    } else {
      // Refresh findings immediately; clusters will arrive via poll
      allFindings = await apiFetch('/api/findings');
      updateSidebar();
      resultEl.innerHTML =
        '<div class="alert alert-success">\u2713 Added ' + data.added + ' findings (' + data.skipped + ' skipped). Total: ' + data.total + '.</div>';
      clearFileUpload();
      pollUntilClustered(function(count) {
        showAlert('Clustering complete \u2014 ' + count + ' clusters ready.', 'success');
      });
    }
  } catch(e) {
    resultEl.innerHTML = '<div class="alert alert-error">\u2717 Upload failed: ' + e.message + '</div>';
  }
  btn.textContent = 'Import File';
  btn.disabled = false;
}

// ── Import ────────────────────────────────────────────────────────────────
function switchTab(tab) {
  document.querySelectorAll('.import-tab').forEach(t => { t.style.display='none'; t.classList.remove('active'); });
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  const tabEl = document.getElementById('import-' + tab);
  tabEl.style.display = '';
  tabEl.classList.add('active');
  document.getElementById('tab-' + tab).classList.add('active');
}

async function importCSV() {
  const raw = document.getElementById('csv-input').value.trim();
  if (!raw) return;
  const rows = raw.split('\n').map(line => {
    const parts = line.split(',').map(s => s.trim());
    if (parts.length < 4) return null;
    // 6-col: finding_id, model_theme, title, description, business_justification, suggested_remediation
    if (parts.length >= 6) {
      return {
        finding_id: parts[0],
        model_theme: parts[1],
        title: parts[2],
        description: parts.slice(3, parts.length - 2).join(','),
        business_justification: parts[parts.length - 2],
        suggested_remediation: parts[parts.length - 1],
      };
    }
    // 5-col: finding_id, model_theme, title, description, business_justification
    if (parts.length === 5) {
      return {
        finding_id: parts[0],
        model_theme: parts[1],
        title: parts[2],
        description: parts.slice(3, parts.length - 1).join(','),
        business_justification: parts[parts.length - 1],
        suggested_remediation: '',
      };
    }
    // 4-col: finding_id, title, description, business_justification
    return {
      finding_id: parts[0],
      model_theme: '',
      title: parts[1],
      description: parts.slice(2, parts.length - 1).join(','),
      business_justification: parts[parts.length - 1],
      suggested_remediation: '',
    };
  }).filter(Boolean);
  if (!rows.length) { showAlert('No valid rows found', 'error'); return; }
  const res = await apiFetch('/api/findings/bulk', {method:'POST', body:JSON.stringify(rows)});
  allFindings = await apiFetch('/api/findings');
  updateSidebar();
  document.getElementById('import-result').innerHTML = '<div class="alert alert-success">\u2713 Added ' + res.added + ' findings (' + res.skipped + ' skipped). Total: ' + res.total + '.</div>';
  pollUntilClustered(function(count) {
    showAlert('Clustering complete \u2014 ' + count + ' clusters ready.', 'success');
  });
}

async function importJSON() {
  try {
    const data = JSON.parse(document.getElementById('json-input').value);
    const res = await apiFetch('/api/findings/bulk', {method:'POST', body:JSON.stringify(data)});
    allFindings = await apiFetch('/api/findings');
    updateSidebar();
    document.getElementById('import-result-json').innerHTML = '<div class="alert alert-success">\u2713 Added ' + res.added + ' findings (' + res.skipped + ' skipped). Total: ' + res.total + '.</div>';
    pollUntilClustered(function(count) {
      showAlert('Clustering complete \u2014 ' + count + ' clusters ready.', 'success');
    });
  } catch(e) {
    document.getElementById('import-result-json').innerHTML = '<div class="alert alert-error">\u2717 Invalid JSON: ' + e.message + '</div>';
  }
}

function downloadTemplate() {
  const csv = 'Finding ID,Model Theme,Title,Description,Business Justification,Suggested Remediation\nF013,Model Governance,Example Finding Title,Detailed description of the issue observed including what controls are missing or deficient,Business and regulatory rationale for why this finding matters,"- Implement step one\n- Implement step two"\nF014,,Second Example Title,Description of the second finding,Regulatory rationale for the second finding,\n';
  const a = document.createElement('a');
  a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
  a.download = 'mrm_finding_template.csv';
  a.click();
}

// ── Modals ────────────────────────────────────────────────────────────────
function openFindingModal(fid) {
  const f = allFindings.find(x => x.finding_id === fid);
  if (!f) return;
  const cl = findClusterForFinding(fid);
  const ci = cl ? clusterColorIdx(cl.cluster_id) : 1;
  document.getElementById('modal-badge').textContent = f.finding_id + (cl ? ' · ' + cl.cluster_id : '');
  document.getElementById('modal-title').textContent = f.title;
  document.getElementById('modal-content').innerHTML = `
    ${f.model_theme ? `<div class="modal-section">
      <h4>Model Theme</h4>
      <p><span class="tag tag-success" style="font-size:12px">${f.model_theme}</span></p>
    </div>` : ''}
    <div class="modal-section">
      <h4>Description</h4>
      <p>${f.description}</p>
    </div>
    <div class="modal-section">
      <h4>Business Justification</h4>
      <p>${f.business_justification}</p>
    </div>
    ${f.suggested_remediation ? `<div class="modal-section">
      <h4 style="display:flex;align-items:center;gap:8px">Suggested Remediation <span class="rem-badge">✓ Action Required</span></h4>
      <ul class="remediation-list">
        ${f.suggested_remediation.split('\n').filter(l=>l.trim()).map(line => {
          const text = line.replace(/^[-•*]\s*/, '').trim();
          return text ? `<li><span>${text}</span></li>` : '';
        }).join('')}
      </ul>
    </div>` : ''}
    ${cl ? `<div class="modal-section">
      <h4>Assigned Cluster</h4>
      <p><span class="tag c-bg-${ci} c-color-${ci}" style="font-size:12px;font-weight:600">${cl.cluster_id}</span></p>
      <p style="margin-top:8px;font-size:12px;color:var(--muted)">${cl.why_grouped}</p>
    </div>` : ''}`;
  document.getElementById('modal-backdrop').classList.add('open');
}

function openClusterModal(cid) {
  const c = allClusters.find(x => x.cluster_id === cid);
  if (!c) return;
  const ci = clusterColorIdx(cid);
  document.getElementById('modal-badge').textContent = cid;
  document.getElementById('modal-title').textContent = c.semantic_label ? `${cid} — ${c.semantic_label}` : `Cluster ${cid}`;
  const members = c.findings_included.map(fid => {
    const f = allFindings.find(x => x.finding_id === fid);
    return f ? `<div class="finding-item">
      <div class="fi-header"><span class="tag tag-id">${f.finding_id}</span>${f.model_theme ? `<span class="tag tag-success" style="font-size:10px;margin-left:6px">${f.model_theme}</span>` : ''}</div>
      <div class="fi-title">${f.title}</div>
      <div class="fi-desc">${f.description.substring(0,200)}…</div>
    </div>` : '';
  }).join('');
  document.getElementById('modal-content').innerHTML = `
    ${c.semantic_label ? `<div class="modal-section">
      <h4>Semantic Label</h4>
      <p style="font-size:13px;font-weight:600;color:var(--primary);padding:8px 12px;background:var(--primary-bg);border-radius:6px;border-left:3px solid var(--primary)">${c.semantic_label}</p>
    </div>` : ''}
    <div class="modal-section">
      <h4>Semantic Signals (bigrams + unigrams)</h4>
      <p style="font-family:var(--font-mono);font-size:12px;background:var(--bg);padding:10px;border-radius:6px;border:1px solid var(--border);line-height:1.7">${c.semantic_signals}</p>
    </div>
    <div class="modal-section">
      <h4>Findings in this Cluster (${c.findings_included.length})</h4>
      <div style="display:flex;flex-wrap:wrap;gap:5px;margin-bottom:12px">
        ${c.findings_included.map(f=>`<span class="tag tag-id">${f}</span>`).join('')}
      </div>
      ${members}
    </div>
    <div class="modal-section">
      <h4>Why Grouped Together</h4>
      <p>${c.why_grouped}</p>
    </div>`;
  document.getElementById('modal-backdrop').classList.add('open');
}

function closeModal(e) {
  if (!e || e.target === document.getElementById('modal-backdrop')) {
    document.getElementById('modal-backdrop').classList.remove('open');
  }
}

// ── Alerts ────────────────────────────────────────────────────────────────
function showAlert(msg, type='info') {
  const z = document.getElementById('alert-zone');
  const div = document.createElement('div');
  div.className = `alert alert-${type} fade-in`;
  div.textContent = msg;
  z.appendChild(div);
  setTimeout(() => div.remove(), 3800);
}

// ── Init ──────────────────────────────────────────────────────────────────
(async () => {
  await loadAll();
  renderDashboard();
})();

