
// ════════════════════════════════════════════════════════════════════════════
//  Data Quality Checks
// ════════════════════════════════════════════════════════════════════════════
function dqEscape(s){
  return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// Per-kind state — each sub-check owns its own dataset; switching tabs never
// carries data across.
const DQ_STATES = {
  missing: { headers:[], rows:[], lastResult:null },
  outlier: { headers:[], rows:[], lastResult:null },
  unique:  { headers:[], rows:[], lastResult:null },
  type:    { headers:[], rows:[], schema:{}, lastResult:null },
  range:   { headers:[], rows:[], ranges:{}, lastResult:null },
};

// Default ranges keyed by canonical variable name (suggested presets; user can override)
const DQ_DEFAULT_RANGES = {
  age:[18,100], credit_score:[300,900],
  loan_to_value_ratio:[0,1], ltv:[0,1],
  interest_rate:[0,40], dti:[0,1], debt_to_income:[0,1],
  probability_of_default:[0,1], pd:[0,1],
  loss_given_default:[0,1], lgd:[0,1],
  exposure_at_default:[0,Number.MAX_SAFE_INTEGER]
};
const DQ_TYPE_OPTIONS = ['String','Numeric','Integer','Date','Binary','String Category'];

const DQ_RESULT_ID = {
  missing:'dq-miss-results', outlier:'dq-out-results', unique:'dq-uniq-results',
  type:'dq-type-results', range:'dq-range-results'
};

function dqSwitchSubTab(name, el){
  ['missing','outlier','unique','type','range'].forEach(n=>{
    const tab = document.getElementById('dq-tab-'+n);
    const pane = document.getElementById('dq-pane-'+n);
    if (tab) tab.classList.toggle('active', n===name);
    if (pane) pane.style.display = (n===name)?'block':'none';
  });
}

function dqFmtBytes(n){
  if (!n) return '0 B';
  if (n < 1024) return n + ' B';
  if (n < 1024*1024) return (n/1024).toFixed(1) + ' KB';
  return (n/1024/1024).toFixed(2) + ' MB';
}

function dqShowFileChip(kind, file, headers, rows){
  const drop = document.getElementById('dq-drop-'+kind);
  const chip = document.getElementById('dq-chip-'+kind);
  const config = document.getElementById('dq-config-'+kind);
  if (drop) drop.style.display = 'none';
  if (chip){
    chip.style.display = 'flex';
    const nameEl = chip.querySelector('.dq-file-chip-name');
    const metaEl = chip.querySelector('.dq-file-chip-meta');
    if (nameEl) nameEl.textContent = file.name;
    if (metaEl) metaEl.textContent = `${dqFmtBytes(file.size)} · ${rows.length} rows × ${headers.length} columns`;
  }
  if (config) config.style.display = 'block';
}

function dqRemoveFile(kind){
  DQ_STATES[kind].headers = [];
  DQ_STATES[kind].rows = [];
  if (kind === 'type')  DQ_STATES[kind].schema = {};
  if (kind === 'range') DQ_STATES[kind].ranges = {};
  DQ_STATES[kind].lastResult = null;
  const drop = document.getElementById('dq-drop-'+kind);
  const chip = document.getElementById('dq-chip-'+kind);
  const config = document.getElementById('dq-config-'+kind);
  const results = document.getElementById(DQ_RESULT_ID[kind]);
  const input = document.getElementById('dq-file-'+kind);
  if (drop) drop.style.display = 'block';
  if (chip) chip.style.display = 'none';
  if (config) config.style.display = 'none';
  if (results) results.innerHTML = '';
  if (input) input.value = '';
}

function dqDragOver(ev, el){
  ev.preventDefault();
  if (el) el.classList.add('dragover');
}
function dqDragLeave(ev, el){
  if (el) el.classList.remove('dragover');
}
function dqDrop(ev, kind, el){
  ev.preventDefault();
  if (el) el.classList.remove('dragover');
  const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0];
  if (!f) return;
  dqHandleFile({target:{files:[f], value:''}}, kind);
}

function dqHandleFile(ev, kind){
  const f = ev.target.files && ev.target.files[0];
  if (!f) return;
  const name = f.name.toLowerCase();
  const ingest = (txt) => {
    const {headers, rows} = dqParseTable(txt);
    if (!headers.length){
      showAlert('File parsed but no header row was found.', 'warning');
      return;
    }
    DQ_STATES[kind].headers = headers;
    DQ_STATES[kind].rows = rows;
    if (kind === 'type')  DQ_STATES[kind].schema = {};
    if (kind === 'range') DQ_STATES[kind].ranges = {};
    DQ_STATES[kind].lastResult = null;
    const resultsEl = document.getElementById(DQ_RESULT_ID[kind]);
    if (resultsEl) resultsEl.innerHTML = '';
    dqShowFileChip(kind, f, headers, rows);
    dqPopulateKind(kind);
  };
  if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const wb = XLSX.read(new Uint8Array(e.target.result), {type:'array'});
        // Templates that ship with a leading "Guidance" tab were producing junk rows.
        // Prefer a sheet literally named "Input"; otherwise pick the first non-Guidance sheet.
        const inputName = wb.SheetNames.find(n => n.toLowerCase() === 'input')
                       || wb.SheetNames.find(n => n.toLowerCase() !== 'guidance')
                       || wb.SheetNames[0];
        const sheet = wb.Sheets[inputName];
        const csv = XLSX.utils.sheet_to_csv(sheet);
        ingest(csv);
      } catch(err){
        showAlert('Excel parse error: '+err.message, 'warning');
      }
    };
    reader.readAsArrayBuffer(f);
  } else {
    const reader = new FileReader();
    reader.onload = e => ingest(e.target.result);
    reader.readAsText(f);
  }
  if (ev.target && 'value' in ev.target) ev.target.value = '';
}

function dqSplitLine(line, delim){
  const out = []; let cur = ''; let q = false;
  for (let i=0;i<line.length;i++){
    const c = line[i];
    if (q){
      if (c === '"'){ if (line[i+1]==='"'){ cur+='"'; i++; } else q=false; }
      else cur += c;
    } else {
      if (c === '"') q = true;
      else if (c === delim){ out.push(cur); cur=''; }
      else cur += c;
    }
  }
  out.push(cur);
  return out;
}

function dqParseTable(txt){
  const lines = txt.replace(/\r\n?/g,'\n').split('\n').filter(l=>l.length>0);
  if (!lines.length) return {headers:[], rows:[]};
  const first = lines[0];
  const delim = (first.indexOf('\t') > -1) ? '\t' : ',';
  const headers = dqSplitLine(first, delim).map(h=>h.trim());
  const rows = lines.slice(1).map(l => {
    const cells = dqSplitLine(l, delim).map(c=>c.trim());
    while (cells.length < headers.length) cells.push('');
    return cells;
  });
  return {headers, rows};
}

function dqIsMissing(v){
  if (v === null || v === undefined) return true;
  const s = String(v).trim().toLowerCase();
  return s === '' || s === 'na' || s === 'n/a' || s === 'null' || s === 'none' || s === 'nan';
}

function dqEnsureState(kind){
  if (!DQ_STATES[kind].headers.length) {
    showAlert('Upload a CSV / TSV / XLSX file in this tab first.', 'warning');
    return false;
  }
  return true;
}

function dqPopulateKind(kind){
  if (kind === 'missing') dqPopulateMissing();
  else if (kind === 'outlier') dqPopulateOutlier();
  else if (kind === 'unique') dqPopulateUnique();
  else if (kind === 'type') dqPopulateType();
  else if (kind === 'range') dqPopulateRange();
}

function dqPopulateMissing(){
  const headers = DQ_STATES.missing.headers;
  const box = document.getElementById('dq-miss-cols');
  if (!box) return;
  if (!headers.length){
    box.innerHTML = '<span style="color:var(--muted);font-size:12px">Upload data to populate columns.</span>';
  } else {
    box.innerHTML = headers.map((h,i)=>
      `<button class="dq-col-pill active" data-idx="${i}" onclick="this.classList.toggle('active')">${dqEscape(h)}</button>`
    ).join('');
  }
}

function dqPopulateOutlier(){
  const {headers, rows} = DQ_STATES.outlier;
  const box = document.getElementById('dq-out-cols');
  if (!box) return;
  if (!headers.length){
    box.innerHTML = '<span style="color:var(--muted);font-size:12px">Upload data to populate columns.</span>';
  } else {
    let firstNumeric = -1;
    for (let i=0;i<headers.length;i++){
      const numeric = rows.some(r => !dqIsMissing(r[i]) && !isNaN(parseFloat(r[i])));
      if (numeric){ firstNumeric = i; break; }
    }
    box.innerHTML = headers.map((h,i)=>
      `<button class="dq-col-pill${i===firstNumeric?' active':''}" data-idx="${i}" onclick="dqOutSelect(${i})">${dqEscape(h)}</button>`
    ).join('');
  }
}

function dqPopulateUnique(){
  const headers = DQ_STATES.unique.headers;
  const box = document.getElementById('dq-uniq-cols');
  if (!box) return;
  if (!headers.length){
    box.innerHTML = '<span style="color:var(--muted);font-size:12px">Upload data to populate columns.</span>';
  } else {
    box.innerHTML = headers.map((h,i)=>
      `<button class="dq-col-pill${i===0?' active':''}" data-idx="${i}" onclick="dqUniqSelect(${i})">${dqEscape(h)}</button>`
    ).join('');
  }
}

function dqPopulateType(){
  const {headers, rows, schema} = DQ_STATES.type;
  const box = document.getElementById('dq-type-schema');
  if (!box) return;
  if (!headers.length){
    box.innerHTML = '<span style="color:var(--muted);font-size:12px">Upload data to populate schema.</span>';
    return;
  }
  if (Object.keys(schema).length === 0) dqAutoDetectSchema(true);
  box.innerHTML = `
    <div class="dq-table-wrap" style="max-height:none">
      <table class="dq-table">
        <thead><tr>
          <th>Variable</th>
          <th style="width:200px">Expected Type</th>
          <th>Detected From Data</th>
        </tr></thead>
        <tbody>
          ${headers.map((h,i) => {
            const detected = dqDetectType(rows.map(r=>r[i]));
            const current = DQ_STATES.type.schema[h] || detected;
            return `<tr>
              <td style="font-family:var(--font-mono);font-weight:600">${dqEscape(h)}</td>
              <td><select onchange="DQ_STATES.type.schema['${h.replace(/'/g,"\\'")}']=this.value" style="width:100%;padding:5px 8px;font-size:12px;border:1px solid var(--border);border-radius:6px;background:#fff">
                ${DQ_TYPE_OPTIONS.map(t => `<option value="${t}"${t===current?' selected':''}>${t}</option>`).join('')}
              </select></td>
              <td style="font-size:12px;color:var(--muted)">${detected}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
}

function dqPopulateRange(){
  const {headers, rows, ranges} = DQ_STATES.range;
  const box = document.getElementById('dq-range-rules');
  if (!box) return;
  if (!headers.length){
    box.innerHTML = '<span style="color:var(--muted);font-size:12px">Upload data to populate ranges.</span>';
    return;
  }
  const numericCols = [];
  headers.forEach((h,i) => {
    const vals = rows.map(r=>r[i]).filter(v=>!dqIsMissing(v));
    const nums = vals.filter(v => !isNaN(parseFloat(v)) && /^-?\d+(\.\d+)?([eE][-+]?\d+)?$/.test(String(v).trim()));
    if (nums.length && nums.length >= vals.length * 0.6) numericCols.push({h, i, nums: nums.map(parseFloat)});
  });
  if (!numericCols.length){
    box.innerHTML = '<span style="color:var(--muted);font-size:12px">No numeric columns detected.</span>';
    return;
  }
  box.innerHTML = `
    <div class="dq-table-wrap" style="max-height:none">
      <table class="dq-table">
        <thead><tr>
          <th>Variable</th>
          <th style="width:130px;text-align:right">Min</th>
          <th style="width:130px;text-align:right">Max</th>
          <th>Observed (min – max)</th>
        </tr></thead>
        <tbody>
          ${numericCols.map(({h,nums}) => {
            const obsMin = Math.min(...nums), obsMax = Math.max(...nums);
            const key = h.toLowerCase().replace(/\s+/g,'_');
            const preset = ranges[h] || DQ_DEFAULT_RANGES[key];
            const minV = preset ? preset[0] : '';
            const maxV = preset ? preset[1] : '';
            if (preset && !ranges[h]) ranges[h] = [preset[0], preset[1]];
            const safe = h.replace(/'/g,"\\'");
            return `<tr>
              <td style="font-family:var(--font-mono);font-weight:600">${dqEscape(h)}</td>
              <td><input type="number" step="any" value="${minV}" placeholder="min"
                oninput="dqSetRange('${safe}',0,this.value)"
                style="width:100%;padding:5px 8px;font-size:12px;font-family:var(--font-mono);border:1px solid var(--border);border-radius:6px;text-align:right"></td>
              <td><input type="number" step="any" value="${maxV}" placeholder="max"
                oninput="dqSetRange('${safe}',1,this.value)"
                style="width:100%;padding:5px 8px;font-size:12px;font-family:var(--font-mono);border:1px solid var(--border);border-radius:6px;text-align:right"></td>
              <td style="font-size:12px;color:var(--muted);font-family:var(--font-mono)">${dqFmt(obsMin)} — ${dqFmt(obsMax)}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
}

function dqSetRange(col, idx, val){
  const ranges = DQ_STATES.range.ranges;
  if (!ranges[col]) ranges[col] = [null, null];
  const num = (val === '' || val === null) ? null : parseFloat(val);
  ranges[col][idx] = (val === '' || isNaN(num)) ? null : num;
}

function dqOutSelect(idx){
  document.querySelectorAll('#dq-out-cols .dq-col-pill').forEach(b=>{
    b.classList.toggle('active', parseInt(b.dataset.idx,10)===idx);
  });
}
function dqUniqSelect(idx){
  document.querySelectorAll('#dq-uniq-cols .dq-col-pill').forEach(b=>{
    b.classList.toggle('active', parseInt(b.dataset.idx,10)===idx);
  });
}

// ─── Missing Values ───
function dqMissSeverity(pct){
  if (pct === 0) return {label:'None', cls:'dq-badge-none'};
  if (pct <= 15) return {label:'Low', cls:'dq-badge-low'};
  if (pct <= 25) return {label:'Medium', cls:'dq-badge-medium'};
  if (pct <= 50) return {label:'High', cls:'dq-badge-high'};
  return {label:'Critical', cls:'dq-badge-critical'};
}
function dqMissTreatment(pct, label){
  if (pct === 0) return 'No action — column is complete.';
  if (label === 'Low') return 'Impute with median (numeric) or mode (categorical). Document imputation in model card.';
  if (label === 'Medium') return 'Impute with median/mode and add an "is_missing" indicator flag for downstream models.';
  if (label === 'High') return 'Investigate root cause. Consider model-based imputation (KNN/MICE) and treat as separate feature.';
  return 'Drop column or escalate to data owner. Imputation likely to introduce bias at this missing rate.';
}
function dqComputeMissing(headers, rows, selectedIdx){
  return selectedIdx.map(i => {
    const total = rows.length;
    let miss = 0;
    for (let r=0;r<total;r++) if (dqIsMissing(rows[r][i])) miss++;
    const pct = total ? (miss/total*100) : 0;
    const sev = dqMissSeverity(pct);
    return {
      column: headers[i],
      total, missing: miss,
      pct: Math.round(pct*100)/100,
      severity: sev.label,
      sevClass: sev.cls,
      treatment: dqMissTreatment(pct, sev.label)
    };
  });
}
function dqRunMissing(){
  if (!dqEnsureState('missing')) return;
  const {headers, rows} = DQ_STATES.missing;
  const selected = Array.from(document.querySelectorAll('#dq-miss-cols .dq-col-pill.active'))
    .map(b => parseInt(b.dataset.idx,10));
  if (!selected.length){ showAlert('Select at least one column.', 'warning'); return; }
  const result = dqComputeMissing(headers, rows, selected);
  DQ_STATES.missing.lastResult = result;
  dqRenderMissing(result);
}
function dqRenderMissing(rows){
  const totalRows = DQ_STATES.missing.rows.length;
  const colsScanned = rows.length;
  const totalMissing = rows.reduce((s,r)=>s+r.missing, 0);
  const worst = rows.reduce((a,b)=>a.pct>b.pct?a:b, {pct:-1, column:'—'});
  const stats = `
    <div class="dq-stat-grid">
      <div class="dq-stat-card"><div class="dq-stat-label">Total Rows</div><div class="dq-stat-val">${totalRows}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Columns Scanned</div><div class="dq-stat-val">${colsScanned}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Total Missing Cells</div><div class="dq-stat-val">${totalMissing}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Worst Column</div><div class="dq-stat-val" style="font-size:13px">${dqEscape(worst.column)} · ${worst.pct.toFixed(1)}%</div></div>
    </div>`;
  const table = `
    <div class="dq-table-wrap">
      <table class="dq-table">
        <thead><tr>
          <th>Variable</th><th style="text-align:right">Total</th>
          <th style="text-align:right">Missing</th><th style="text-align:right">Missing %</th>
          <th>Severity</th><th>Suggested Treatment</th>
        </tr></thead>
        <tbody>
          ${rows.map(r=>`
            <tr>
              <td style="font-family:var(--font-mono);font-weight:600">${dqEscape(r.column)}</td>
              <td style="text-align:right;font-family:var(--font-mono)">${r.total}</td>
              <td style="text-align:right;font-family:var(--font-mono)">${r.missing}</td>
              <td style="text-align:right;font-family:var(--font-mono)">${r.pct.toFixed(2)}%</td>
              <td><span class="dq-badge ${r.sevClass}">${r.severity}</span></td>
              <td style="font-size:12px;color:#4A5568">${dqEscape(r.treatment)}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  document.getElementById('dq-miss-results').innerHTML = stats + table;
}

// ─── Outliers (IQR) ───
function dqPercentile(sorted, p){
  // Linear interpolation between closest ranks (matches Excel PERCENTILE.INC / numpy default)
  if (!sorted.length) return NaN;
  if (sorted.length === 1) return sorted[0];
  const idx = (sorted.length - 1) * p;
  const lo = Math.floor(idx), hi = Math.ceil(idx);
  if (lo === hi) return sorted[lo];
  return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
}
function dqOutlierTreatment(extreme, total){
  const pct = total ? extreme/total*100 : 0;
  if (pct === 0) return 'No extreme outliers — distribution looks clean. Continue periodic monitoring.';
  if (pct < 1) return 'Investigate individual records. Cap to upper/lower fence (winsorize) or remove if data-entry error.';
  if (pct < 5) return 'Cap at 1.5×IQR fences (winsorize) or apply log transformation before modelling.';
  return 'Significant tail. Consider robust methods (median, IQR-based) or transform feature; review collection process.';
}
function dqComputeOutlier(headers, rows, idx){
  const raw = rows.map(r => r[idx]).filter(v => !dqIsMissing(v));
  const nums = raw.map(v => parseFloat(v)).filter(v => !isNaN(v));
  const sorted = [...nums].sort((a,b)=>a-b);
  const n = sorted.length;
  const q1 = dqPercentile(sorted, 0.25);
  const q3 = dqPercentile(sorted, 0.75);
  const iqr = q3 - q1;
  const lower = q1 - 1.5*iqr;
  const upper = q3 + 1.5*iqr;
  const xLower = q1 - 3*iqr;
  const xUpper = q3 + 3*iqr;
  const records = [];
  rows.forEach((r,ri) => {
    const v = r[idx];
    if (dqIsMissing(v)) return;
    const num = parseFloat(v);
    if (isNaN(num)) return;
    let flag = 'OK';
    if (num < xLower || num > xUpper) flag = 'Extreme Outlier';
    else if (num < lower || num > upper) flag = 'Outlier';
    records.push({rowIdx: ri+1, value: num, flag});
  });
  const min = sorted[0], max = sorted[n-1];
  const mean = nums.reduce((s,v)=>s+v,0) / n;
  const median = dqPercentile(sorted, 0.5);
  const outliers = records.filter(r=>r.flag==='Outlier').length;
  const extreme = records.filter(r=>r.flag==='Extreme Outlier').length;
  return {
    column: headers[idx], n, min, max, mean, median,
    q1, q3, iqr, lower, upper, xLower, xUpper,
    outliers, extreme, records,
    treatment: dqOutlierTreatment(extreme, n)
  };
}
function dqFmt(v){
  if (typeof v !== 'number' || !isFinite(v)) return '—';
  if (Math.abs(v) >= 1000) return v.toLocaleString(undefined,{maximumFractionDigits:2});
  return v.toFixed(2);
}
function dqRunOutlier(){
  if (!dqEnsureState('outlier')) return;
  const {headers, rows} = DQ_STATES.outlier;
  const sel = document.querySelector('#dq-out-cols .dq-col-pill.active');
  if (!sel){ showAlert('Select a numeric column.', 'warning'); return; }
  const idx = parseInt(sel.dataset.idx, 10);
  const numeric = rows.some(r => !dqIsMissing(r[idx]) && !isNaN(parseFloat(r[idx])));
  if (!numeric){ showAlert('Selected column has no numeric values.', 'warning'); return; }
  const result = dqComputeOutlier(headers, rows, idx);
  DQ_STATES.outlier.lastResult = result;
  dqRenderOutlier(result);
}
function dqRenderOutlier(r){
  const stats = `
    <div class="dq-stat-grid">
      <div class="dq-stat-card"><div class="dq-stat-label">Column</div><div class="dq-stat-val" style="font-size:13px">${dqEscape(r.column)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Numeric N</div><div class="dq-stat-val">${r.n}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Min</div><div class="dq-stat-val">${dqFmt(r.min)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Max</div><div class="dq-stat-val">${dqFmt(r.max)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Mean</div><div class="dq-stat-val">${dqFmt(r.mean)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Median</div><div class="dq-stat-val">${dqFmt(r.median)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Q1 (25%)</div><div class="dq-stat-val">${dqFmt(r.q1)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Q3 (75%)</div><div class="dq-stat-val">${dqFmt(r.q3)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">IQR</div><div class="dq-stat-val">${dqFmt(r.iqr)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Lower Fence (1.5×)</div><div class="dq-stat-val">${dqFmt(r.lower)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Upper Fence (1.5×)</div><div class="dq-stat-val">${dqFmt(r.upper)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Outliers / Extreme</div><div class="dq-stat-val">${r.outliers} / ${r.extreme}</div></div>
    </div>
    <div class="dq-treatment"><strong>Treatment:</strong> ${dqEscape(r.treatment)}</div>`;
  const flagged = r.records.filter(x=>x.flag!=='OK').sort((a,b)=>{
    if (a.flag!==b.flag) return a.flag==='Extreme Outlier'?-1:1;
    return b.value - a.value;
  });
  const table = `
    <div class="dq-section-label">Flagged Records (${flagged.length})</div>
    <div class="dq-table-wrap">
      <table class="dq-table">
        <thead><tr>
          <th style="width:80px">Row #</th>
          <th style="text-align:right">Value</th>
          <th>Status</th>
        </tr></thead>
        <tbody>
          ${flagged.length===0?'<tr><td colspan="3" style="text-align:center;color:var(--muted);padding:18px">No outliers flagged.</td></tr>':
          flagged.map(x=>{
            const cls = x.flag==='Extreme Outlier'?'dq-badge-extreme':'dq-badge-high';
            return `<tr>
              <td style="font-family:var(--font-mono)">${x.rowIdx}</td>
              <td style="text-align:right;font-family:var(--font-mono)">${dqFmt(x.value)}</td>
              <td><span class="dq-badge ${cls}">${x.flag}</span></td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>`;
  document.getElementById('dq-out-results').innerHTML = stats + table;
}

// ─── Uniqueness ───
function dqComputeUnique(headers, rows, idx){
  const counts = new Map();
  let nonMissing = 0;
  rows.forEach(r => {
    const v = r[idx];
    if (dqIsMissing(v)) return;
    nonMissing++;
    const k = String(v).trim();
    counts.set(k, (counts.get(k)||0) + 1);
  });
  const total = rows.length;
  const unique = counts.size;
  let duplicateRows = 0;
  const dupes = [];
  for (const [k, c] of counts){
    if (c > 1){
      duplicateRows += (c - 1);
      dupes.push({value:k, count:c});
    }
  }
  dupes.sort((a,b)=>b.count - a.count);
  const dupPct = total ? (duplicateRows/total*100) : 0;
  let severity = {label:'None', cls:'dq-badge-none'};
  if (dupPct > 0 && dupPct <= 5) severity = {label:'Low', cls:'dq-badge-low'};
  else if (dupPct <= 15) severity = {label:'Medium', cls:'dq-badge-medium'};
  else if (dupPct <= 30) severity = {label:'High', cls:'dq-badge-high'};
  else if (dupPct > 30) severity = {label:'Critical', cls:'dq-badge-critical'};
  let treatment = 'Column is fully unique — safe as a primary key candidate.';
  if (dupPct > 0 && dupPct <= 5) treatment = 'Investigate the duplicates. If unintended, deduplicate; if expected, document the column is non-unique.';
  else if (dupPct <= 15) treatment = 'Material duplication. Review join logic / extraction query — likely a Cartesian or repeated extraction issue.';
  else if (dupPct > 15) treatment = 'High duplication — column is not a key. Use a composite key, or audit the source system.';
  return {
    column: headers[idx],
    total, nonMissing, missing: total - nonMissing,
    unique, duplicateRows, duplicateValues: dupes.length,
    pct: Math.round(dupPct*100)/100,
    severity: severity.label, sevClass: severity.cls,
    treatment, dupes
  };
}
function dqRunUnique(){
  if (!dqEnsureState('unique')) return;
  const {headers, rows} = DQ_STATES.unique;
  const sel = document.querySelector('#dq-uniq-cols .dq-col-pill.active');
  if (!sel){ showAlert('Select a column.', 'warning'); return; }
  const idx = parseInt(sel.dataset.idx, 10);
  const result = dqComputeUnique(headers, rows, idx);
  DQ_STATES.unique.lastResult = result;
  dqRenderUnique(result);
}
function dqRenderUnique(r){
  const stats = `
    <div class="dq-stat-grid">
      <div class="dq-stat-card"><div class="dq-stat-label">Column</div><div class="dq-stat-val" style="font-size:13px">${dqEscape(r.column)}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Total Rows</div><div class="dq-stat-val">${r.total}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Non-Missing</div><div class="dq-stat-val">${r.nonMissing}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Unique Values</div><div class="dq-stat-val">${r.unique}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Duplicate Rows</div><div class="dq-stat-val">${r.duplicateRows}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Duplicate %</div><div class="dq-stat-val">${r.pct.toFixed(2)}%</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Severity</div><div class="dq-stat-val"><span class="dq-badge ${r.sevClass}">${r.severity}</span></div></div>
    </div>
    <div class="dq-treatment"><strong>Treatment:</strong> ${dqEscape(r.treatment)}</div>`;
  const table = `
    <div class="dq-section-label">Duplicated Values (${r.dupes.length})</div>
    <div class="dq-table-wrap">
      <table class="dq-table">
        <thead><tr>
          <th>Value</th>
          <th style="text-align:right;width:120px">Occurrences</th>
        </tr></thead>
        <tbody>
          ${r.dupes.length===0?'<tr><td colspan="2" style="text-align:center;color:var(--muted);padding:18px">All values unique — no duplicates.</td></tr>':
          r.dupes.map(d=>`<tr>
            <td style="font-family:var(--font-mono)">${dqEscape(d.value)}</td>
            <td style="text-align:right;font-family:var(--font-mono)">${d.count}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  document.getElementById('dq-uniq-results').innerHTML = stats + table;
}

// ─── Data Type Check ───
const DQ_DATE_RE = /^(\d{4}[-\/]\d{1,2}[-\/]\d{1,2}|\d{1,2}[-\/]\d{1,2}[-\/]\d{4})$/;
function dqIsIntStrict(v){
  const s = String(v).trim();
  return /^-?\d+$/.test(s);
}
function dqIsNumStrict(v){
  const s = String(v).trim();
  return /^-?\d+(\.\d+)?([eE][-+]?\d+)?$/.test(s);
}
function dqIsDateStrict(v){
  const s = String(v).trim();
  if (!DQ_DATE_RE.test(s)) return false;
  const d = new Date(s);
  return !isNaN(d.getTime());
}
function dqIsBinary(v){
  const s = String(v).trim();
  return s === '0' || s === '1';
}
function dqDetectType(values){
  const vals = values.filter(v => !dqIsMissing(v));
  if (!vals.length) return 'String';
  const allBinary = vals.every(dqIsBinary);
  if (allBinary) return 'Binary';
  const allDate = vals.every(dqIsDateStrict);
  if (allDate) return 'Date';
  const allInt = vals.every(dqIsIntStrict);
  if (allInt) return 'Integer';
  const allNum = vals.every(dqIsNumStrict);
  if (allNum) return 'Numeric';
  // Categorical: low cardinality and mostly non-numeric
  const uniq = new Set(vals.map(v => String(v).trim()));
  const numericShare = vals.filter(dqIsNumStrict).length / vals.length;
  if (uniq.size <= Math.max(8, vals.length*0.4) && numericShare < 0.2) return 'String Category';
  return 'String';
}
function dqAutoDetectSchema(silent){
  const {headers, rows} = DQ_STATES.type;
  if (!headers.length){
    if (!silent) showAlert('Upload data first.', 'warning');
    return;
  }
  DQ_STATES.type.schema = {};
  headers.forEach((h,i) => {
    DQ_STATES.type.schema[h] = dqDetectType(rows.map(r=>r[i]));
  });
  if (!silent) dqPopulateType();
}
function dqIsValidType(value, expected){
  // Returns true if value is valid for expected type. Missing values are skipped upstream.
  switch (expected){
    case 'String':         return true;
    case 'Numeric':        return dqIsNumStrict(value);
    case 'Integer':        return dqIsIntStrict(value);
    case 'Date':           return dqIsDateStrict(value);
    case 'Binary':         return dqIsBinary(value);
    case 'String Category': return !dqIsNumStrict(value);
    default: return true;
  }
}
function dqTypeSeverity(pct){
  if (pct === 0) return {label:'None', cls:'dq-badge-none'};
  if (pct <= 5) return {label:'Low', cls:'dq-badge-low'};
  if (pct <= 15) return {label:'Medium', cls:'dq-badge-medium'};
  if (pct <= 30) return {label:'High', cls:'dq-badge-high'};
  return {label:'Critical', cls:'dq-badge-critical'};
}
function dqTypeTreatment(pct, expected){
  if (pct === 0) return 'All values conform to the expected type. No action required.';
  if (pct <= 5) return 'Coerce or quarantine the bad rows; document them in the data lineage notes.';
  if (pct <= 15) return 'Investigate ETL/parser. Recurrent type errors usually indicate an upstream schema mismatch.';
  if (pct <= 30) return 'Stop downstream consumption. The column is unreliable until source casting is fixed.';
  return 'Treat the column as untyped. Roll back the load and engage the data owner.';
}
function dqRunType(){
  if (!dqEnsureState('type')) return;
  const {headers, rows} = DQ_STATES.type;
  const idCol = headers[0]; // first column treated as record ID
  const summary = [];
  const offenders = [];
  headers.forEach((h, ci) => {
    if (ci === 0) return; // skip ID column from validation summary
    const expected = DQ_STATES.type.schema[h] || dqDetectType(rows.map(r=>r[ci]));
    DQ_STATES.type.schema[h] = expected;
    let invalid = 0;
    let nonMissing = 0;
    rows.forEach((r, ri) => {
      const v = r[ci];
      if (dqIsMissing(v)) return;
      nonMissing++;
      if (!dqIsValidType(v, expected)){
        invalid++;
        offenders.push({id:r[0], variable:h, value:v, expected});
      }
    });
    const total = rows.length;
    const pct = total ? invalid/total*100 : 0;
    const sev = dqTypeSeverity(pct);
    summary.push({
      column:h, expected, total, nonMissing, invalid,
      pct: Math.round(pct*100)/100,
      severity: sev.label, sevClass: sev.cls,
      treatment: dqTypeTreatment(pct, expected)
    });
  });
  const result = {summary, offenders, idCol};
  DQ_STATES.type.lastResult = result;
  dqRenderType(result);
}
function dqRenderType(r){
  const totalRows = DQ_STATES.type.rows.length;
  const totalInvalid = r.summary.reduce((s,x)=>s+x.invalid,0);
  const worst = r.summary.reduce((a,b)=>a.pct>b.pct?a:b, {pct:-1, column:'—'});
  const stats = `
    <div class="dq-stat-grid">
      <div class="dq-stat-card"><div class="dq-stat-label">Total Rows</div><div class="dq-stat-val">${totalRows}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Variables Scanned</div><div class="dq-stat-val">${r.summary.length}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Total Type Errors</div><div class="dq-stat-val">${totalInvalid}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Worst Variable</div><div class="dq-stat-val" style="font-size:13px">${dqEscape(worst.column)} · ${worst.pct.toFixed(1)}%</div></div>
    </div>`;
  const summaryTable = `
    <div class="dq-section-label">Validation Summary</div>
    <div class="dq-table-wrap" style="margin-bottom:16px">
      <table class="dq-table">
        <thead><tr>
          <th>Variable</th><th>Expected Type</th>
          <th style="text-align:right">Invalid</th>
          <th style="text-align:right">Invalid %</th>
          <th>Severity</th><th>Treatment</th>
        </tr></thead>
        <tbody>
          ${r.summary.map(x=>`
            <tr>
              <td style="font-family:var(--font-mono);font-weight:600">${dqEscape(x.column)}</td>
              <td><span class="dq-badge dq-badge-none">${dqEscape(x.expected)}</span></td>
              <td style="text-align:right;font-family:var(--font-mono)">${x.invalid}</td>
              <td style="text-align:right;font-family:var(--font-mono)">${x.pct.toFixed(2)}%</td>
              <td><span class="dq-badge ${x.sevClass}">${x.severity}</span></td>
              <td style="font-size:12px;color:#4A5568">${dqEscape(x.treatment)}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  const detailTable = `
    <div class="dq-section-label">Invalid Records (${r.offenders.length})</div>
    <div class="dq-table-wrap">
      <table class="dq-table">
        <thead><tr>
          <th>${dqEscape(r.idCol)}</th><th>Variable</th>
          <th>Invalid Value</th><th>Expected Type</th>
        </tr></thead>
        <tbody>
          ${r.offenders.length===0?'<tr><td colspan="4" style="text-align:center;color:var(--muted);padding:18px">No type violations.</td></tr>':
          r.offenders.map(o=>`<tr>
            <td style="font-family:var(--font-mono)">${dqEscape(o.id)}</td>
            <td style="font-family:var(--font-mono)">${dqEscape(o.variable)}</td>
            <td style="font-family:var(--font-mono);color:#9B2C24">${dqEscape(o.value)}</td>
            <td>${dqEscape(o.expected)}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  document.getElementById('dq-type-results').innerHTML = stats + summaryTable + detailTable;
}

// ─── Range Check ───
function dqRangeSeverity(pct){
  if (pct === 0) return {label:'None', cls:'dq-badge-none'};
  if (pct <= 5) return {label:'Low', cls:'dq-badge-low'};
  if (pct <= 15) return {label:'Medium', cls:'dq-badge-medium'};
  if (pct <= 30) return {label:'High', cls:'dq-badge-high'};
  return {label:'Critical', cls:'dq-badge-critical'};
}
function dqRangeTreatment(pct){
  if (pct === 0) return 'All values within tolerance. Continue periodic monitoring.';
  if (pct <= 5) return 'Cap at the boundary (winsorize) or quarantine. Likely entry errors.';
  if (pct <= 15) return 'Investigate the source feed. Patterns of out-of-range values usually point to unit / encoding mismatches.';
  if (pct <= 30) return 'Block downstream use. The column is failing business validation at material rate.';
  return 'Reject the load. Engage the data owner before any consumption.';
}
function dqRunRange(){
  if (!dqEnsureState('range')) return;
  const {headers, rows, ranges} = DQ_STATES.range;
  const idCol = headers[0];
  const colsWithRules = headers.map((h,i)=>({h,i})).filter(x => {
    const r = ranges[x.h];
    return r && r[0] !== null && r[1] !== null && r[0] !== undefined && r[1] !== undefined;
  });
  if (!colsWithRules.length){
    showAlert('Set min and max for at least one variable.', 'warning');
    return;
  }
  const summary = [];
  const offenders = [];
  colsWithRules.forEach(({h, i}) => {
    const [lo, hi] = ranges[h];
    let invalid = 0;
    let nonMissing = 0;
    rows.forEach(r => {
      const v = r[i];
      if (dqIsMissing(v)) return;
      nonMissing++;
      const num = parseFloat(v);
      const isNum = !isNaN(num) && isFinite(num);
      if (!isNum || num < lo || num > hi){
        invalid++;
        offenders.push({id:r[0], variable:h, value:v, lo, hi});
      }
    });
    const total = rows.length;
    const pct = total ? invalid/total*100 : 0;
    const sev = dqRangeSeverity(pct);
    summary.push({
      column:h, lo, hi, total, nonMissing, invalid,
      pct: Math.round(pct*100)/100,
      severity: sev.label, sevClass: sev.cls,
      treatment: dqRangeTreatment(pct)
    });
  });
  const result = {summary, offenders, idCol};
  DQ_STATES.range.lastResult = result;
  dqRenderRange(result);
}
function dqRenderRange(r){
  const totalRows = DQ_STATES.range.rows.length;
  const totalInvalid = r.summary.reduce((s,x)=>s+x.invalid,0);
  const worst = r.summary.reduce((a,b)=>a.pct>b.pct?a:b, {pct:-1, column:'—'});
  const stats = `
    <div class="dq-stat-grid">
      <div class="dq-stat-card"><div class="dq-stat-label">Total Rows</div><div class="dq-stat-val">${totalRows}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Variables Checked</div><div class="dq-stat-val">${r.summary.length}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Total Out-of-Range</div><div class="dq-stat-val">${totalInvalid}</div></div>
      <div class="dq-stat-card"><div class="dq-stat-label">Worst Variable</div><div class="dq-stat-val" style="font-size:13px">${dqEscape(worst.column)} · ${worst.pct.toFixed(1)}%</div></div>
    </div>`;
  const summaryTable = `
    <div class="dq-section-label">Validation Summary</div>
    <div class="dq-table-wrap" style="margin-bottom:16px">
      <table class="dq-table">
        <thead><tr>
          <th>Variable</th><th>Rule</th>
          <th style="text-align:right">Invalid</th>
          <th style="text-align:right">Invalid %</th>
          <th>Severity</th><th>Treatment</th>
        </tr></thead>
        <tbody>
          ${r.summary.map(x=>`
            <tr>
              <td style="font-family:var(--font-mono);font-weight:600">${dqEscape(x.column)}</td>
              <td style="font-family:var(--font-mono)">${dqFmt(x.lo)} – ${dqFmt(x.hi)}</td>
              <td style="text-align:right;font-family:var(--font-mono)">${x.invalid}</td>
              <td style="text-align:right;font-family:var(--font-mono)">${x.pct.toFixed(2)}%</td>
              <td><span class="dq-badge ${x.sevClass}">${x.severity}</span></td>
              <td style="font-size:12px;color:#4A5568">${dqEscape(x.treatment)}</td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  const detailTable = `
    <div class="dq-section-label">Invalid Records (${r.offenders.length})</div>
    <div class="dq-table-wrap">
      <table class="dq-table">
        <thead><tr>
          <th>${dqEscape(r.idCol)}</th><th>Variable</th>
          <th>Invalid Value</th><th>Expected Range</th>
        </tr></thead>
        <tbody>
          ${r.offenders.length===0?'<tr><td colspan="4" style="text-align:center;color:var(--muted);padding:18px">All values within range.</td></tr>':
          r.offenders.map(o=>`<tr>
            <td style="font-family:var(--font-mono)">${dqEscape(o.id)}</td>
            <td style="font-family:var(--font-mono)">${dqEscape(o.variable)}</td>
            <td style="font-family:var(--font-mono);color:#9B2C24">${dqEscape(o.value)}</td>
            <td style="font-family:var(--font-mono)">${dqFmt(o.lo)} – ${dqFmt(o.hi)}</td>
          </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  document.getElementById('dq-range-results').innerHTML = stats + summaryTable + detailTable;
}

// ─── Export ───
function dqExport(kind){
  const result = DQ_STATES[kind] && DQ_STATES[kind].lastResult;
  if (!result){
    showAlert('Run the check first to export results.', 'warning');
    return;
  }
  const csvEsc = v => {
    const s = String(v==null?'':v);
    return /[",\n]/.test(s) ? '"' + s.replace(/"/g,'""') + '"' : s;
  };
  let csv = '';
  let filename = 'dq_'+kind+'.csv';
  if (kind === 'missing'){
    csv = 'Variable,Total,Missing,Missing %,Severity,Treatment\n';
    csv += result.map(r => [r.column, r.total, r.missing, r.pct, r.severity, r.treatment].map(csvEsc).join(',')).join('\n');
  } else if (kind === 'outlier'){
    csv = `Column,${csvEsc(result.column)}\nN,${result.n}\nMin,${result.min}\nMax,${result.max}\nMean,${result.mean}\nMedian,${result.median}\nQ1,${result.q1}\nQ3,${result.q3}\nIQR,${result.iqr}\nLowerFence,${result.lower}\nUpperFence,${result.upper}\nExtremeLower,${result.xLower}\nExtremeUpper,${result.xUpper}\nOutliers,${result.outliers}\nExtremeOutliers,${result.extreme}\n\nRow,Value,Status\n`;
    csv += result.records.map(x => [x.rowIdx, x.value, x.flag].map(csvEsc).join(',')).join('\n');
  } else if (kind === 'unique'){
    csv = `Column,${csvEsc(result.column)}\nTotalRows,${result.total}\nNonMissing,${result.nonMissing}\nUnique,${result.unique}\nDuplicateRows,${result.duplicateRows}\nDuplicate %,${result.pct}\nSeverity,${result.severity}\nTreatment,${csvEsc(result.treatment)}\n\nValue,Occurrences\n`;
    csv += result.dupes.map(d => [d.value, d.count].map(csvEsc).join(',')).join('\n');
  } else if (kind === 'type'){
    csv = 'Variable,Expected Type,Invalid,Invalid %,Severity,Treatment\n';
    csv += result.summary.map(x => [x.column, x.expected, x.invalid, x.pct, x.severity, x.treatment].map(csvEsc).join(',')).join('\n');
    csv += `\n\n${csvEsc(result.idCol)},Variable,Invalid Value,Expected Type\n`;
    csv += result.offenders.map(o => [o.id, o.variable, o.value, o.expected].map(csvEsc).join(',')).join('\n');
  } else if (kind === 'range'){
    csv = 'Variable,Min,Max,Invalid,Invalid %,Severity,Treatment\n';
    csv += result.summary.map(x => [x.column, x.lo, x.hi, x.invalid, x.pct, x.severity, x.treatment].map(csvEsc).join(',')).join('\n');
    csv += `\n\n${csvEsc(result.idCol)},Variable,Invalid Value,Min,Max\n`;
    csv += result.offenders.map(o => [o.id, o.variable, o.value, o.lo, o.hi].map(csvEsc).join(',')).join('\n');
  }
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
}
