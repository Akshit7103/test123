// ── Search ────────────────────────────────────────────────────────────────
function setSearch(q) { document.getElementById('search-input').value = q; doSearch(); }

function switchResultTab(tid, pane) {
  const bar = document.getElementById(tid + '-bar');
  if (bar) bar.querySelectorAll('.frc-tab').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.pane === pane);
  });
  ['finding'].forEach(p => {
    const el = document.getElementById(tid + '-' + p);
    if (el) el.classList.toggle('active', p === pane);
  });
}

async function doSearch() {
  const q = document.getElementById('search-input').value.trim();
  if (!q) return;
  const res = await apiFetch('/api/search', {method:'POST', body:JSON.stringify({query:q})});
  _lastSearchResults = res; // cache for LLM analysis
  // Reset LLM panel on new search (will be re-created inline)
  const zone = document.getElementById('search-results');
  if (!res.cluster && !res.findings.length) {
    zone.innerHTML = '<div class="empty"><div class="empty-icon">⊘</div><p>No matches found. Try different keywords.</p></div>';
    return;
  }

  // ── Tab icon SVGs ──────────────────────────────────────────────────────────
  const tabIcons = {
    finding: `<svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>`,
    remediation: `<svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>`,
    validation: `<svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/><path d="M9 12h6M9 16h4"/></svg>`,
    regulatory: `<svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>`,
    ai: `<svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/><circle cx="19" cy="5" r="3" fill="currentColor" stroke="none"/></svg>`,
  };

  const findHTML = res.findings.map((f, idx) => {
    const remLines = f.suggested_remediation ? f.suggested_remediation.split('\n').filter(l => l.trim()) : [];
    const remCount = remLines.length;
    const tid = 'sr-tabs-' + idx;

    // ── Overview pane (Title + Model Theme + Description + Business Justification — NO remediation) ──
    const findingPaneHTML = `
      <div>
        <div class="frc-section-label" style="color:var(--primary)">Title</div>
        <div style="font-size:13.5px;font-weight:600;color:var(--text);line-height:1.45;margin-bottom:4px">${f.title}</div>
        ${f.model_theme ? `<span class="tag tag-success" style="font-size:11px;margin-bottom:2px">${f.model_theme}</span>` : ''}
        <div class="frc-section-label" style="color:var(--primary);margin-top:14px">Description</div>
        <div class="frc-text">${f.description}</div>
        <div class="frc-section-label" style="color:var(--warn);margin-top:16px">Business Justification</div>
        <div class="frc-biz-just">${f.business_justification}</div>
      </div>`;

    // ── Remediation pane (dedicated, not duplicated elsewhere) ──
    const remPaneHTML = remCount ? `
      <div class="remediation-section">
        <h4><span class="rem-badge">Action Required</span> Suggested Remediation</h4>
        <ul class="remediation-list">
          ${remLines.map(line => {
            const text = line.replace(/^[-•*]\s*/, '').trim();
            return text ? `<li><span>${text}</span></li>` : '';
          }).join('')}
        </ul>
      </div>` : `<p style="font-size:12.5px;color:var(--muted);padding:8px 0">No remediation steps recorded for this finding.</p>`;

    // ── Validation checks pane — LLM generated on demand ──
    const valPaneHTML = `
      <div id="${tid}-val-container">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px;padding:14px 16px;border-radius:8px;background:linear-gradient(135deg,#F0F7FF,#F5F9FF);border:1px solid #C0D8F0">
          <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--primary),#0081A6);display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 3px 8px rgba(0,94,124,.2)">
            <svg width="16" height="16" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/><path d="M9 12h6M9 16h4"/></svg>
          </div>
          <div style="flex:1">
            <div style="font-family:var(--font-mono);font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.13em;color:#0A5FA8">AI-Generated · Validation Checks</div>
            <div style="font-size:12px;color:#4A7DAA;margin-top:2px">Specific validation activities tailored to this finding</div>
          </div>
          <button onclick="generateFindingPane('${tid}','val','${(f.finding_id||'').replace(/'/g,"\\'")}',this)" style="display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:7px;border:1.5px solid var(--primary);background:var(--primary);color:#fff;font-size:12px;font-weight:700;cursor:pointer;transition:all .18s;font-family:var(--font-sans);box-shadow:0 2px 6px rgba(0,94,124,.2)" onmouseover="this.style.background='#0081A6'" onmouseout="this.style.background='var(--primary)'">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg>
            Generate
          </button>
        </div>
        <div id="${tid}-val-content"><span style="color:var(--muted);font-size:13px">Click Generate to produce AI-tailored validation checks for this finding…</span></div>
      </div>`;

    // ── Regulatory pane — LLM generated on demand ──
    const regPaneHTML = `
      <div id="${tid}-reg-container">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px;padding:14px 16px;border-radius:8px;background:linear-gradient(135deg,#EAF3FF,#F5F9FF);border:1px solid #C0D8F0">
          <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#2B6CB0,#3182CE);display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 3px 8px rgba(43,108,176,.2)">
            <svg width="16" height="16" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>
          </div>
          <div style="flex:1">
            <div style="font-family:var(--font-mono);font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.13em;color:#2B6CB0">AI-Generated · Regulatory Guidelines</div>
            <div style="font-size:12px;color:#4A7DAA;margin-top:2px">Applicable regulations and specific requirements for this finding</div>
          </div>
          <button onclick="generateFindingPane('${tid}','reg','${(f.finding_id||'').replace(/'/g,"\\'")}',this)" style="display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:7px;border:1.5px solid #2B6CB0;background:#2B6CB0;color:#fff;font-size:12px;font-weight:700;cursor:pointer;transition:all .18s;font-family:var(--font-sans);box-shadow:0 2px 6px rgba(43,108,176,.2)" onmouseover="this.style.background='#3182CE'" onmouseout="this.style.background='#2B6CB0'">
            <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg>
            Generate
          </button>
        </div>
        <div id="${tid}-reg-content"><span style="color:var(--muted);font-size:13px">Click Generate to produce applicable regulatory guidelines for this finding…</span></div>
      </div>`;

    // ── AI Generated pane ──
    const aiPaneHTML = `
      <div style="display:flex;flex-direction:column;gap:0">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px;padding:14px 16px;border-radius:8px;background:linear-gradient(135deg,#EAF3FF,#F5F9FF);border:1px solid #C0D8F0">
          <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--primary),#0081A6);display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 3px 8px rgba(0,94,124,.25)">
            <svg width="17" height="17" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg>
          </div>
          <div>
            <div style="font-family:var(--font-mono);font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.13em;color:#0A5FA8">AI-Generated Analysis</div>
            <div style="font-size:12px;color:#4A7DAA;margin-top:2px;font-weight:500">Powered by OpenAI · Based on this finding</div>
          </div>
          <button onclick="generateFindingAI('${tid}','${f.finding_id}',this)" style="margin-left:auto;display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:7px;border:1.5px solid var(--primary);background:var(--primary);color:#fff;font-size:12px;font-weight:700;cursor:pointer;transition:all .18s;font-family:var(--font-sans);box-shadow:0 2px 6px rgba(0,94,124,.25)" onmouseover="this.style.background='#0081A6';this.style.borderColor='#0081A6'" onmouseout="this.style.background='var(--primary)';this.style.borderColor='var(--primary)'">
            <svg width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg>
            Generate
          </button>
        </div>
        <div id="${tid}-ai-tabs" class="tab-bar" style="margin-bottom:14px;display:none">
          <button class="tab active" onclick="switchFindingAITab('${tid}','rem')">Remediation</button>
          <button class="tab" onclick="switchFindingAITab('${tid}','reg')">Regulatory</button>
          <button class="tab" onclick="switchFindingAITab('${tid}','val')">Validation</button>
        </div>
        <div id="${tid}-ai-rem" class="finding-ai-pane"><span style="color:var(--muted);font-size:13px">Click Generate to produce AI analysis for this finding…</span></div>
        <div id="${tid}-ai-reg" class="finding-ai-pane" style="display:none"></div>
        <div id="${tid}-ai-val" class="finding-ai-pane" style="display:none"></div>
      </div>`;

    return `
    <div class="finding-result-card fade-in">
      <div class="frc-header">
        <div style="flex:1;min-width:0">
          <div class="frc-meta">
            <span class="tag tag-id" style="cursor:pointer" onclick="openFindingModal('${f.finding_id}')">${f.finding_id}</span>
            ${f.model_theme ? `<span class="tag tag-success" style="font-size:10px">${f.model_theme}</span>` : ''}
          </div>
          <div class="frc-title" onclick="openFindingModal('${f.finding_id}')">${f.title}</div>
        </div>
      </div>
      <div class="frc-body">
        <div id="${tid}-finding" class="frc-pane active" style="padding:18px 22px">${findingPaneHTML}</div>
      </div>
    </div>`;
  }).join('');

  // Score badge helper
  const scoreHTML = (score) => score > 0
    ? `<span class="score-badge"><svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></span>`
    : '';

  // ── Cluster match card ──────────────────────────────────────────────────
  const ci = res.cluster ? clusterColorIdx(res.cluster.cluster_id) : 1;
  const clHTML = res.cluster ? `
    <div class="cluster-match-card">
      <div class="cmc-header">
        <span class="tag c-bg-${ci} c-color-${ci}" style="font-size:12px;font-weight:600;padding:3px 10px">${res.cluster.cluster_id}</span>
        ${res.cluster.semantic_label ? `<span style="font-size:12px;font-weight:500;color:var(--text-secondary)">${res.cluster.semantic_label}</span>` : ''}
        <span style="margin-left:auto;font-size:11px;color:var(--muted);font-family:var(--font-mono)">${res.cluster.findings_included.length} finding${res.cluster.findings_included.length !== 1 ? 's' : ''}</span>
      </div>
      <div class="cmc-body">
        <div class="cmc-findings">
          ${res.cluster.findings_included.map(fid => `<span class="tag tag-id" style="font-size:10px;cursor:pointer" onclick="openFindingModal('${fid}')">${fid}</span>`).join('')}
        </div>
        <div class="cmc-signals">${res.cluster.semantic_signals}</div>
        <div class="cmc-why">${res.cluster.why_grouped}</div>
      </div>
    </div>` : `<p style="color:var(--muted);font-size:13px;padding:4px 0">No direct cluster match found.</p>`;

  // Build overview-only cards for Potential Findings drawer
  const pfCardsHTML = res.findings.map(f => {
    return `<div class="pf-finding-card fade-in">
      <div class="pf-finding-meta">
        <span class="tag tag-id" style="cursor:pointer" onclick="openFindingModal('${f.finding_id}')">${f.finding_id}</span>
        ${f.model_theme ? `<span class="tag tag-success" style="font-size:10px">${f.model_theme}</span>` : ''}
      </div>
      <div class="pf-finding-title">${f.title}</div>
      <div class="pf-section-label">Description</div>
      <div class="pf-text">${f.description}</div>
      <div class="pf-section-label" style="color:var(--warn)">Business Justification</div>
      <div class="pf-biz">${f.business_justification}</div>
    </div>`;
  }).join('');

  zone.innerHTML = `
    <div class="bottom-sections-row">

      <!-- ── LEFT: Potential Findings ── -->
      <div class="bottom-drawer">
        <div class="drawer-tab-header" onclick="openResultPage('pf')" style="cursor:pointer" title="View matched findings">
          <div class="drawer-tab-header-inner">
            <div class="drawer-tab-icon" style="background:linear-gradient(135deg,var(--primary),#0081A6)">
              <svg width="15" height="15" fill="none" stroke="#fff" stroke-width="2.5" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/></svg>
            </div>
            <div>
              <div class="drawer-tab-label">Potential Findings</div>
              <div class="drawer-tab-sub">${res.findings.length} matched · ${scoreHTML(res.score)}</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;margin-right:16px">
            <span style="font-size:11px;color:var(--primary);font-family:var(--font-mono);background:var(--primary-bg);border:1px solid #C5D5F5;border-radius:10px;padding:2px 9px;font-weight:600;display:flex;align-items:center;gap:4px">
              <svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              Findings
            </span>
          </div>
        </div>
        <div class="drawer-body" id="pf-drawer">
          <div class="drawer-inner-tabs">
            <button class="drawer-inner-tab active" onclick="switchDrawerTab('pf','overview',this)">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/></svg>
              Overview
            </button>
          </div>
          <div class="drawer-pane-content">
            <div class="drawer-pane active" id="pf-pane-overview">
              ${pfCardsHTML || '<div class="empty" style="padding:30px 20px"><div class="empty-icon">⊘</div><p>No findings matched.</p></div>'}
            </div>
          </div>
        </div>
      </div>

      <!-- ── RIGHT: Additional MRM Actions ── -->
      <div class="bottom-drawer">
        <div class="drawer-tab-header" onclick="openResultPage('mrm')" style="cursor:pointer" title="Run AI analysis">
          <div class="drawer-tab-header-inner">
            <div class="drawer-tab-icon" style="background:linear-gradient(135deg,var(--accent),#c9520f)">
              <svg width="15" height="15" fill="none" stroke="#fff" stroke-width="2" viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 10 10"/><path d="M9 12l2 2 4-4"/><circle cx="19" cy="5" r="3" fill="currentColor" stroke="none"/></svg>
            </div>
            <div>
              <div class="drawer-tab-label">Additional MRM Actions</div>
              <div class="drawer-tab-sub" style="display:flex;align-items:center;gap:6px">
                <span id="llm-meta" style="font-size:11px;color:var(--muted)">Click AI Analyze to generate</span>
                <span id="llm-spinner" style="display:none;width:12px;height:12px;border-radius:50%;border:2px solid var(--accent);border-top-color:transparent;animation:spin .7s linear infinite;flex-shrink:0"></span>
                <span style="font-size:10px;color:var(--accent);font-family:var(--font-mono);background:var(--accent-bg);border:1px solid rgba(234,108,54,.3);border-radius:10px;padding:1px 7px;font-weight:700;letter-spacing:.03em">✦ AI</span>
              </div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;margin-right:16px">
            <span style="font-size:11px;color:var(--accent);font-family:var(--font-mono);background:var(--accent-bg);border:1px solid rgba(234,108,54,.3);border-radius:10px;padding:2px 9px;font-weight:600;display:flex;align-items:center;gap:4px">
              <svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
              AI Analyze
            </span>
          </div>
        </div>
        <div class="drawer-body" id="mrm-drawer">
          <div class="drawer-inner-tabs" id="llm-tab-bar">
            <button class="drawer-inner-tab active" onclick="switchLLMTab('regulatory');switchDrawerTab('mrm','regulatory',this)">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>
              Regulatory Guidelines
            </button>
            <button class="drawer-inner-tab" onclick="switchLLMTab('validation');switchDrawerTab('mrm','validation',this)">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/><path d="M9 12h6M9 16h4"/></svg>
              Validation Checks
            </button>
            <button class="drawer-inner-tab" onclick="switchLLMTab('remediation');switchDrawerTab('mrm','remediation',this)">
              <svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              Suggested Remediations
            </button>
          </div>
          <div class="drawer-pane-content">
            <div class="drawer-pane active" id="mrm-pane-regulatory">
              <div id="llm-pane-regulatory" class="llm-pane">
                <div id="llm-text-regulatory" class="llm-section-body">
                  <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:28px 16px;gap:10px;color:var(--muted)">
                    <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" style="opacity:.35"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 12h6M9 15h4"/></svg>
                    <span style="font-size:12.5px;color:var(--muted);text-align:center">Click <strong style="color:var(--text-secondary)">AI Analyze</strong> to generate applicable regulatory guidelines</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="drawer-pane" id="mrm-pane-validation">
              <div id="llm-pane-validation" class="llm-pane">
                <div id="llm-text-validation" class="llm-section-body">
                  <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:28px 16px;gap:10px;color:var(--muted)">
                    <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" style="opacity:.35"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2"/><path d="M9 12h6M9 16h4"/></svg>
                    <span style="font-size:12.5px;color:var(--muted);text-align:center">Click <strong style="color:var(--text-secondary)">AI Analyze</strong> to generate validation checks</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="drawer-pane" id="mrm-pane-remediation">
              <div id="llm-pane-remediation" class="llm-pane">
                <div id="llm-text-remediation" class="llm-section-body">
                  <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:28px 16px;gap:10px;color:var(--muted)">
                    <svg width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24" style="opacity:.35"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    <span style="font-size:12.5px;color:var(--muted);text-align:center">Click <strong style="color:var(--text-secondary)">AI Analyze</strong> to generate tailored recommendations</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
    `;
}

// ── LLM Analysis ─────────────────────────────────────────────────────────
let _lastSearchResults = null; // cached from last doSearch call

// Switch between the 3 LLM feature tabs (inline, no overlay)
function switchLLMTab(pane) {
  ['remediation', 'regulatory', 'validation'].forEach(p => {
    const el = document.getElementById('llm-pane-' + p);
    if (el) el.style.display = (p === pane) ? '' : 'none';
  });
}

// ── Deduplication helpers ──────────────────────────────────────────────────
/**
 * Tokenise a line into a set of meaningful words (3+ chars, lowercase).
 * Used for Jaccard similarity comparison.
 */
function _tokenSet(text) {
  return new Set(
    text.toLowerCase()
        .replace(/[^a-z0-9\s]/g, ' ')
        .split(/\s+/)
        .filter(w => w.length >= 3)
  );
}

/**
 * Jaccard similarity between two token sets.
 * Returns a value in [0, 1]; 1 = identical.
 */
function _jaccard(a, b) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const t of a) if (b.has(t)) inter++;
  return inter / (a.size + b.size - inter);
}

/**
 * Remove near-duplicate lines from a numbered-list string.
 * Lines already seen (Jaccard >= threshold) are dropped and the list
 * is renumbered from 1 continuously.
 *
 * @param {string} text        - Raw LLM output text
 * @param {Set[]}  seenSets    - Token-sets of lines already used in OTHER sections
 * @param {number} threshold   - Similarity cutoff (default 0.45)
 * @returns {{ deduped: string, newSets: Set[] }}
 */
function deduplicateSection(text, seenSets = [], threshold = 0.45) {
  const lines = text.trim().split('\n');
  const kept = [];
  const newSets = [];
  let counter = 1;

  for (const rawLine of lines) {
    const stripped = rawLine.replace(/^\d+\.\s*/, '').trim();
    if (!stripped) continue;                             // skip blank lines

    const tset = _tokenSet(stripped);
    if (!tset.size) continue;

    // Check similarity against already-kept lines (within this section)
    const dupWithin = newSets.some(s => _jaccard(tset, s) >= threshold);
    if (dupWithin) continue;

    // Check similarity against lines already committed in OTHER sections
    const dupAcross = seenSets.some(s => _jaccard(tset, s) >= threshold);
    if (dupAcross) continue;

    kept.push(`${counter}. ${stripped}`);
    newSets.push(tset);
    counter++;
  }

  return { deduped: kept.join('\n'), newSets };
}

// ── Render helpers ────────────────────────────────────────────────────────

/**
 * Render LLM output as clean Claude-style prose cards.
 * Each numbered point becomes a self-contained insight block —
 * no number badges, no left-border boxes, just readable flowing text
 * separated by a thin divider, exactly like Claude's own response style.
 *
 * paneType: 'regulatory' | 'validation' | 'remediation'
 */
function renderLLMSection(elId, text, paneType) {
  const el = document.getElementById(elId);
  if (!el) return;
  if (!text || !text.trim()) {
    el.innerHTML = `<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:32px 16px;gap:8px;color:var(--muted)">
      <span style="font-size:13px">No content returned.</span>
    </div>`;
    return;
  }

  // Accent colour per section — used only for the tiny dot marker
  const accents = {
    regulatory:  '#2B6CB0',
    validation:  '#005E7C',
    remediation: '#EA6C36',
  };
  const accent = accents[paneType] || '#2B6CB0';

  // Strip numbered prefixes and collect non-empty lines
  const items = text.trim()
    .split('\n')
    .map(l => l.replace(/^\d+\.\s*/, '').trim())
    .filter(Boolean);

  if (!items.length) {
    el.innerHTML = `<span style="color:var(--muted);font-size:13px">No content returned.</span>`;
    return;
  }

  // Build Claude-style prose blocks — divider-separated, no badges
  const blocks = items.map((body, idx) => {
    const isLast = idx === items.length - 1;
    return `
      <div style="padding:14px 4px ${isLast ? '6px' : '14px'} 0;
                  ${!isLast ? 'border-bottom:1px solid #EEF1F5;' : ''}
                  animation:fadeIn .3s ease ${idx * 0.06}s both;
                  display:flex;gap:12px;align-items:flex-start">
        <!-- Subtle accent dot — the only visual marker -->
        <span style="flex-shrink:0;width:7px;height:7px;border-radius:50%;
                     background:${accent};margin-top:7px;opacity:.75"></span>
        <!-- Prose text -->
        <p style="margin:0;font-size:14px;color:#1A2F4A;line-height:1.82;
                  font-weight:400;letter-spacing:.01em">${body}</p>
      </div>`;
  }).join('');

  el.innerHTML = `<div style="padding:4px 2px 2px">${blocks}</div>`;
}

// Show a loading skeleton inside a pane (3 shimmer lines like Claude's typing state)
function setLLMPaneLoading(pane) {
  const el = document.getElementById('llm-text-' + pane);
  if (!el) return;
  const shimmer = (w) => `
    <div style="height:13px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);
                background-size:400% 100%;animation:shimmer 1.4s ease infinite;
                width:${w};margin-bottom:12px"></div>`;
  el.innerHTML = `
    <style>@keyframes shimmer{0%{background-position:100% 50%}100%{background-position:0% 50%}}</style>
    <div style="padding:14px 4px">
      ${shimmer('88%')}${shimmer('72%')}${shimmer('81%')}${shimmer('60%')}
    </div>`;
}

// Single LLM call helper — proxied through Flask backend to OpenAI
async function callLLM(systemPrompt, userMsg) {
  const response = await fetch('/api/llm', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ system: systemPrompt, user: userMsg })
  });
  const data = await response.json();
  if (data.error) throw new Error(data.error);
  return data.text || '';
}

// ── Shared system-prompt builder ──────────────────────────────────────────
/**
 * Build the base system prompt from the search query and matched findings.
 * Context is embedded silently; output rules are strict and enumerated.
 */
function buildBaseSystem(query, findings) {
  // Merge Description + Business Justification only (no IDs, titles, themes)
  const riskNarrative = findings
    .map(f => [
      (f.description || '').trim().substring(0, 350),
      (f.business_justification || '').trim().substring(0, 200)
    ].filter(Boolean).join(' '))
    .filter(Boolean)
    .join(' ');

  const context = 'Search query: ' + query +
    (riskNarrative ? '. MRM risk context: ' + riskNarrative : '');

  return [
    'You are a senior Model Risk Management (MRM) expert with deep expertise in SR 11-7, EBA GL 2023/05, BCBS d192, OCC 2011-12, PRA SS1/23, and related supervisory frameworks.',
    'BACKGROUND (use only as silent context — never reproduce, quote, or paraphrase): ' + context + '.',
    'STRICT OUTPUT RULES:',
    '1. Output ONLY a clean numbered list (1. 2. 3. …) with no counter resets.',
    '2. Never quote, echo, repeat, or paraphrase any background context text.',
    '3. Never mention finding IDs, finding titles, theme names, field names, descriptions, business justifications, or suggested remediations.',
    '4. Never include an intro sentence, section heading, label, meta-commentary, or closing remark.',
    '5. Plain text only — no bold, italic, markdown, or bullet symbols.',
    '6. Each numbered point must be one self-contained sentence or short paragraph of original expert analysis unique to this section.',
    '7. Do not repeat or rephrase points you have already made.'
  ].join(' ');
}

// ── Main MRM AI Analysis (sequential, deduplicated) ───────────────────────
async function doLLMAnalysis() {
  const q = document.getElementById('search-input').value.trim();
  if (!q) { showAlert('Please run a search first then click AI Analyze', 'info'); return; }

  const spinner = document.getElementById('llm-spinner');
  const meta    = document.getElementById('llm-meta');

  if (spinner) spinner.style.display = 'inline-block';
  if (meta) meta.textContent = 'Generating…';

  // Show all panes in loading state; start on Regulatory Guidelines tab
  setLLMPaneLoading('regulatory');
  setLLMPaneLoading('validation');
  setLLMPaneLoading('remediation');
  switchLLMTab('regulatory');

  // Collect top matched findings (description + business_justification only)
  const findings = (_lastSearchResults && _lastSearchResults.findings)
    ? _lastSearchResults.findings.slice(0, 5)
    : allFindings.slice(0, 5);

  const baseSystem = buildBaseSystem(q, findings);

  // ── 1. REGULATORY GUIDELINES ─────────────────────────────────────────────
  // Focus: specific regulatory citations with section references and obligation text.
  // Deliberately scoped to citation-level granularity — NOT remediation or test steps.
 
  const regUserMsg = [
  'Generate 5 to 6 numbered Regulatory Guideline points relevant to this MRM query.',
  'Each point must:',
  '(a) cite one specific regulation by name and precise section number',
  '(e.g. SR 11-7 Section IV, EBA GL 2023/05 paragraph 5.2, BCBS d192 paragraph 18, OCC 2011-12 page 3, PRA SS1/23 paragraph 4.1),',
  'and (b) describe in a complete, fully formed paragraph what that provision requires of model risk practitioners.',
  'Each paragraph must be written in formal supervisory language and contain only complete sentences.',
  'Do not use placeholders or unfinished phrases such as "must have a".',
  'Cover different regulatory bodies across the list — do not repeat the same framework twice.',
  'Do not describe remediation actions, testing steps, or implementation guidance.'
].join(' ');


  let regRaw = '', regSets = [];
  try {
    regRaw = await callLLM(baseSystem, regUserMsg);
    const { deduped, newSets } = deduplicateSection(regRaw, [], 0.40);
    regRaw = deduped;
    regSets = newSets;
  } catch(e) {
    regRaw = 'Error: ' + e.message;
  }
  renderLLMSection('llm-text-regulatory', regRaw, 'regulatory');
  switchLLMTab('regulatory');

  // ── 2. VALIDATION CHECKS ─────────────────────────────────────────────────
  // Focus: concrete test/review activities with evidence and pass/fail criteria.
  // Seeded with regulatory sets to prevent cross-section duplication.
  const valUserMsg = [
    'Generate 5 to 7 numbered Validation Check points for this MRM query.',
    'Each point must describe: (a) one specific test or structured review activity (e.g. statistical test, document review, code comparison),',
    '(b) the exact evidence or artefact needed to perform it, and',
    '(c) a clear pass or fail criterion.',
    'Focus on testable, verifiable activities performed by an independent validation team.',
    'Do not cite regulations, do not describe remediation actions or policy changes.'
  ].join(' ');

  let valRaw = '', valSets = [];
  try {
    valRaw = await callLLM(baseSystem, valUserMsg);
    const { deduped, newSets } = deduplicateSection(valRaw, regSets, 0.40);
    valRaw = deduped;
    valSets = newSets;
  } catch(e) {
    valRaw = 'Error: ' + e.message;
  }
  renderLLMSection('llm-text-validation', valRaw, 'validation');

  // ── 3. REMEDIATION ────────────────────────────────────────────────────────
  // Focus: actionable corrective steps with implementation guidance and expected outcome.
  // Seeded with both prior sections to prevent all cross-section duplication.
  const remUserMsg = [
    'Generate 5 to 7 numbered Remediation Action points for this MRM query.',
    'Each point must state: (a) one concrete corrective action to implement,',
    '(b) how specifically to implement it (owner, method, or tooling), and',
    '(c) the expected risk-reduction outcome.',
    'Sequence from immediate tactical fixes to longer-term structural improvements.',
    'Do not cite regulatory frameworks, do not describe validation tests or review activities.'
  ].join(' ');

  let remRaw = '';
  try {
    remRaw = await callLLM(baseSystem, remUserMsg);
    const { deduped } = deduplicateSection(remRaw, [...regSets, ...valSets], 0.40);
    remRaw = deduped;
  } catch(e) {
    remRaw = 'Error: ' + e.message;
  }
  renderLLMSection('llm-text-remediation', remRaw, 'remediation');

  if (spinner) spinner.style.display = 'none';
  if (meta) meta.textContent = 'AI analysis complete';

  // Return to Regulatory tab so user sees first section
  switchLLMTab('regulatory');
}

// ── Per-finding on-demand LLM pane generation (val / reg) ────────────────
async function generateFindingPane(tid, pane, findingId, btn) {
  const f = allFindings.find(x => x.finding_id === findingId);
  if (!f) return;

  const origText = btn.innerHTML;
  btn.innerHTML = '<span style="width:10px;height:10px;border-radius:50%;border:2px solid currentColor;border-top-color:transparent;animation:spin .7s linear infinite;display:inline-block"></span> Generating…';
  btn.disabled = true;

  const context = `Finding: [${f.finding_id}] ${f.title}\nTheme: ${f.model_theme || 'N/A'}\nDescription: ${f.description.substring(0,400)}\nBusiness Justification: ${(f.business_justification||'').substring(0,200)}`;
  const baseSystem = 'You are a senior Model Risk Management (MRM) expert. Be concise and practical. Respond with ONLY a plain numbered or bulleted list — no intro sentence, no headers, no markdown fences.';

  const prompt = pane === 'val'
    ? `${context}\n\nList 4-6 specific validation checks that should be performed to assess this MRM finding. Each check must describe a concrete test or review activity.`
    : `${context}\n\nList 3-5 applicable regulatory guidelines relevant to this finding. For each, cite the specific regulation (e.g. SR 11-7 Section III, EBA GL 2023/05 §5.3, OCC 2011-12, BCBS d192) and briefly state what it requires.`;

  const setContent = (html) => {
    [`#${tid}-${pane}-content`, `#tab-detail-body #${tid}-${pane}-content`].forEach(sel => {
      const el = document.querySelector(sel);
      if (el) el.innerHTML = html;
    });
  };

  try {
    const text = await callLLM(baseSystem, prompt);
    if (!text || !text.trim()) { setContent('<span style="color:var(--muted);font-size:13px">No content returned.</span>'); return; }

    // Claude-style prose — accent dot, divider lines, no numbered badges
    const accent = pane === 'reg' ? '#2B6CB0' : pane === 'val' ? '#005E7C' : '#EA6C36';
    const items = text.trim()
      .split('\n')
      .map(l => l.replace(/^\d+\.\s*/, '').replace(/^[-•*]\s*/, '').trim())
      .filter(Boolean);
    const blocks = items.map((body, idx) => {
      const isLast = idx === items.length - 1;
      return `<div style="padding:12px 4px ${isLast ? '4px' : '12px'} 0;
                          ${!isLast ? 'border-bottom:1px solid #EEF1F5;' : ''}
                          display:flex;gap:11px;align-items:flex-start;
                          animation:fadeIn .3s ease ${idx * 0.06}s both">
        <span style="flex-shrink:0;width:6px;height:6px;border-radius:50%;background:${accent};margin-top:7px;opacity:.8"></span>
        <p style="margin:0;font-size:13.5px;color:#1A2F4A;line-height:1.8;font-weight:400">${body}</p>
      </div>`;
    }).join('');
    setContent(`<div style="padding:4px 2px 2px">${blocks}</div>`);
    btn.innerHTML = '<svg width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg> Regenerate';
    btn.disabled = false;
  } catch(e) {
    setContent(`<span style="color:var(--accent);font-size:12px">Error: ${e.message}</span>`);
    btn.innerHTML = origText;
    btn.disabled = false;
  }
}

// ── Per-finding AI generation ─────────────────────────────────────────────
function switchFindingAITab(tid, sub) {
  ['rem','reg','val'].forEach(s => {
    const el = document.getElementById(tid + '-ai-' + s);
    if (el) el.style.display = (s === sub) ? '' : 'none';
  });
  const tabsEl = document.getElementById(tid + '-ai-tabs');
  if (tabsEl) tabsEl.querySelectorAll('.tab').forEach((btn, i) => {
    btn.classList.toggle('active', ['rem','reg','val'][i] === sub);
  });
  // Also switch in any overlay clone (look for cloned tabs)
  const overlay = document.getElementById('tab-detail-body');
  if (overlay) {
    ['rem','reg','val'].forEach(s => {
      const el = overlay.querySelector('#' + tid + '-ai-' + s);
      if (el) el.style.display = (s === sub) ? '' : 'none';
    });
    const tabs = overlay.querySelector('#' + tid + '-ai-tabs');
    if (tabs) tabs.querySelectorAll('.tab').forEach((btn, i) => {
      btn.classList.toggle('active', ['rem','reg','val'][i] === sub);
    });
  }
}

async function generateFindingAI(tid, findingId, btn) {
  const f = allFindings.find(x => x.finding_id === findingId);
  if (!f) return;

  btn.textContent = 'Generating…';
  btn.disabled = true;

  const context = `Finding: [${f.finding_id}] ${f.title}\nTheme: ${f.model_theme || 'N/A'}\nDescription: ${f.description.substring(0,400)}\nBusiness Justification: ${(f.business_justification||'').substring(0,200)}\nSuggested Remediation: ${(f.suggested_remediation||'').substring(0,200)}`;
  const baseSystem = 'You are a senior Model Risk Management (MRM) expert. Be concise and practical. Respond with ONLY a plain numbered or bulleted list — no intro sentence, no headers, no markdown fences.';

  const setPane = (sub, html) => {
    ['#'+tid+'-ai-'+sub, '#tab-detail-body #'+tid+'-ai-'+sub].forEach(sel => {
      const el = document.querySelector(sel);
      if (el) el.innerHTML = html;
    });
  };

  const loadingHTML = `
    <style>@keyframes shimmer{0%{background-position:100% 50%}100%{background-position:0% 50%}}</style>
    <div style="padding:14px 4px">
      <div style="height:13px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.4s ease infinite;width:85%;margin-bottom:12px"></div>
      <div style="height:13px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.4s ease infinite;width:70%;margin-bottom:12px"></div>
      <div style="height:13px;border-radius:6px;background:linear-gradient(90deg,#EEF1F5 25%,#E2E8F0 50%,#EEF1F5 75%);background-size:400% 100%;animation:shimmer 1.4s ease infinite;width:78%"></div>
    </div>`;
  setPane('rem', loadingHTML);
  setPane('reg', loadingHTML);
  setPane('val', loadingHTML);

  // Show sub-tabs
  ['#'+tid+'-ai-tabs', '#tab-detail-body #'+tid+'-ai-tabs'].forEach(sel => {
    const el = document.querySelector(sel);
    if (el) el.style.display = '';
  });
  switchFindingAITab(tid, 'rem');

  // Claude-style prose renderer for per-finding panes
  const subAccents = { rem: '#EA6C36', reg: '#2B6CB0', val: '#005E7C' };
  const renderPane = (sub, text) => {
    if (!text || !text.trim()) {
      setPane(sub, '<span style="color:var(--muted);font-size:13px">No content returned.</span>');
      return;
    }
    const accent = subAccents[sub] || '#2B6CB0';
    const items = text.trim()
      .split('\n')
      .map(l => l.replace(/^\d+\.\s*/, '').replace(/^[-•*]\s*/, '').trim())
      .filter(Boolean);
    const blocks = items.map((body, idx) => {
      const isLast = idx === items.length - 1;
      return `<div style="padding:12px 4px ${isLast ? '4px' : '12px'} 0;
                          ${!isLast ? 'border-bottom:1px solid #EEF1F5;' : ''}
                          display:flex;gap:11px;align-items:flex-start;
                          animation:fadeIn .3s ease ${idx * 0.06}s both">
        <span style="flex-shrink:0;width:6px;height:6px;border-radius:50%;
                     background:${accent};margin-top:7px;opacity:.8"></span>
        <p style="margin:0;font-size:13.5px;color:#1A2F4A;line-height:1.8;font-weight:400">${body}</p>
      </div>`;
    }).join('');
    setPane(sub, `<div style="padding:4px 2px 2px">${blocks}</div>`);
  };

  try {
    const [remResult, regResult, valResult] = await Promise.allSettled([
      callLLM(baseSystem, `${context}\n\nProvide 4-6 numbered remediation action steps to address this MRM finding. Each step must be specific and actionable.`),
      callLLM(baseSystem, `${context}\n\nList 3-5 applicable regulatory guidelines relevant to this finding. For each, cite the specific regulation (e.g. SR 11-7 Section III, EBA GL 2023/05 §5.3, OCC 2011-12) and briefly state what it requires.`),
      callLLM(baseSystem, `${context}\n\nList 4-6 specific validation checks that should be performed to assess and verify this MRM finding. Each check must describe a concrete test or review activity.`)
    ]);
    renderPane('rem', remResult.status === 'fulfilled' ? remResult.value : 'Error: ' + remResult.reason?.message);
    renderPane('reg', regResult.status === 'fulfilled' ? regResult.value : 'Error: ' + regResult.reason?.message);
    renderPane('val', valResult.status === 'fulfilled' ? valResult.value : 'Error: ' + valResult.reason?.message);
  } catch(e) {
    setPane('rem', '<span style="color:var(--accent);font-size:12px">Error: ' + e.message + '</span>');
  }

  btn.textContent = 'Regenerate';
  btn.disabled = false;
}

// ── Global search ────────────────────────────────────────────────────────
let gsTimer = null;
function globalSearch(q) {
  clearTimeout(gsTimer);
  if (!q || q.length < 2) { closeGlobalDropdown(); return; }
  gsTimer = setTimeout(() => {
    const qL = q.toLowerCase();
    const hits = allFindings.filter(f =>
      [f.finding_id, f.model_theme, f.title, f.description,
       f.business_justification, f.suggested_remediation].some(s => s && s.toLowerCase().includes(qL))
    ).slice(0, 8);
    const dd = document.getElementById('global-dropdown');
    const dr = document.getElementById('global-dropdown-results');
    if (!hits.length) { dr.innerHTML = '<div style="padding:12px 16px;color:var(--muted);font-size:12px">No results</div>'; }
    else {
      dr.innerHTML = hits.map(f => {
        const cl = findClusterForFinding(f.finding_id);
        const ci = cl ? clusterColorIdx(cl.cluster_id) : 1;
        return `<div onclick="openFindingModal('${f.finding_id}');closeGlobalDropdown()" style="padding:10px 16px;cursor:pointer;border-bottom:1px solid var(--border);transition:background .15s" onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
          <div style="display:flex;align-items:center;gap:7px;margin-bottom:3px">
            <span class="tag tag-id" style="font-size:10px">${f.finding_id}</span>
            ${cl ? `<span class="tag c-bg-${ci} c-color-${ci}" style="font-size:10px">${cl.cluster_id}</span>` : ''}
          </div>
          <div style="font-size:12px;font-weight:500;color:var(--text)">${f.title}</div>
        </div>`;}).join('');
    }
    dd.style.display = 'block';
  }, 200);
}
function closeGlobalDropdown() {
  document.getElementById('global-dropdown').style.display = 'none';
  document.getElementById('global-dropdown-results').innerHTML = '';
}
document.addEventListener('click', e => {
  if (!e.target.closest('#global-dropdown') && !e.target.closest('#global-search')) closeGlobalDropdown();
});

// ── Add Finding ──────────────────────────────────────────────────────────
async function addFinding() {
  const data = {
    finding_id: document.getElementById('f-id').value.trim(),
    model_theme: document.getElementById('f-theme').value.trim(),
    title: document.getElementById('f-title').value.trim(),
    description: document.getElementById('f-desc').value.trim(),
    business_justification: document.getElementById('f-just').value.trim(),
    suggested_remediation: document.getElementById('f-rem').value.trim(),
  };
  // ── Validation checks ────────────────────────────────────────────────
  const fieldRules = [
    {
      id: 'f-id', label: 'Finding ID', value: data.finding_id,
      checks: [
        [!data.finding_id, 'Finding ID is required'],
        [data.finding_id && !/^[A-Za-z0-9_\-]{1,30}$/.test(data.finding_id),
          'Finding ID must be 1-30 alphanumeric characters (letters, numbers, hyphens, underscores)'],
        [data.finding_id && allFindings.some(f => f.finding_id === data.finding_id),
          'Finding ID "' + data.finding_id + '" already exists in the library'],
      ]
    },
    {
      id: 'f-title', label: 'Title', value: data.title,
      checks: [
        [!data.title, 'Title is required'],
        [data.title && data.title.length < 5, 'Title must be at least 5 characters (currently ' + data.title.length + ')'],
        [data.title && data.title.length > 250, 'Title must be 250 characters or fewer (currently ' + data.title.length + ')'],
      ]
    },
    {
      id: 'f-desc', label: 'Description', value: data.description,
      checks: [
        [!data.description, 'Description is required'],
        [data.description && data.description.length < 20,
          'Description must be at least 20 characters — provide a detailed account of the issue (currently ' + data.description.length + ')'],
        [data.description && data.description.length > 5000,
          'Description is too long — keep it under 5000 characters (currently ' + data.description.length + ')'],
      ]
    },
    {
      id: 'f-just', label: 'Business Justification', value: data.business_justification,
      checks: [
        [!data.business_justification, 'Business Justification is required'],
        [data.business_justification && data.business_justification.length < 10,
          'Business Justification must be at least 10 characters (currently ' + data.business_justification.length + ')'],
        [data.business_justification && data.business_justification.length > 3000,
          'Business Justification is too long — keep it under 3000 characters (currently ' + data.business_justification.length + ')'],
      ]
    },
    {
      id: 'f-rem', label: 'Suggested Remediation', value: data.suggested_remediation,
      checks: [
        [data.suggested_remediation && data.suggested_remediation.length > 3000,
          'Suggested Remediation is too long — keep it under 3000 characters (currently ' + data.suggested_remediation.length + ')'],
      ]
    },
  ];

  // Collect all errors and annotate fields
  const fieldErrors = {};
  for (const rule of fieldRules) {
    const el = document.getElementById(rule.id);
    let errMsg = null;
    for (const [cond, msg] of rule.checks) {
      if (cond) { errMsg = msg; break; }
    }
    if (errMsg) {
      fieldErrors[rule.id] = errMsg;
      if (el) {
        el.style.borderColor = 'var(--accent)';
        el.style.boxShadow = '0 0 0 3px rgba(234,108,54,.15)';
        // Inline error hint
        let hint = el.parentElement.querySelector('.field-error-hint');
        if (!hint) {
          hint = document.createElement('span');
          hint.className = 'field-error-hint';
          hint.style.cssText = 'font-size:11px;color:var(--accent);margin-top:3px;display:block;font-weight:500';
          el.parentElement.appendChild(hint);
        }
        hint.textContent = '⚠ ' + errMsg;
      }
    } else {
      if (el) {
        el.style.borderColor = '';
        el.style.boxShadow = '';
        const hint = el.parentElement.querySelector('.field-error-hint');
        if (hint) hint.remove();
      }
    }
  }

  if (Object.keys(fieldErrors).length) {
    const firstErrId = Object.keys(fieldErrors)[0];
    const firstEl = document.getElementById(firstErrId);
    if (firstEl) firstEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    showAlert('Please fix ' + Object.keys(fieldErrors).length + ' validation error(s) before submitting.', 'error');
    return;
  }

  // Clear all validation states
  for (const rule of fieldRules) {
    const el = document.getElementById(rule.id);
    if (el) {
      el.style.borderColor = '';
      el.style.boxShadow = '';
      const hint = el.parentElement.querySelector('.field-error-hint');
      if (hint) hint.remove();
    }
  }
  try {
    const res = await apiFetch('/api/findings', {method:'POST', body:JSON.stringify(data)});
    if (res.error) { showAlert(res.error, 'error'); return; }
    allFindings = await apiFetch('/api/findings');
    updateSidebar();
    clearForm();
    showAlert('Finding ' + data.finding_id + ' added (' + res.total + ' total). Clustering\u2026', 'success');
    pollUntilClustered(function(count) {
      showAlert('Clustering complete \u2014 ' + count + ' clusters ready.', 'success');
    });
  } catch(e) {
    showAlert('Error: ' + e.message, 'error');
  }
}
