# Unified Insurance Calculator (Maturity Benefit)

One Flask web app that consolidates the MB1, MB2 and MB3 maturity-benefit
calculators behind a single input/output. Each row's `CNTTYPE` (column Z)
decides which underlying calculator runs for that row.

## Layout

- **Input**: any `.xlsx` workbook with columns A:BD on its first calculator
  sheet. Row 1 is a section/label row, row 2 is the column-header row, data
  starts at row 3.
- **Output**: one `.xlsx` with the same A:BD inputs, the 9 user-facing output
  columns at BE:BM, and a "Calculator Used" diagnostic column at BN telling
  you which underlying calculator produced each row's output (MB1 / MB2 /
  MB3 / UNROUTED).

## CNTTYPE routing

| Calculator | CNTTYPEs |
|-----------|---------|
| MB1 | CPP, CHP, MBP, RFP, SMB, MSB, RMM, MMP |
| MB2 | CSR, SEP, CPF, CPH, DEP, END, RBC, IMP, MBG, MBN, MPI, RFI, WLI |
| MB3 | LPR, LBR, LBS, LCS |

## Running locally

```bash
pip install -r requirements.txt
python app.py
# open http://127.0.0.1:5003
```

## CLI

```bash
python unified.py input.xlsx output.xlsx
```

## Deploying on Render

This repo is Render-ready. Either:

1. **Blueprint**: Render auto-detects `render.yaml` and provisions a free
   web service with `gunicorn app:app` and a `/health` check.
2. **Manual web service**: point Render at this repo, set runtime to Python,
   build command `pip install -r requirements.txt`, start command
   `gunicorn app:app --bind 0.0.0.0:$PORT`.

`runtime.txt` pins Python 3.11.9. `SECRET_KEY` is sourced from the
environment (the blueprint generates one automatically).

## Project structure

```
.
├── app.py                # Flask web app
├── unified.py            # Router + workbook I/O
├── calculators/
│   ├── __init__.py
│   ├── mb1.py
│   ├── mb2.py
│   └── mb3.py
├── templates/index.html
├── static/style.css
├── requirements.txt
├── Procfile
├── render.yaml
├── runtime.txt
└── README.md
```
