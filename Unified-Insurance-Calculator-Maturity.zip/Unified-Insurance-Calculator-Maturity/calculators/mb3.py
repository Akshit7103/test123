"""MB3 Calculator: LPR / LBR / LBS maturity benefit.

Mirrors the MB_Calc 3 reference workbook formulas with one correction:
the loan-interest accrual uses RISKCESDTE (AH) — the date column — instead
of PREM TERM (AD), which the reference formula references by mistake. The
correction matches the MB1 calculator's interest formula.
"""
from __future__ import annotations

import argparse
import sys
from datetime import date, datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any

import openpyxl
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.utils.datetime import from_excel, to_excel


SHEET_NAME = "MAIN CALCULATOR"
INPUT_LAST_COL = 56  # BD
DATA_START_ROW_OUT = 3
ACCRUED_INTEREST_DATE_SERIAL = float(to_excel(datetime(2026, 3, 31)))
ACCRUED_INTEREST_RATE = 0.0825


INPUT_HEADERS = [
    "Dummypol", "STATUS", "LE_LP_AMT", "LE_ME", "LE_RY", "LE_SI", "LE_IM", "LE_PA", "LE_BT", "LE_LY",
    "LE_FE", "LE_GM", "LN_LO_AMT", "LN_LA_AMT", "LN_LI_AMT", "LE_MC", "LP_S", "LP_MS", "LE_SB", "ASGNNUM",
    "NATLTY", "ISSDATE", "FIRSTISSDT", "PREMIUM01", "SA", "CNTTYPE", "CATEGORY", "PROD_NAME", "RISK TERM", "PREM TERM",
    "FREQUENCY", "RCDDATE", "PAIDTODATE", "RISKCESDTE", "PREMCESDTE", "CLTDOB", "CLTDOD", "ZPANVAL", "ANP_PREMIUM", "STMPDTYAMT",
    "INSTPREM_GST", "INSTPREM_WITH_GST", "INSTPREM_WITHOUT_GST", "PLAN_COMPONENT", "COMPONENT_DESC", "ORIGINAL_SA", "ASSIGNEE FLAG", "LITIGATION FLAG", "CURRENT_SA", "ACCUMLATION ACCOUNT BALANCE",
    "POLICY PAYOUT TYPE", "ADDITIONAL_ACCUMLATION_ACC_BAL", "AGE LAST BDAY", "BASE_PREMIUM_AMT", "X_LOADED_PREM_AMT", "MODAL_FACTOR",
]

OUTPUT_HEADERS = [
    "LN_LA\nUpdated", "GLA", "GMA", "Revisionary Bonus", "Special Bonus", "Terminal Bonus",
    "Maturity Benefit", "Condition of 100.1% , additional bonus", "Total Maturity Benefit ",
]

INPUT_COLUMN_WIDTHS = [
    19.140625, 7.42578125, 14.42578125, 12.5703125, 13.42578125, 11.28515625, 7.140625,
    6.0, 5.85546875, 5.5703125, 8.42578125, 6.5703125, 12.5703125, 13.0, 12.28515625,
    6.42578125, 12.28515625, 13.0, 10.5703125, 10.140625, 7.42578125, 17.28515625, 13.0,
    11.28515625, 10.0, 8.7109375, 12.5703125, 24.7109375, 10.0, 11.0, 11.42578125,
    17.28515625, 17.42578125, 17.28515625, 13.0, 17.42578125, 8.0, 8.85546875, 14.0,
    12.7109375, 14.140625, 19.7109375, 23.5703125, 18.28515625, 24.7109375, 13.7109375,
    14.28515625, 15.7109375, 13.7109375, 31.7109375, 19.42578125, 34.42578125, 14.0,
    13.0, 13.0, 13.0,
]
OUTPUT_COLUMN_WIDTHS = [11.28515625, 13.0, 13.0, 20.140625, 16.0, 17.28515625, 15.5703125, 13.5703125, 31.28515625]


def is_blank(value: Any) -> bool:
    return value is None or value == ""


def clean_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def eq_text(left: Any, right: str) -> bool:
    return clean_text(left).casefold() == right.casefold()


def is_one_of(value: Any, *options: str) -> bool:
    return any(eq_text(value, option) for option in options)


def num(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    if isinstance(value, bool):
        return 1.0 if value else 0.0
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, datetime):
        return float(to_excel(value))
    if isinstance(value, date):
        return float(to_excel(datetime(value.year, value.month, value.day)))
    if isinstance(value, str):
        stripped = value.strip().replace(",", "")
        if stripped == "":
            return 0.0
        if stripped.startswith("(") and stripped.endswith(")"):
            stripped = f"-{stripped[1:-1]}"
        return float(stripped.rstrip("%"))
    return float(value)


def safe_num(value: Any) -> float:
    try:
        return num(value)
    except Exception:
        return 0.0


def excel_round(value: Any, digits: int = 0) -> float:
    quant = Decimal("1").scaleb(-digits)
    rounded = Decimal(str(num(value))).quantize(quant, rounding=ROUND_HALF_UP)
    result = float(rounded)
    return int(result) if digits == 0 else result


def excel_date(value: Any) -> datetime | None:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    if isinstance(value, (int, float)):
        return from_excel(value)
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return None
        for fmt in (
            "%Y-%m-%d %H:%M:%S", "%d-%m-%Y %H:%M:%S", "%d/%m/%Y %H:%M:%S",
            "%m/%d/%Y %H:%M:%S", "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%m/%d/%Y",
        ):
            try:
                return datetime.strptime(stripped, fmt)
            except ValueError:
                continue
        try:
            return datetime.fromisoformat(stripped)
        except ValueError:
            pass
        try:
            return from_excel(float(stripped))
        except ValueError:
            return None
    return None


def date_serial(value: Any) -> float:
    dt = excel_date(value)
    return 0.0 if dt is None else float(to_excel(dt))


def calculate_outputs(row: dict[str, Any]) -> dict[str, Any]:
    """Compute the 9 user-facing output columns for one input row."""
    status = row.get("B")
    cnttype = row.get("Z")

    # PPT * Freq (BG): IF(Z="LBS", 1, AD*AE)
    if eq_text(cnttype, "LBS"):
        ppt_freq: float = 1.0
    else:
        ppt_freq = safe_num(row.get("AD")) * safe_num(row.get("AE"))

    # Prem Paid * Freq (BH): IF(Z="LBS" AND AG=AI, 1, ROUND((AG-AF)/365 * AE, 0))
    if eq_text(cnttype, "LBS") and date_serial(row.get("AG")) == date_serial(row.get("AI")):
        prem_paid_freq: float = 1.0
    else:
        prem_paid_freq = excel_round(
            (date_serial(row.get("AG")) - date_serial(row.get("AF"))) / 365 * safe_num(row.get("AE")),
            0,
        )

    # Updated SA (BI): IF status=IF -> AT, status=PU -> AT*BH/BG, else "" (blank)
    if eq_text(status, "IF"):
        updated_sa: Any = safe_num(row.get("AT"))
    elif eq_text(status, "PU"):
        updated_sa = safe_num(row.get("AT")) * prem_paid_freq / ppt_freq if ppt_freq else 0.0
    else:
        updated_sa = ""

    # Loan interest accrual (BJ): MB1-style formula using AH (RISKCESDTE).
    # The reference workbook formula references AD (PREM TERM, a number) which
    # always satisfies AD <= cutoff_date_serial and so always returns 0 — that
    # is a bug in the reference. Using AH matches MB1 and is correct.
    ah_serial = date_serial(row.get("AH"))
    if ah_serial <= ACCRUED_INTEREST_DATE_SERIAL:
        accrued_interest = 0.0
    else:
        accrued_interest = (safe_num(row.get("M")) + safe_num(row.get("N"))) * (
            (1 + ACCRUED_INTEREST_RATE)
            ** ((ah_serial - ACCRUED_INTEREST_DATE_SERIAL) / 365)
            - 1
        )

    # LN_LA Updated (BK): N + accrued_interest
    ln_la_updated = safe_num(row.get("N")) + accrued_interest

    # Maturity Benefit (BS): only LPR/LBR/LBS with status IF/PU and non-blank Updated SA
    if (
        is_one_of(cnttype, "LPR", "LBR", "LBS")
        and is_one_of(status, "IF", "PU")
        and not is_blank(updated_sa)
    ):
        maturity_benefit: Any = safe_num(row.get("X")) * prem_paid_freq
    else:
        maturity_benefit = 0

    # Total Maturity Benefit (BU): BS - SUM(M + BK) - Q - K
    total_mb = (
        safe_num(maturity_benefit)
        - (safe_num(row.get("M")) + safe_num(ln_la_updated))
        - safe_num(row.get("Q"))
        - safe_num(row.get("K"))
    )

    return {
        "LN_LA Updated": ln_la_updated,
        "GLA": "",
        "GMA": "",
        "Revisionary Bonus": "",
        "Special Bonus": "",
        "Terminal Bonus": "",
        "Maturity Benefit": maturity_benefit,
        "Condition 100.1%": "",
        "Total Maturity Benefit": total_mb,
    }


OUTPUT_KEY_ORDER = [
    "LN_LA Updated", "GLA", "GMA", "Revisionary Bonus", "Special Bonus", "Terminal Bonus",
    "Maturity Benefit", "Condition 100.1%", "Total Maturity Benefit",
]


def find_data_rows(in_ws) -> list[tuple[int, list[Any]]]:
    """Return list of (source_row_num, row_values) for actual data rows.

    Skips any row that matches the column header layout exactly. This handles
    inputs with one header row (row 1) or two header rows (row 1 section
    labels + row 2 column labels).
    """
    rows: list[tuple[int, list[Any]]] = []
    header_row_seen: int | None = None
    for r_idx, raw in enumerate(
        in_ws.iter_rows(min_row=1, max_col=INPUT_LAST_COL, values_only=True), start=1
    ):
        values = list(raw)
        normalized = [clean_text(v) for v in values[: len(INPUT_HEADERS)]]
        if normalized == INPUT_HEADERS:
            header_row_seen = r_idx
            continue
        if header_row_seen is None and r_idx == 1:
            # First row not a column header; assume it's a label row and skip.
            continue
        if header_row_seen is None and r_idx == 2:
            # Likely the label row was at row 1 (different format); now expecting data.
            pass
        if any(not is_blank(v) for v in values):
            rows.append((r_idx, values))
    return rows


def write_workbook(out_path: Path, data_rows: list[tuple[int, list[Any]]]) -> int:
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET_NAME
    ws.freeze_panes = "B3"

    for ci, width in enumerate(INPUT_COLUMN_WIDTHS, 1):
        ws.column_dimensions[get_column_letter(ci)].width = width
    for i, width in enumerate(OUTPUT_COLUMN_WIDTHS, len(INPUT_HEADERS) + 1):
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[2].height = 60

    green_fill = PatternFill(start_color="00B050", end_color="00B050", fill_type="solid")
    yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    default_font = Font(name="Aptos Narrow", size=11)
    header_font = Font(name="Aptos Narrow", size=11, bold=True)
    input_header_align = Alignment(vertical="center")
    output_header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for ci, label in enumerate(INPUT_HEADERS, 1):
        cell = ws.cell(row=2, column=ci)
        cell.value = label
        cell.font = header_font
        cell.alignment = input_header_align
    for i, label in enumerate(OUTPUT_HEADERS):
        ci = len(INPUT_HEADERS) + 1 + i
        cell = ws.cell(row=2, column=ci)
        cell.value = label
        cell.font = header_font
        cell.alignment = output_header_align
        cell.fill = yellow_fill if i == 6 else green_fill

    for offset, (_, values) in enumerate(data_rows):
        out_row = DATA_START_ROW_OUT + offset
        # Write A:BD inputs
        for ci in range(1, INPUT_LAST_COL + 1):
            cell = ws.cell(row=out_row, column=ci)
            cell.value = values[ci - 1] if ci - 1 < len(values) else None
            cell.font = default_font
        # Build dict keyed by Excel column letter for the calculator
        row_dict = {get_column_letter(ci): values[ci - 1] for ci in range(1, INPUT_LAST_COL + 1) if ci - 1 < len(values)}
        outputs = calculate_outputs(row_dict)
        for j, key in enumerate(OUTPUT_KEY_ORDER):
            cell = ws.cell(row=out_row, column=len(INPUT_HEADERS) + 1 + j)
            cell.value = outputs[key]
            cell.font = default_font

    wb.save(out_path)
    return len(data_rows)


def calculate_mb3(input_file_path: str | Path, output_file_path: str | Path) -> tuple[bool, str]:
    """Web-app entry point. Preserved signature for app.py compatibility."""
    try:
        in_wb = load_workbook(input_file_path, data_only=True, read_only=True)
    except Exception as exc:
        return False, f"Error reading input: {exc}"
    try:
        in_ws = in_wb[SHEET_NAME] if SHEET_NAME in in_wb.sheetnames else in_wb.active
        data_rows = find_data_rows(in_ws)
        if not data_rows:
            return False, "No data rows found in the input workbook."
        write_workbook(Path(output_file_path), data_rows)
        return True, "Success"
    except Exception as exc:
        return False, f"Error during calculation: {exc}"
    finally:
        in_wb.close()


# ---------- Validation ----------

OUTPUT_REF_COLUMNS = {
    # output_key -> reference column number (1-indexed) in MB_Calc 3 reference
    "LN_LA Updated": 63,        # BK
    "GLA": 66,                  # BN
    "GMA": 67,                  # BO
    "Revisionary Bonus": 68,    # BP
    "Special Bonus": 69,        # BQ
    "Terminal Bonus": 70,       # BR
    "Maturity Benefit": 71,     # BS
    "Condition 100.1%": 72,     # BT
    "Total Maturity Benefit": 73,  # BU
}


def values_close(left: Any, right: Any, tol: float = 1.0) -> bool:
    a = safe_num(left) if not is_blank(left) else None
    b = safe_num(right) if not is_blank(right) else None
    if a is None and b is None:
        return True
    if (a is None and b == 0) or (b is None and a == 0):
        return True
    if a is None or b is None:
        return False
    return abs(a - b) <= tol


def validate(output_path: Path, reference_path: Path) -> list[str]:
    out_wb = load_workbook(output_path, data_only=True, read_only=True)
    ref_wb = load_workbook(reference_path, data_only=True, read_only=True)
    try:
        out_ws = out_wb[SHEET_NAME]
        ref_ws = ref_wb[SHEET_NAME]
    except KeyError as exc:
        return [f"Sheet '{SHEET_NAME}' not found: {exc}"]

    mismatches: list[str] = []
    for ref_row in range(DATA_START_ROW_OUT, ref_ws.max_row + 1):
        if not any(
            ref_ws.cell(ref_row, c).value not in (None, "") for c in range(1, INPUT_LAST_COL + 1)
        ):
            continue
        for j, key in enumerate(OUTPUT_KEY_ORDER):
            out_col = len(INPUT_HEADERS) + 1 + j
            ref_col = OUTPUT_REF_COLUMNS[key]
            actual = out_ws.cell(ref_row, out_col).value
            expected = ref_ws.cell(ref_row, ref_col).value
            if not values_close(actual, expected):
                mismatches.append(
                    f"row {ref_row} {key}: expected {expected!r}, got {actual!r}"
                )
                if len(mismatches) >= 50:
                    return mismatches
    return mismatches


def main() -> int:
    parser = argparse.ArgumentParser(description="MB3 calculator: LPR/LBR/LBS maturity benefit.")
    parser.add_argument("input", type=Path, help="Input Excel file with columns A:BD.")
    parser.add_argument("output", type=Path, help="Output Excel file to create.")
    parser.add_argument("--validate", type=Path, help="Optional reference workbook to compare outputs against.")
    args = parser.parse_args()

    ok, msg = calculate_mb3(args.input, args.output)
    if not ok:
        print(f"Failed: {msg}", file=sys.stderr)
        return 1
    print(f"Created {args.output}")

    if args.validate:
        mismatches = validate(args.output, args.validate)
        if mismatches:
            print("Validation FAILED:")
            for m in mismatches:
                print(f"  - {m}")
            return 1
        print("Validation passed: all 9 output columns match the reference workbook.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
