"""Bundled MB1/MB2/MB3 calculator modules used by the unified router."""
from . import mb1, mb2, mb3

__all__ = ["mb1", "mb2", "mb3"]
