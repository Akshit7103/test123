import { useState, useEffect, useRef, useCallback } from "react";

const REGULATORY_FRAMEWORKS = [
  "SR 11-7 (Fed/OCC)",
  "SS1/23 (PRA)",
  "ECB Guide to Internal Models",
  "BCBS 239",
  "IFRS 9",
  "Basel III/IV",
  "DORA",
  "Other / Not specified",
];

const MODEL_TYPES = [
  "Credit Risk – PD Model",
  "Credit Risk – LGD Model",
  "Credit Risk – EAD Model",
  "Market Risk – VaR/ES",
  "Pricing Model – Options/Derivatives",
  "Pricing Model – Fixed Income",
  "Transaction Monitoring – Rule-based",
  "Transaction Monitoring – ML/Statistical",
  "Fraud Detection",
  "Operational Risk",
  "Liquidity Risk",
  "IFRS 9 – ECL Model",
  "Stress Testing / DFAST",
  "Other",
];

const STEPS = ["upload", "configure", "validate", "report"];

const STEP_LABELS = {
  upload: "Upload",
  configure: "Configure",
  validate: "Validating",
  report: "Report",
};

function FileIcon() {
  return (
    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="40" height="40" rx="8" fill="var(--color-background-secondary)" />
      <path d="M12 8h12l8 8v18a2 2 0 01-2 2H12a2 2 0 01-2-2V10a2 2 0 012-2z" stroke="var(--color-text-secondary)" strokeWidth="1.5" fill="none" />
      <path d="M24 8v8h8" stroke="var(--color-text-secondary)" strokeWidth="1.5" fill="none" />
    </svg>
  );
}

function Stepper({ current }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 0, marginBottom: "2.5rem" }}>
      {STEPS.map((step, i) => {
        const isDone = STEPS.indexOf(current) > i;
        const isActive = current === step;
        return (
          <div key={step} style={{ display: "flex", alignItems: "center", flex: i < STEPS.length - 1 ? 1 : "none" }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
              <div style={{
                width: 28, height: 28, borderRadius: "50%",
                background: isDone ? "var(--color-text-primary)" : isActive ? "var(--color-text-primary)" : "var(--color-background-secondary)",
                border: `1.5px solid ${isDone || isActive ? "var(--color-text-primary)" : "var(--color-border-secondary)"}`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 11, fontWeight: 500,
                color: isDone || isActive ? "var(--color-background-primary)" : "var(--color-text-secondary)",
                transition: "all 0.3s ease",
                fontFamily: "var(--font-mono)",
              }}>
                {isDone ? "✓" : i + 1}
              </div>
              <span style={{
                fontSize: 11, letterSpacing: "0.06em", textTransform: "uppercase",
                color: isActive ? "var(--color-text-primary)" : "var(--color-text-tertiary)",
                fontWeight: isActive ? 500 : 400,
                whiteSpace: "nowrap",
              }}>{STEP_LABELS[step]}</span>
            </div>
            {i < STEPS.length - 1 && (
              <div style={{
                flex: 1, height: 1,
                background: isDone ? "var(--color-text-primary)" : "var(--color-border-tertiary)",
                margin: "0 8px", marginBottom: 20,
                transition: "background 0.3s ease",
              }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

function UploadStep({ onNext }) {
  const [files, setFiles] = useState([]);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef();

  const addFiles = (incoming) => {
    const arr = Array.from(incoming);
    setFiles(prev => {
      const names = new Set(prev.map(f => f.name));
      return [...prev, ...arr.filter(f => !names.has(f.name))];
    });
  };

  const onDrop = useCallback((e) => {
    e.preventDefault();
    setDragging(false);
    addFiles(e.dataTransfer.files);
  }, []);

  const onDragOver = (e) => { e.preventDefault(); setDragging(true); };
  const onDragLeave = () => setDragging(false);

  const removeFile = (name) => setFiles(prev => prev.filter(f => f.name !== name));

  const ext = (name) => name.split(".").pop().toUpperCase();

  const formatSize = (bytes) => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  };

  return (
    <div>
      <h2 style={{ fontSize: 22, fontWeight: 500, margin: "0 0 0.5rem", color: "var(--color-text-primary)" }}>
        Upload model documentation
      </h2>
      <p style={{ fontSize: 14, color: "var(--color-text-secondary)", margin: "0 0 1.5rem", lineHeight: 1.6 }}>
        Upload methodology documents, parameter files, backtesting results, output data, or any model artefact. Accepted: PDF, Excel, CSV, Word.
      </p>

      <div
        onClick={() => inputRef.current.click()}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        style={{
          border: `1.5px dashed ${dragging ? "var(--color-border-primary)" : "var(--color-border-secondary)"}`,
          borderRadius: "var(--border-radius-lg)",
          padding: "2.5rem",
          textAlign: "center",
          cursor: "pointer",
          background: dragging ? "var(--color-background-secondary)" : "transparent",
          transition: "all 0.2s ease",
          marginBottom: "1rem",
        }}
      >
        <input
          ref={inputRef}
          type="file"
          multiple
          accept=".pdf,.xlsx,.xls,.csv,.doc,.docx,.txt"
          style={{ display: "none" }}
          onChange={e => addFiles(e.target.files)}
        />
        <div style={{ fontSize: 32, marginBottom: 12, color: "var(--color-text-tertiary)" }}>
          <i className="ti ti-cloud-upload" aria-hidden="true" />
        </div>
        <p style={{ fontSize: 14, fontWeight: 500, margin: "0 0 4px", color: "var(--color-text-primary)" }}>
          Drop files here or click to browse
        </p>
        <p style={{ fontSize: 12, color: "var(--color-text-tertiary)", margin: 0 }}>
          PDF · XLSX · CSV · DOCX · TXT
        </p>
      </div>

      {files.length > 0 && (
        <div style={{ marginBottom: "1.5rem" }}>
          {files.map(f => (
            <div key={f.name} style={{
              display: "flex", alignItems: "center", gap: 12,
              padding: "10px 14px",
              border: "0.5px solid var(--color-border-tertiary)",
              borderRadius: "var(--border-radius-md)",
              marginBottom: 6,
              background: "var(--color-background-primary)",
            }}>
              <div style={{
                fontSize: 10, fontWeight: 500, fontFamily: "var(--font-mono)",
                background: "var(--color-background-secondary)",
                color: "var(--color-text-secondary)",
                padding: "2px 6px", borderRadius: 4, minWidth: 36, textAlign: "center",
              }}>{ext(f.name)}</div>
              <span style={{ fontSize: 13, color: "var(--color-text-primary)", flex: 1 }}>{f.name}</span>
              <span style={{ fontSize: 12, color: "var(--color-text-tertiary)", fontFamily: "var(--font-mono)" }}>
                {formatSize(f.size)}
              </span>
              <button
                onClick={(e) => { e.stopPropagation(); removeFile(f.name); }}
                style={{
                  background: "none", border: "none", cursor: "pointer",
                  color: "var(--color-text-tertiary)", fontSize: 16, padding: "0 2px",
                  lineHeight: 1,
                }}
                aria-label="Remove file"
              >
                <i className="ti ti-x" aria-hidden="true" />
              </button>
            </div>
          ))}
        </div>
      )}

      <button
        onClick={() => onNext(files)}
        disabled={files.length === 0}
        style={{
          padding: "10px 24px", fontSize: 14, fontWeight: 500,
          background: files.length > 0 ? "var(--color-text-primary)" : "var(--color-background-secondary)",
          color: files.length > 0 ? "var(--color-background-primary)" : "var(--color-text-tertiary)",
          border: "none", borderRadius: "var(--border-radius-md)",
          cursor: files.length > 0 ? "pointer" : "not-allowed",
          transition: "all 0.2s ease",
        }}
      >
        Continue to configure <i className="ti ti-arrow-right" aria-hidden="true" />
      </button>
    </div>
  );
}

function ConfigureStep({ files, onBack, onNext }) {
  const [modelType, setModelType] = useState("");
  const [customType, setCustomType] = useState("");
  const [domain, setDomain] = useState("");
  const [framework, setFramework] = useState("");
  const [notes, setNotes] = useState("");

  const canProceed = (modelType !== "") && (modelType !== "Other" || customType.trim() !== "") && framework !== "";

  const selectStyle = {
    width: "100%", padding: "9px 12px", fontSize: 14,
    border: "0.5px solid var(--color-border-secondary)",
    borderRadius: "var(--border-radius-md)",
    background: "var(--color-background-primary)",
    color: "var(--color-text-primary)",
    fontFamily: "var(--font-sans)",
    appearance: "none",
    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24'%3E%3Cpath fill='none' stroke='%23888' stroke-width='2' d='M6 9l6 6 6-6'/%3E%3C/svg%3E")`,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "right 12px center",
    cursor: "pointer",
  };

  const inputStyle = {
    width: "100%", padding: "9px 12px", fontSize: 14,
    border: "0.5px solid var(--color-border-secondary)",
    borderRadius: "var(--border-radius-md)",
    background: "var(--color-background-primary)",
    color: "var(--color-text-primary)",
    fontFamily: "var(--font-sans)",
    boxSizing: "border-box",
  };

  const labelStyle = {
    display: "block", fontSize: 12, fontWeight: 500,
    color: "var(--color-text-secondary)", marginBottom: 6,
    letterSpacing: "0.04em", textTransform: "uppercase",
  };

  return (
    <div>
      <h2 style={{ fontSize: 22, fontWeight: 500, margin: "0 0 0.5rem", color: "var(--color-text-primary)" }}>
        Configure validation scope
      </h2>
      <p style={{ fontSize: 14, color: "var(--color-text-secondary)", margin: "0 0 1.5rem", lineHeight: 1.6 }}>
        {files.length} file{files.length > 1 ? "s" : ""} uploaded. Specify the model type and regulatory context so the validation dimensions are correctly scoped.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
        <div>
          <label style={labelStyle}>Model type *</label>
          <select style={selectStyle} value={modelType} onChange={e => setModelType(e.target.value)}>
            <option value="">Select model type...</option>
            {MODEL_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label style={labelStyle}>Regulatory framework *</label>
          <select style={selectStyle} value={framework} onChange={e => setFramework(e.target.value)}>
            <option value="">Select framework...</option>
            {REGULATORY_FRAMEWORKS.map(f => <option key={f} value={f}>{f}</option>)}
          </select>
        </div>
      </div>

      {modelType === "Other" && (
        <div style={{ marginBottom: 16 }}>
          <label style={labelStyle}>Specify model type *</label>
          <input
            type="text"
            style={inputStyle}
            placeholder="e.g. Climate risk scenario model"
            value={customType}
            onChange={e => setCustomType(e.target.value)}
          />
        </div>
      )}

      <div style={{ marginBottom: 16 }}>
        <label style={labelStyle}>Business domain / portfolio</label>
        <input
          type="text"
          style={inputStyle}
          placeholder="e.g. Retail mortgage, Corporate FX derivatives, AML – wire transfers"
          value={domain}
          onChange={e => setDomain(e.target.value)}
        />
      </div>

      <div style={{ marginBottom: "1.5rem" }}>
        <label style={labelStyle}>Additional context for the validator</label>
        <textarea
          style={{ ...inputStyle, minHeight: 80, resize: "vertical", lineHeight: 1.6 }}
          placeholder="Known issues, specific validation focus areas, model version, last validation date, any material changes since last review..."
          value={notes}
          onChange={e => setNotes(e.target.value)}
        />
      </div>

      <div style={{ display: "flex", gap: 10 }}>
        <button
          onClick={onBack}
          style={{
            padding: "10px 20px", fontSize: 14,
            background: "none",
            color: "var(--color-text-secondary)",
            border: "0.5px solid var(--color-border-secondary)",
            borderRadius: "var(--border-radius-md)", cursor: "pointer",
          }}
        >
          <i className="ti ti-arrow-left" aria-hidden="true" /> Back
        </button>
        <button
          onClick={() => onNext({ modelType: modelType === "Other" ? customType : modelType, domain, framework, notes })}
          disabled={!canProceed}
          style={{
            padding: "10px 24px", fontSize: 14, fontWeight: 500,
            background: canProceed ? "var(--color-text-primary)" : "var(--color-background-secondary)",
            color: canProceed ? "var(--color-background-primary)" : "var(--color-text-tertiary)",
            border: "none", borderRadius: "var(--border-radius-md)",
            cursor: canProceed ? "pointer" : "not-allowed",
            transition: "all 0.2s ease",
          }}
        >
          Run validation <i className="ti ti-player-play" aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}

function ValidatingStep({ files, config }) {
  const stages = [
    "Parsing uploaded documentation",
    "Mapping model to validation dimensions",
    "Evaluating conceptual soundness",
    "Assessing data quality and representativeness",
    "Running quantitative checks",
    "Evaluating performance and stability metrics",
    "Checking regulatory compliance posture",
    "Scoring findings and generating report",
  ];
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    let i = 0;
    const tick = setInterval(() => {
      i++;
      if (i < stages.length) {
        setCurrent(i);
      } else {
        clearInterval(tick);
      }
    }, 800);
    return () => clearInterval(tick);
  }, []);

  return (
    <div style={{ minHeight: 300, display: "flex", flexDirection: "column", justifyContent: "center" }}>
      <h2 style={{ fontSize: 22, fontWeight: 500, margin: "0 0 0.5rem", color: "var(--color-text-primary)" }}>
        "Running validation..."
      </h2>
      <p style={{ fontSize: 14, color: "var(--color-text-secondary)", margin: "0 0 2rem" }}>
        {config.modelType} · {config.framework}
      </p>
      <div>
        {stages.map((s, i) => (
          <div key={s} style={{
            display: "flex", alignItems: "center", gap: 12,
            padding: "8px 0",
            opacity: i <= current ? 1 : 0.3,
            transition: "opacity 0.4s ease",
          }}>
            <div style={{
              width: 18, height: 18, borderRadius: "50%", flexShrink: 0,
              background: i < current ? "var(--color-text-primary)" : i === current ? "var(--color-background-secondary)" : "var(--color-background-secondary)",
              border: `1.5px solid ${i < current ? "var(--color-text-primary)" : i === current ? "var(--color-border-primary)" : "var(--color-border-tertiary)"}`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 10, color: i < current ? "var(--color-background-primary)" : "transparent",
              transition: "all 0.3s ease",
            }}>
              {i < current && "✓"}
              {i === current && (
                <div style={{
                  width: 6, height: 6, borderRadius: "50%",
                  background: "var(--color-text-primary)",
                  animation: "pulse 1s infinite",
                }} />
              )}
            </div>
            <span style={{
              fontSize: 13, fontFamily: "var(--font-mono)",
              color: i <= current ? "var(--color-text-primary)" : "var(--color-text-tertiary)",
            }}>{s}</span>
          </div>
        ))}
      </div>
      <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }`}</style>
    </div>
  );
}

const SEVERITY_COLORS = {
  "Critical Finding": { bg: "var(--color-background-danger)", text: "var(--color-text-danger)", border: "var(--color-border-danger)" },
  "Material Finding": { bg: "#FFF3E0", text: "#E65100", border: "#FFB74D" },
  "Observation": { bg: "var(--color-background-info)", text: "var(--color-text-info)", border: "var(--color-border-info)" },
  "Best Practice Gap": { bg: "var(--color-background-secondary)", text: "var(--color-text-secondary)", border: "var(--color-border-secondary)" },
};

function SeverityBadge({ severity }) {
  const c = SEVERITY_COLORS[severity] || SEVERITY_COLORS["Observation"];
  return (
    <span style={{
      fontSize: 11, fontWeight: 500, padding: "3px 9px",
      borderRadius: "var(--border-radius-md)",
      background: c.bg, color: c.text,
      border: `0.5px solid ${c.border}`,
      letterSpacing: "0.03em", whiteSpace: "nowrap",
    }}>{severity}</span>
  );
}

function FindingCard({ finding }) {
  const [open, setOpen] = useState(false);
  return (
    <div style={{
      border: "0.5px solid var(--color-border-tertiary)",
      borderRadius: "var(--border-radius-md)",
      marginBottom: 8, overflow: "hidden",
      background: "var(--color-background-primary)",
    }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: "100%", display: "flex", alignItems: "center", gap: 12,
          padding: "12px 16px", background: "none", border: "none",
          cursor: "pointer", textAlign: "left",
        }}
      >
        <SeverityBadge severity={finding.severity} />
        <span style={{ fontSize: 13, fontWeight: 500, flex: 1, color: "var(--color-text-primary)" }}>
          {finding.dimension} — {finding.title}
        </span>
        <i className={`ti ti-chevron-${open ? "up" : "down"}`} style={{ fontSize: 16, color: "var(--color-text-tertiary)" }} aria-hidden="true" />
      </button>
      {open && (
        <div style={{ padding: "0 16px 16px", borderTop: "0.5px solid var(--color-border-tertiary)" }}>
          <div style={{ paddingTop: 14, display: "grid", gap: 12 }}>
            <div>
              <p style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--color-text-tertiary)", margin: "0 0 4px", fontWeight: 500 }}>Finding</p>
              <p style={{ fontSize: 13, color: "var(--color-text-primary)", margin: 0, lineHeight: 1.65 }}>{finding.finding}</p>
            </div>
            <div>
              <p style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--color-text-tertiary)", margin: "0 0 4px", fontWeight: 500 }}>Implication</p>
              <p style={{ fontSize: 13, color: "var(--color-text-primary)", margin: 0, lineHeight: 1.65 }}>{finding.implication}</p>
            </div>
            <div>
              <p style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--color-text-tertiary)", margin: "0 0 4px", fontWeight: 500 }}>Recommended action</p>
              <p style={{ fontSize: 13, color: "var(--color-text-primary)", margin: 0, lineHeight: 1.65 }}>{finding.action}</p>
            </div>
            {finding.reference && (
              <div>
                <p style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--color-text-tertiary)", margin: "0 0 4px", fontWeight: 500 }}>Evidence reference</p>
                <p style={{ fontSize: 12, fontFamily: "var(--font-mono)", color: "var(--color-text-secondary)", margin: 0 }}>{finding.reference}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function ReportStep({ files, config, report, onReset }) {
  const [exportView, setExportView] = useState(null); // null | "markdown" | "plaintext"

  const counts = report.findings.reduce((acc, f) => {
    acc[f.severity] = (acc[f.severity] || 0) + 1;
    return acc;
  }, {});

  const ratingColor = {
    "Unsatisfactory": "var(--color-text-danger)",
    "Needs Improvement": "#E65100",
    "Satisfactory": "var(--color-text-success)",
    "Strong": "var(--color-text-success)",
  }[report.overallRating] || "var(--color-text-secondary)";

  const grouped = report.findings.reduce((acc, f) => {
    (acc[f.dimension] = acc[f.dimension] || []).push(f);
    return acc;
  }, {});

  const mdText = generateMarkdown(report, config, files);
  const plainText = generatePlainText(report, config, files);

  const btnBase = {
    padding: "8px 14px", fontSize: 12, fontWeight: 500,
    borderRadius: "var(--border-radius-md)", cursor: "pointer",
    display: "flex", alignItems: "center", gap: 6,
  };

  if (exportView) {
    const text = exportView === "markdown" ? mdText : plainText;
    const label = exportView === "markdown" ? "Markdown" : "Plain text";
    return (
      <div>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: "1rem" }}>
          <button onClick={() => setExportView(null)} style={{ ...btnBase, background: "none", border: "0.5px solid var(--color-border-secondary)", color: "var(--color-text-secondary)" }}>
            ← Back to report
          </button>
          <span style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>
            {label} — select all and copy with Ctrl+A / Cmd+A
          </span>
        </div>
        <textarea
          readOnly
          value={text}
          onClick={e => e.target.select()}
          style={{
            width: "100%", height: "70vh", padding: "14px 16px",
            fontFamily: "var(--font-mono)", fontSize: 12, lineHeight: 1.7,
            border: "0.5px solid var(--color-border-secondary)",
            borderRadius: "var(--border-radius-lg)",
            background: "var(--color-background-secondary)",
            color: "var(--color-text-primary)",
            resize: "none", outline: "none",
          }}
        />
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: "1.5rem", gap: 12 }}>
        <div>
          <h2 style={{ fontSize: 22, fontWeight: 500, margin: "0 0 4px", color: "var(--color-text-primary)" }}>
            Validation Report
          </h2>
          <p style={{ fontSize: 13, color: "var(--color-text-secondary)", margin: 0, fontFamily: "var(--font-mono)" }}>
            {config.modelType} · {config.framework} · {new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}
          </p>
        </div>
        <div style={{ display: "flex", gap: 8, flexShrink: 0, flexWrap: "wrap" }}>
          <button onClick={() => setExportView("markdown")} style={{ ...btnBase, background: "var(--color-text-primary)", border: "none", color: "var(--color-background-primary)" }}>
            Export Markdown
          </button>
          <button onClick={() => setExportView("plaintext")} style={{ ...btnBase, background: "var(--color-text-primary)", border: "none", color: "var(--color-background-primary)" }}>
            Export Plain Text
          </button>
          <button onClick={onReset} style={{ ...btnBase, background: "none", border: "0.5px solid var(--color-border-secondary)", color: "var(--color-text-secondary)" }}>
            ↺ New
          </button>
        </div>
      </div>

      <div style={{
        padding: "16px 20px", borderRadius: "var(--border-radius-lg)",
        border: "0.5px solid var(--color-border-secondary)",
        background: "var(--color-background-secondary)", marginBottom: "1.5rem",
      }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 16, marginBottom: 10 }}>
          <span style={{ fontSize: 12, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--color-text-tertiary)", fontWeight: 500 }}>Overall rating</span>
          <span style={{ fontSize: 20, fontWeight: 500, color: ratingColor, fontFamily: "var(--font-mono)" }}>
            {report.overallRating}
          </span>
        </div>
        <p style={{ fontSize: 13, color: "var(--color-text-primary)", margin: "0 0 14px", lineHeight: 1.7 }}>
          {report.executiveSummary}
        </p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {Object.entries(SEVERITY_COLORS).map(([sev, c]) => counts[sev] ? (
            <span key={sev} style={{
              fontSize: 12, padding: "3px 10px",
              borderRadius: "var(--border-radius-md)",
              background: c.bg, color: c.text, border: `0.5px solid ${c.border}`,
            }}>
              {counts[sev]} {sev}{counts[sev] > 1 ? "s" : ""}
            </span>
          ) : null)}
        </div>
      </div>

      <h3 style={{ fontSize: 14, fontWeight: 500, textTransform: "uppercase", letterSpacing: "0.06em", color: "var(--color-text-secondary)", margin: "0 0 12px" }}>
        Validation findings
      </h3>

      {Object.entries(grouped).map(([dim, findings]) => (
        <div key={dim} style={{ marginBottom: "1.5rem" }}>
          <p style={{ fontSize: 12, fontWeight: 500, color: "var(--color-text-tertiary)", margin: "0 0 8px", fontFamily: "var(--font-mono)", textTransform: "uppercase", letterSpacing: "0.05em" }}>
            {dim}
          </p>
          {findings.map((f, i) => <FindingCard key={i} finding={f} />)}
        </div>
      ))}

      <div style={{
        marginTop: "2rem", padding: "16px 20px",
        border: "0.5px solid var(--color-border-tertiary)",
        borderRadius: "var(--border-radius-lg)",
        background: "var(--color-background-primary)",
      }}>
        <h3 style={{ fontSize: 13, fontWeight: 500, margin: "0 0 10px", color: "var(--color-text-primary)" }}>Scope and limitations</h3>
        <p style={{ fontSize: 13, color: "var(--color-text-secondary)", margin: 0, lineHeight: 1.7 }}>
          {report.scopeLimitations}
        </p>
      </div>
    </div>
  );
}


function generatePlainText(report, config, files) {
  const date = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" });
  const line = (char, len = 72) => char.repeat(len);
  let t = "";
  t += "MODEL VALIDATION REPORT\n";
  t += line("=") + "\n\n";
  t += `Model type:           ${config.modelType}\n`;
  t += `Regulatory framework: ${config.framework}\n`;
  if (config.domain) t += `Business domain:      ${config.domain}\n`;
  t += `Validation date:      ${date}\n`;
  if (files.length > 0) t += `Files reviewed:       ${files.map(f => f.name).join(", ")}\n`;
  t += "\n" + line("-") + "\n\n";
  t += "EXECUTIVE SUMMARY\n";
  t += line("-") + "\n";
  t += `Overall Rating: ${report.overallRating}\n\n`;
  t += report.executiveSummary + "\n\n";
  t += line("-") + "\n\n";
  t += "VALIDATION FINDINGS\n";
  t += line("=") + "\n\n";
  const grouped = report.findings.reduce((acc, f) => { (acc[f.dimension] = acc[f.dimension] || []).push(f); return acc; }, {});
  for (const [dim, findings] of Object.entries(grouped)) {
    t += `${dim.toUpperCase()}\n` + line("-", dim.length) + "\n\n";
    for (const f of findings) {
      t += `[${f.severity}] ${f.title}\n`;
      t += `Finding:            ${f.finding}\n`;
      t += `Implication:        ${f.implication}\n`;
      t += `Recommended action: ${f.action}\n`;
      if (f.reference) t += `Evidence reference: ${f.reference}\n`;
      t += "\n";
    }
  }
  t += line("-") + "\n\n";
  t += "SCOPE AND LIMITATIONS\n";
  t += line("-") + "\n";
  t += report.scopeLimitations + "\n";
  return t;
}

function generateMarkdown(report, config, files) {
  const date = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" });
  let md = `# Model Validation Report\n\n`;
  md += `**Model type:** ${config.modelType}  \n`;
  md += `**Regulatory framework:** ${config.framework}  \n`;
  if (config.domain) md += `**Business domain:** ${config.domain}  \n`;
  md += `**Validation date:** ${date}  \n`;
  md += `**Files reviewed:** ${files.map(f => f.name).join(", ")}  \n\n`;
  md += `---\n\n## Executive Summary\n\n**Overall Rating: ${report.overallRating}**\n\n${report.executiveSummary}\n\n`;
  md += `---\n\n## Validation Findings\n\n`;
  const grouped = report.findings.reduce((acc, f) => { (acc[f.dimension] = acc[f.dimension] || []).push(f); return acc; }, {});
  for (const [dim, findings] of Object.entries(grouped)) {
    md += `### ${dim}\n\n`;
    for (const f of findings) {
      md += `#### [${f.severity}] ${f.title}\n\n`;
      md += `**Finding:** ${f.finding}\n\n`;
      md += `**Implication:** ${f.implication}\n\n`;
      md += `**Recommended action:** ${f.action}\n\n`;
      if (f.reference) md += `**Evidence reference:** \`${f.reference}\`\n\n`;
    }
  }
  md += `---\n\n## Scope and Limitations\n\n${report.scopeLimitations}\n`;
  return md;
}


function generateHtmlReport(report, config, files) {
  const date = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "long", year: "numeric" });
  const SEV_COLORS = {
    "Critical Finding":  { bg: "#fef2f2", color: "#b91c1c", border: "#fca5a5" },
    "Material Finding":  { bg: "#fff7ed", color: "#c2410c", border: "#fed7aa" },
    "Observation":       { bg: "#eff6ff", color: "#1d4ed8", border: "#bfdbfe" },
    "Best Practice Gap": { bg: "#f9fafb", color: "#374151", border: "#e5e7eb" },
  };
  const RATING_COLORS = {
    "Unsatisfactory":    "#b91c1c",
    "Needs Improvement": "#c2410c",
    "Satisfactory":      "#15803d",
    "Strong":            "#15803d",
  };
  const grouped = report.findings.reduce((acc, f) => {
    (acc[f.dimension] = acc[f.dimension] || []).push(f); return acc;
  }, {});

  const findingsHtml = Object.entries(grouped).map(([dim, findings]) => `
    <div class="dimension-block">
      <div class="dim-label">${dim}</div>
      ${findings.map(f => {
        const sc = SEV_COLORS[f.severity] || SEV_COLORS["Best Practice Gap"];
        return `
        <div class="finding-card">
          <div class="finding-header">
            <span class="sev-badge" style="background:${sc.bg};color:${sc.color};border:1px solid ${sc.border}">${f.severity}</span>
            <span class="finding-title">${f.title}</span>
          </div>
          <table class="finding-table">
            <tr><td class="ft-label">Finding</td><td>${f.finding}</td></tr>
            <tr><td class="ft-label">Implication</td><td>${f.implication}</td></tr>
            <tr><td class="ft-label">Recommended action</td><td>${f.action}</td></tr>
            ${f.reference ? `<tr><td class="ft-label">Evidence reference</td><td><code>${f.reference}</code></td></tr>` : ""}
          </table>
        </div>`;
      }).join("")}
    </div>`).join("");

  const counts = report.findings.reduce((acc, f) => { acc[f.severity] = (acc[f.severity]||0)+1; return acc; }, {});
  const badgeHtml = Object.entries(SEV_COLORS).map(([sev, sc]) =>
    counts[sev] ? `<span class="sev-badge" style="background:${sc.bg};color:${sc.color};border:1px solid ${sc.border}">${counts[sev]} ${sev}${counts[sev]>1?"s":""}</span>` : ""
  ).join(" ");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Model Validation Report — ${config.modelType}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, Helvetica, sans-serif; font-size: 11pt; color: #111; background: #fff; padding: 2cm; }
  h1 { font-size: 20pt; font-weight: 700; color: #1e3a5f; margin-bottom: 4px; }
  .meta { font-size: 9pt; color: #555; font-family: monospace; margin-bottom: 24px; }
  .section-title { font-size: 10pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: #555; margin: 28px 0 10px; border-bottom: 1px solid #e5e7eb; padding-bottom: 4px; }
  .summary-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 16px 20px; margin-bottom: 20px; }
  .rating-row { display: flex; align-items: baseline; gap: 14px; margin-bottom: 8px; }
  .rating-label { font-size: 9pt; text-transform: uppercase; letter-spacing: 0.06em; color: #888; font-weight: 600; }
  .rating-value { font-size: 16pt; font-weight: 700; color: ${RATING_COLORS[report.overallRating] || "#111"}; font-family: monospace; }
  .exec-text { font-size: 10.5pt; line-height: 1.65; color: #222; margin-bottom: 12px; }
  .badge-row { display: flex; gap: 6px; flex-wrap: wrap; }
  .sev-badge { font-size: 8pt; font-weight: 600; padding: 2px 8px; border-radius: 4px; display: inline-block; }
  .dimension-block { margin-bottom: 20px; }
  .dim-label { font-size: 9pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #888; font-family: monospace; margin-bottom: 8px; }
  .finding-card { border: 1px solid #e5e7eb; border-radius: 5px; margin-bottom: 8px; overflow: hidden; page-break-inside: avoid; }
  .finding-header { display: flex; align-items: center; gap: 10px; padding: 9px 14px; background: #f9fafb; }
  .finding-title { font-size: 10.5pt; font-weight: 600; color: #111; }
  .finding-table { width: 100%; border-collapse: collapse; }
  .finding-table tr { border-top: 1px solid #f3f4f6; }
  .finding-table td { padding: 7px 14px; font-size: 10pt; line-height: 1.55; vertical-align: top; }
  .ft-label { font-size: 8.5pt; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: #888; white-space: nowrap; width: 130px; }
  code { font-family: monospace; font-size: 9pt; color: #555; background: #f3f4f6; padding: 1px 4px; border-radius: 3px; }
  .scope-box { background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 5px; padding: 12px 16px; }
  .scope-text { font-size: 10pt; color: #444; line-height: 1.6; }
  .footer { margin-top: 32px; padding-top: 12px; border-top: 1px solid #e5e7eb; font-size: 8.5pt; color: #999; }
  @media print { body { padding: 1.5cm; } .finding-card { page-break-inside: avoid; } }
</style>
</head>
<body>
  <h1>Model Validation Report</h1>
  <div class="meta">${config.modelType} &nbsp;·&nbsp; ${config.framework}${config.domain ? " &nbsp;·&nbsp; " + config.domain : ""} &nbsp;·&nbsp; ${date}</div>
  ${files.length > 0 ? `<div class="meta" style="margin-top:-18px;margin-bottom:20px;">Files reviewed: ${files.map(f=>f.name).join(", ")}</div>` : ""}

  <div class="section-title">Executive Summary</div>
  <div class="summary-box">
    <div class="rating-row">
      <span class="rating-label">Overall Rating</span>
      <span class="rating-value">${report.overallRating}</span>
    </div>
    <p class="exec-text">${report.executiveSummary}</p>
    <div class="badge-row">${badgeHtml}</div>
  </div>

  <div class="section-title">Validation Findings</div>
  ${findingsHtml}

  <div class="section-title">Scope and Limitations</div>
  <div class="scope-box"><p class="scope-text">${report.scopeLimitations}</p></div>

  <div class="footer">Generated by Model Validation Engine &nbsp;·&nbsp; ${date} &nbsp;·&nbsp; For regulatory and audit use</div>
</body>
</html>`;
}

function downloadPdf(report, config, files) {
  const html = generateHtmlReport(report, config, files);
  const encoded = "data:text/html;charset=utf-8," + encodeURIComponent(html);
  const a = document.createElement("a");
  const date = new Date().toISOString().slice(0,10);
  a.href = encoded;
  a.download = `Validation_Report_${(config.modelType||"Model").replace(/[^a-z0-9]/gi,"_")}_${date}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function downloadWord(report, config, files) {
  const html = generateHtmlReport(report, config, files);
  const encoded = "data:application/msword;charset=utf-8," + encodeURIComponent("\ufeff" + html);
  const a = document.createElement("a");
  const date = new Date().toISOString().slice(0,10);
  a.href = encoded;
  a.download = `Validation_Report_${(config.modelType||"Model").replace(/[^a-z0-9]/gi,"_")}_${date}.doc`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

async function runValidation(files, config) {
  const fileNames = files.map(f => f.name).join(", ");
  const fileTypes = [...new Set(files.map(f => f.name.split(".").pop().toUpperCase()))].join(", ");

  const systemPrompt = `You are a senior model validation specialist with deep expertise across financial services model types including credit risk (PD, LGD, EAD), market risk (VaR, ES), pricing models (options, fixed income), transaction monitoring (rule-based, ML), and fraud detection. You write model validation reports to regulatory standards including SR 11-7, PRA SS1/23, and ECB Internal Model Guide.

Your task: produce a structured model validation report in JSON format only. No preamble. No markdown. Pure JSON.

Return exactly this structure:
{
  "overallRating": "Unsatisfactory|Needs Improvement|Satisfactory|Strong",
  "executiveSummary": "200 words max. Formal regulatory English. Key conclusions, material risks identified, overall assessment.",
  "findings": [
    {
      "dimension": "string (validation dimension name)",
      "severity": "Critical Finding|Material Finding|Observation|Best Practice Gap",
      "title": "short finding title",
      "finding": "What the evidence shows. Cite the document/file where applicable. Specific, not generic.",
      "implication": "What this means for model soundness, regulatory compliance, or business risk.",
      "action": "Specific remediation step with a suggested timeline.",
      "reference": "File/section reference if applicable, else null"
    }
  ],
  "scopeLimitations": "What could not be assessed given the materials provided. Honest about gaps."
}

Validation dimensions to apply based on model type:
- Credit Risk PD/LGD/EAD: Conceptual soundness, Data quality & representativeness, Segmentation logic, Discriminatory power (Gini/AUC), Calibration (Hosmer-Lemeshow), Stability (PSI/CSI), Override rates, Margin of conservatism, Regulatory compliance
- Transaction Monitoring: Rule/model logic coverage, Threshold calibration, False positive rate, SAR conversion rate, Typology alignment, Data completeness, Backtesting, Segmentation
- Pricing Models: Model assumptions, Parameter sensitivity, Benchmark comparison, P&L explain, Stress scenarios, Greeks accuracy (if applicable)
- Market Risk VaR/ES: Backtesting (Basel traffic light), Risk factor coverage, Correlation assumptions, Liquidity horizon, Stress VaR
- For unlisted types: derive dimensions from SR 11-7 principles and state your derivation in the finding.

Rules:
- Every finding must reference the uploaded files by name where possible.
- Do not produce boilerplate findings. Tailor each to the model type and regulatory framework.
- Severity definitions: Critical = model cannot be used as-is, regulatory breach likely. Material = significant weakness requiring remediation before next review. Observation = weakness that should be addressed. Best Practice Gap = not a deficiency but below industry standard.
- Produce exactly 8 findings. Cover multiple dimensions.
- Keep each finding, implication, and action field under 80 words each. Be precise, not verbose.
- Keep executiveSummary under 120 words.
- Keep scopeLimitations under 60 words.
- The overall rating must reflect the severity distribution: any Critical Finding = at most Needs Improvement.
- CRITICAL: Your entire JSON response must be complete and valid. Do not truncate. Close all braces and brackets.`;

  const userMsg = `Validate the following model:

Model type: ${config.modelType}
Regulatory framework: ${config.framework}
Business domain: ${config.domain || "Not specified"}
Additional context: ${config.notes || "None provided"}
Files uploaded: ${fileNames} (types: ${fileTypes})

Since actual file content cannot be parsed in this demo, base your validation on the model type, regulatory framework, and file names provided. Reason through what a validator would assess for this model type, what documentation should be present, and what common deficiencies arise for this model type under the specified framework. Generate realistic, specific, audit-grade findings as if you had reviewed the actual documents. Make the findings feel like a real validation report, not a generic checklist.`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 8000,
      system: systemPrompt,
      messages: [{ role: "user", content: userMsg }],
    }),
  });

  if (!response.ok) throw new Error(`API error: ${response.status}`);
  const data = await response.json();
  const text = data.content.map(b => b.text || "").join("").trim();
  const clean = text.replace(/^```json\s*/i, "").replace(/```\s*$/i, "").trim();
  try {
    return JSON.parse(clean);
  } catch (parseErr) {
    // Try to recover a partial JSON by finding the last complete finding
    const lastBracket = clean.lastIndexOf('}');
    if (lastBracket > 0) {
      try {
        // Attempt to close out truncated JSON
        const partial = clean.substring(0, lastBracket + 1);
        // Find end of findings array
        const findingsEnd = partial.lastIndexOf('}');
        const recovered = partial.substring(0, findingsEnd + 1) + ']}';
        return JSON.parse(recovered);
      } catch(e) {}
    }
    throw new Error(`Report generation failed — response was cut off. Try again. (${parseErr.message})`);
  }
}

export default function App() {
  const [step, setStep] = useState("upload");
  const [files, setFiles] = useState([]);
  const [config, setConfig] = useState(null);
  const [report, setReport] = useState(null);
  const [error, setError] = useState(null);

  const handleUpload = (uploadedFiles) => {
    setFiles(uploadedFiles);
    setStep("configure");
  };

  const handleConfigureWithFiles = async (cfg) => {
    setConfig(cfg);
    setStep("validate");
    setError(null);
    try {
      const r = await runValidation(files, cfg);
      // Set report first, then transition — avoids race where step changes before state lands
      setReport(r);
      setStep("report");
    } catch (e) {
      setError(e.message);
      setStep("configure");
    }
  };

  const handleReset = () => {
    setStep("upload");
    setFiles([]);
    setConfig(null);
    setReport(null);
    setError(null);
  };

  return (
    <div style={{ padding: "1.5rem 0", maxWidth: 680, margin: "0 auto" }}>
      <h2 className="sr-only">Model Validation Tool — upload model documentation, configure scope, receive a formal validation report.</h2>

      <div style={{ marginBottom: "2rem" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
          <span style={{
            fontSize: 10, fontFamily: "var(--font-mono)", fontWeight: 500,
            letterSpacing: "0.1em", textTransform: "uppercase",
            color: "var(--color-text-tertiary)",
            border: "0.5px solid var(--color-border-tertiary)",
            padding: "2px 8px", borderRadius: "var(--border-radius-md)",
          }}>
            Model Risk Management
          </span>
        </div>
        <h1 style={{ fontSize: 28, fontWeight: 500, margin: 0, color: "var(--color-text-primary)", letterSpacing: "-0.02em" }}>
          Validation Engine
        </h1>
        <p style={{ fontSize: 14, color: "var(--color-text-secondary)", margin: "4px 0 0", lineHeight: 1.5 }}>
          Subject-agnostic · SR 11-7 / PRA SS1/23 / ECB aligned · Regulatory-grade output
        </p>
      </div>

      <Stepper current={step} />

      {error && (
        <div style={{
          padding: "12px 16px", borderRadius: "var(--border-radius-md)",
          background: "var(--color-background-danger)", color: "var(--color-text-danger)",
          border: "0.5px solid var(--color-border-danger)", fontSize: 13, marginBottom: "1rem",
        }}>
          <i className="ti ti-alert-triangle" aria-hidden="true" /> Validation error: {error}
        </div>
      )}

      {step === "upload" && <UploadStep onNext={handleUpload} />}
      {step === "configure" && <ConfigureStep files={files} onBack={() => setStep("upload")} onNext={handleConfigureWithFiles} />}
      {step === "validate" && <ValidatingStep files={files} config={config} />}
      {step === "report" && report && <ReportStep files={files} config={config} report={report} onReset={handleReset} />}
    </div>
  );
}
